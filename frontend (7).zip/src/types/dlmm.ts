// src/types/dlmm.ts

// Define the type for the detailed LP position data returned from the backend
export interface LpPosition {
  address: string; // Position address
  pair_address: string; // LB Pair address
  owner: string; // Owner public key

  // Data from Meteora API (subset)
  total_fee_usd_claimed: number; // Total claimed fee in USD
  total_reward_usd_claimed: number; // Total claimed reward in USD
  fee_apy_24h: number; // 24h fee APY
  fee_apr_24h: number; // 24h fee APR
  daily_fee_yield: number; // Daily fee yield

  // Calculated details from on-chain data (now provided by backend)
  lowerBinId: number;
  upperBinId: number;
  binStep: number;
  tokenXMint: string;
  tokenXSymbol?: string; // Optional: Symbol for token X
  tokenYMint: string;
  tokenYSymbol?: string; // Optional: Symbol for token Y
  tokenXDecimals: number;
  tokenYDecimals: number;
  totalXAmount: bigint; // Raw amount
  totalYAmount: bigint; // Raw amount
  pendingFeeX: bigint; // Raw amount
  pendingFeeY: bigint; // Raw amount
  pendingRewards: { mint: string; amount: bigint; symbol?: string }[]; // Raw amounts, optional symbol
  totalXAmountUi: string; // Formatted UI amount
  totalYAmountUi: string; // Formatted UI amount
  pendingFeeXUi: string; // Formatted UI amount
  pendingFeeYUi: string; // Formatted UI amount
  pendingRewardsUi: { mint: string; amount: string; symbol?: string }[]; // Formatted UI amounts, optional symbol
  priceRange: string; // Formatted price range
  totalValueInSol: string; // Total value in SOL (formatted)
}

// 필요하다면 다른 DLMM 관련 타입들도 여기에 정의할 수 있습니다.
// 예: interface DlmmPoolInfo { ... }
