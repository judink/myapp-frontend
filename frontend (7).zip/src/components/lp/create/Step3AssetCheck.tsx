import React from 'react';
import Decimal from 'decimal.js'; // Import Decimal for formatting

interface AssetCheckResult {
  needsSwap: boolean;
  requiredAssets: {
    solLamports: string;
    targetTokenLamports: string;
    tokenCa: string;
    tokenDecimals: number;
  };
  currentBalances: {
    solLamports: string;
    targetTokenLamports: string;
  };
  swapQuote: any | null; // Define a more specific type if possible
}

interface Step3AssetCheckProps {
  assetCheckResult: AssetCheckResult | null;
  assetCheckLoading: boolean; // Need this to show loading state
  createLpLoading: boolean; // Need this to disable the button
  handleExecuteCreateLp: () => Promise<void>;
  setCurrentStep: (step: number) => void;
  setAssetCheckResult: (result: AssetCheckResult | null) => void; // Need this to go back
}

export default function Step3AssetCheck({
  assetCheckResult,
  assetCheckLoading,
  createLpLoading,
  handleExecuteCreateLp,
  setCurrentStep,
  setAssetCheckResult,
}: Step3AssetCheckProps) {

  if (assetCheckLoading || !assetCheckResult) {
      // This component should ideally only render when assetCheckResult is available,
      // but handle loading/null state defensively.
      return <p>자산 정보를 불러오는 중...</p>;
  }

  const formatDisplayAmount = (lamports: string, decimals: number | undefined) => {
      if (!lamports || decimals === undefined) return 'N/A';
      try {
          const amountDecimal = new Decimal(lamports).div(new Decimal(10).pow(decimals));
          return amountDecimal.toFixed(decimals); // Display with full precision or adjust as needed
      } catch (e) {
          console.error("Error formatting amount:", e);
          return 'Error';
      }
  };

  const requiredSolDisplay = formatDisplayAmount(assetCheckResult.requiredAssets?.solLamports, 9);
  const requiredTargetDisplay = formatDisplayAmount(assetCheckResult.requiredAssets?.targetTokenLamports, assetCheckResult.requiredAssets?.tokenDecimals);

  const currentSolDisplay = assetCheckResult.currentBalances ? formatDisplayAmount(assetCheckResult.currentBalances.solLamports, 9) : 'N/A';
  const currentTargetDisplay = assetCheckResult.currentBalances ? formatDisplayAmount(assetCheckResult.currentBalances.targetTokenLamports, assetCheckResult.requiredAssets?.tokenDecimals) : 'N/A';


  return (
    <>
      <h2 className="text-2xl font-semibold text-white mb-6">단계 3: 자산 확인 및 스왑 동의</h2>
      <div className="space-y-4 mb-6 p-4 bg-gray-800 rounded-lg">
        <div>
          <h3 className="text-lg font-semibold text-sky-400 mb-1">필요 자산:</h3>
          <p>SOL: {requiredSolDisplay}</p>
          <p>대상 토큰 ({assetCheckResult.requiredAssets?.tokenCa?.substring(0,6)}...): {requiredTargetDisplay}</p>
        </div>
        <div>
          <h3 className="text-lg font-semibold text-green-400 mb-1">현재 잔액 (서버 조회):</h3>
          <p>SOL: {currentSolDisplay}</p>
          <p>대상 토큰 ({assetCheckResult.requiredAssets?.tokenCa?.substring(0,6)}...): {currentTargetDisplay}</p>
        </div>

        {assetCheckResult.needsSwap && (
          <div className="mt-4 p-3 bg-yellow-900 bg-opacity-50 rounded border border-yellow-700">
            <p className="text-yellow-400 font-semibold mb-2">알림: 자산이 부족하여 자동 스왑을 진행합니다.</p>
            {/* Display swap quote details more user-friendly */}
            {assetCheckResult.swapQuote ? (
              <div className="text-sm text-yellow-500">
                <p>스왑 경로: {assetCheckResult.swapQuote.routePlan?.map((route: any) => route.swapInfo.label).join(' -> ') || 'N/A'}</p>
                <p>입력량: {formatDisplayAmount(assetCheckResult.swapQuote.inAmount, assetCheckResult.swapQuote.inTokenInfo?.decimals || 9)} {assetCheckResult.swapQuote.inTokenInfo?.symbol || 'Input Token'}</p>
                <p>출력량: {formatDisplayAmount(assetCheckResult.swapQuote.outAmount, assetCheckResult.swapQuote.outTokenInfo?.decimals || 9)} {assetCheckResult.swapQuote.outTokenInfo?.symbol || 'Output Token'}</p>
                <p>최소 출력량 (슬리피지 포함): {formatDisplayAmount(assetCheckResult.swapQuote.outAmountWithSlippage, assetCheckResult.swapQuote.outTokenInfo?.decimals || 9)} {assetCheckResult.swapQuote.outTokenInfo?.symbol || 'Output Token'}</p>
                {/* Add more relevant quote details */}
              </div>
            ) : (
              <p className="text-sm text-yellow-500">스왑 견적 정보를 불러오지 못했습니다.</p>
            )}
          </div>
        )}
         {!assetCheckResult.needsSwap && (
           <div className="mt-4 p-3 bg-green-900 bg-opacity-50 rounded border border-green-700">
              <p className="text-green-400 font-semibold">필요한 자산이 충분합니다. 스왑 없이 LP 생성이 가능합니다.</p>
           </div>
         )}
      </div>

      <div className="flex space-x-4 mt-8">
        <button
          className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
          onClick={() => { setAssetCheckResult(null); setCurrentStep(2); }}
        >
          이전 (예치 설정)
        </button>
        <button
          className={`bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${createLpLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          onClick={handleExecuteCreateLp}
          disabled={createLpLoading}
        >
          {createLpLoading ? 'LP 생성 중...' : (assetCheckResult.needsSwap ? '자동 스왑 후 LP 생성' : 'LP 포지션 생성')}
        </button>
      </div>
    </>
  );
}
