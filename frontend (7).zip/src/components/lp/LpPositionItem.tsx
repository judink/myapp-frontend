"use client";

import React, { useState, useEffect } from 'react'; // Removed useCallback, added useEffect
import { LpPosition } from '@/types/dlmm';
import { useRemoveLp } from '@/hooks/useRemoveLp'; // Import the new hook
// import useAuthStore from '@/store/authStore'; // Not directly needed if user context is handled elsewhere or not needed for display
// import { PublicKey } from '@solana/web3.js'; // Not directly needed here
// import Decimal from 'decimal.js'; // Not used in this version of the component

interface LpPositionItemProps {
  position: LpPosition;
  onPositionRemoved: (positionAddress: string) => void;
  // Consider adding a generic notification callback for better UX
  // showNotification: (message: string, type: 'success' | 'error') => void;
}

// Removed lamportsToUiAmount as display amounts are expected from backend

export default function LpPositionItem({ position, onPositionRemoved }: LpPositionItemProps) {
  const { removeLp, isLoading, error: removeError, data: removeData, reset: resetRemoveLpState } = useRemoveLp();
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [bpsToRemove, setBpsToRemove] = useState(10000); // Default to 100%
  const [shouldClaimAndClose, setShouldClaimAndClose] = useState(true); // Default to true

  // const { user } = useAuthStore(); // Example if user context is needed for other actions

  useEffect(() => {
    if (removeData) {
      // alert(`LP 해제 트랜잭션이 성공적으로 전송되었습니다. 서명: ${removeData.signature}`);
      // Consider using a more sophisticated notification system instead of alert
      console.log(`LP removal successful for ${position.address}. Signature: ${removeData.signature}`);
      onPositionRemoved(position.address); // Notify parent to refresh list
      resetRemoveLpState(); // Reset hook state after successful operation
      setShowConfirmationModal(false); // Close modal
    }
  }, [removeData, position.address, onPositionRemoved, resetRemoveLpState]);

  useEffect(() => {
    if (removeError) {
      // alert(`LP 해제 중 오류 발생: ${removeError.message || removeError}`);
      console.error(`Error removing LP for ${position.address}:`, removeError);
      // Optionally, keep the modal open or provide specific feedback
      // resetRemoveLpState(); // Reset error after showing it, or let user dismiss
    }
  }, [removeError, position.address]);


  const handleInitiateRemove = () => {
    setShowConfirmationModal(true);
    // Reset any previous errors from the hook when opening modal
    if (removeError) resetRemoveLpState();
  };

  const handleConfirmRemove = async () => {
    console.log(`Attempting to remove ${bpsToRemove / 100}% of LP for position: ${position.address}, pool: ${position.pair_address}`);
    await removeLp({
      positionAddress: position.address,
      poolAddress: position.pair_address,
      bps: bpsToRemove,
      shouldClaimAndClose: shouldClaimAndClose,
    });
    // State updates (isLoading, error, data) are handled by the hook
    // Success/error useEffects will trigger based on hook state changes
  };

  const handleCancelRemove = () => {
    setShowConfirmationModal(false);
    resetRemoveLpState(); // Also reset if modal is cancelled
  };


  // Keep this disabled for now
  const handleRemoveAndSwap = async () => {
    console.warn("handleRemoveAndSwap: Functionality not implemented.");
    // This would involve a more complex flow:
    // 1. Remove LP (potentially getting back two tokens)
    // 2. If two tokens received, perform swaps to desired output token(s)
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg mb-4 shadow-md">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold text-white mb-1">
            LP 포지션: <span className="font-mono text-sm">{position.address.slice(0, 6)}...{position.address.slice(-6)}</span>
          </h3>
          <p className="text-sm text-gray-400">
            풀: <span className="font-mono">{position.pair_address.slice(0, 6)}...{position.pair_address.slice(-6)}</span>
          </p>
        </div>
        {/* Future: Could add a small status indicator (e.g., active, closed) */}
      </div>


      <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
        <div>
          <span className="text-gray-400">가격 범위: </span>
          <span className="text-white font-medium">{position.priceRange || 'N/A'}</span>
        </div>
        <div>
          <span className="text-gray-400">총 가치 (SOL): </span>
          <span className="text-white font-medium">{position.totalValueInSol || 'N/A'}</span>
        </div>
        <div>
          <span className="text-gray-400">예치 {position.tokenXSymbol || position.tokenXMint.slice(0,4)}: </span>
          <span className="text-white font-medium">{position.totalXAmountUi || '0'}</span>
        </div>
        <div>
          <span className="text-gray-400">예치 {position.tokenYSymbol || position.tokenYMint.slice(0,4)}: </span>
          <span className="text-white font-medium">{position.totalYAmountUi || '0'}</span>
        </div>
        <div>
          <span className="text-gray-400">미청구 {position.tokenXSymbol || position.tokenXMint.slice(0,4)} 수수료: </span>
          <span className="text-white font-medium">{position.pendingFeeXUi || '0'}</span>
        </div>
        <div>
          <span className="text-gray-400">미청구 {position.tokenYSymbol || position.tokenYMint.slice(0,4)} 수수료: </span>
          <span className="text-white font-medium">{position.pendingFeeYUi || '0'}</span>
        </div>
      </div>

      {position.pendingRewardsUi && position.pendingRewardsUi.length > 0 && (
        <div className="mt-2">
          <p className="text-gray-400 text-sm">미청구 보상:</p>
          {position.pendingRewardsUi.map((reward, index) => (
            <p key={index} className="text-xs text-gray-300 ml-2">
              {reward.amount} ({reward.symbol || reward.mint.slice(0, 4)}...)
            </p>
          ))}
        </div>
      )}

      <div className="flex space-x-2 mt-4">
        <button
          className={`bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 text-sm ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          onClick={handleInitiateRemove}
          disabled={isLoading}
        >
          {isLoading ? '해제 처리 중...' : 'LP 해제'}
        </button>
        {/* Placeholder for a more advanced "Remove & Swap" feature */}
        <button
          className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 text-sm opacity-50 cursor-not-allowed"
          onClick={handleRemoveAndSwap}
          disabled={true}
        >
          해제 및 스왑 (개발 중)
        </button>
      </div>

      {showConfirmationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-700 p-6 rounded-lg shadow-xl max-w-md w-full">
            <h4 className="text-lg font-semibold text-white mb-4">LP 해제 확인</h4>
            <p className="text-gray-300 mb-1 text-sm">
              포지션: <span className="font-mono">{position.address.slice(0,8)}...</span>
            </p>
            <p className="text-gray-300 mb-4 text-sm">
              정말로 이 LP 포지션에서 유동성을 해제하시겠습니까?
            </p>

            <div className="mb-4">
              <label htmlFor="bpsToRemove" className="block text-sm font-medium text-gray-300 mb-1">해제 비율 (%):</label>
              <input
                type="number"
                id="bpsToRemove"
                value={bpsToRemove / 100} // Display as percentage
                onChange={(e) => {
                    const percentage = parseFloat(e.target.value);
                    if (!isNaN(percentage) && percentage >=0 && percentage <= 100) {
                        setBpsToRemove(percentage * 100);
                    } else if (e.target.value === '') {
                        setBpsToRemove(0); // Or handle as needed
                    }
                }}
                min="0"
                max="100"
                step="0.01"
                className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div className="mb-6">
              <label className="flex items-center text-gray-300">
                <input
                  type="checkbox"
                  checked={shouldClaimAndClose}
                  onChange={(e) => setShouldClaimAndClose(e.target.checked)}
                  className="mr-2 h-4 w-4 rounded bg-gray-800 border-gray-600 text-blue-500 focus:ring-blue-500"
                />
                수수료 청구 및 포지션 계정 닫기
              </label>
            </div>
            
            {removeError && (
              <p className="text-red-400 text-sm mb-3">오류: {typeof removeError === 'string' ? removeError : removeError.message || '알 수 없는 오류'}</p>
            )}

            <div className="flex justify-end space-x-3">
              <button
                onClick={handleCancelRemove}
                className="px-4 py-2 rounded text-sm font-medium bg-gray-600 hover:bg-gray-500 text-white transition-colors"
                disabled={isLoading}
              >
                취소
              </button>
              <button
                onClick={handleConfirmRemove}
                className={`px-4 py-2 rounded text-sm font-medium bg-red-600 hover:bg-red-700 text-white transition-colors ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={isLoading || bpsToRemove === 0}
              >
                {isLoading ? '처리 중...' : '확인 및 해제'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
