"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { Connection, PublicKey, Transaction, VersionedTransaction, TransactionInstruction, SystemProgram } from '@solana/web3.js';
import * as DLMMSDK from '@meteora-ag/dlmm'; // Import SDK
import api from '@/lib/api'; // Import api client
import { LpPosition } from '@/types/dlmm'; // Import LpPosition type
import LpPositionItem from '@/components/lp/LpPositionItem'; // Import the new component
import useAuthStore from '@/store/authStore'; // Assuming auth store for user info
import { useRouter } from 'next/navigation'; // Assuming next router for navigation

// Obtain the actual Solana Connection object in the frontend context
// Use environment variable for RPC URL
const connection = new Connection(process.env.NEXT_PUBLIC_SOLANA_RPC_URL || 'https://api.devnet.solana.com', 'confirmed'); // Use env variable

export default function DashboardPage() {
  const { publicKey: userPublicKey, connected } = useWallet();
  const { user, isLoggedIn, isLoading: isAuthLoading, logout } = useAuthStore(); // Get user info and logout function
  const router = useRouter();

  const [positions, setPositions] = useState<LpPosition[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [solBalance, setSolBalance] = useState<number | null>(null); // State for SOL balance

  // Redirect if not logged in
  useEffect(() => {
    if (!isAuthLoading && !isLoggedIn) {
      router.replace('/');
    }
  }, [isAuthLoading, isLoggedIn, router]);

  // Fetch SOL balance
  useEffect(() => {
    const fetchSolBalance = async () => {
      if (userPublicKey) {
        try {
          const balance = await connection.getBalance(userPublicKey);
          setSolBalance(balance / 10 ** 9); // Convert lamports to SOL
        } catch (e) {
          console.error("Failed to fetch SOL balance:", e);
          setSolBalance(null);
        }
      } else {
        setSolBalance(null);
      }
    };
    fetchSolBalance();
  }, [userPublicKey, connection]);


  const fetchUserPositions = useCallback(async () => {
    if (!userPublicKey) {
      setPositions([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // TODO: Use SDK function to fetch positions by user
      // Assuming a function like getAllLbPairPositionsByUser exists in the SDK
      console.warn("fetchUserPositions: SDK fetching placeholder.");
      // Example (pseudo-code):
      /*
      const rawPositions = await DLMMSDK.getAllLbPairPositionsByUser(connection, userPublicKey);
      // Need to fetch LbPair and Mint info for each position to create LpPosition objects
      const detailedPositions: LpPosition[] = await Promise.all(rawPositions.map(async (rawPos: any) => {
          const lbPairAccount = await connection.getAccountInfo(rawPos.lb_pair);
          const lbPairState = DLMMSDK.Accounts.LbPairAccount.deserialize(lbPairAccount.data)?.0;

          const tokenXMintAccount = await connection.getAccountInfo(lbPairState.token_x_mint);
          const tokenXMintInfo = DLMMSDK.Accounts.Mint.unpack(tokenXMintAccount.data); // Assuming Mint.unpack exists

          const tokenYMintAccount = await connection.getAccountInfo(lbPairState.token_y_mint);
          const tokenYMintInfo = DLMMSDK.Accounts.Mint.unpack(tokenYMintAccount.data);

          // Fetch prices (can be done once for all unique mints)
          const uniqueMints = new Set([lbPairState.token_x_mint.toBase58(), lbPairState.token_y_mint.toBase58()]);
          // TODO: Fetch reward mints from rawPos.reward_infos and add to uniqueMints
          const pricesInSol = await api.post('/api/dlmm/get-prices', { mints: [...uniqueMints] }); // Assuming a new backend endpoint for prices

          return {
              positionAddress: rawPos.publicKey.toBase58(),
              lbPairAddress: rawPos.lb_pair.toBase58(),
              owner: rawPos.owner.toBase58(),
              lowerBinId: rawPos.lower_bin_id,
              upperBinId: rawPos.upper_bin_id,
              binStep: lbPairState.bin_step,
              tokenXDecimals: tokenXMintInfo.decimals,
              tokenYDecimals: tokenYMintInfo.decimals,
              tokenXMint: lbPairState.token_x_mint.toBase58(),
              tokenYMint: lbPairState.token_y_mint.toBase58(),
              rawPositionData: rawPos,
              rawLbPairData: lbPairState,
              rawTokenXMintData: tokenXMintInfo,
              rawTokenYMintData: tokenYMintInfo,
              pricesInSol: pricesInSol.data, // Assuming backend returns prices in data field
              // Frontend will calculate total amounts, fees, rewards, and value
              liquidityShares: rawPos.liquidity_shares,
              feeInfos: rawPos.fee_infos,
              rewardInfos: rawPos.reward_infos,
              totalClaimedFeeXAmount: rawPos.total_claimed_fee_x_amount,
              totalClaimedFeeYAmount: rawPos.total_claimed_fee_y_amount,
              totalClaimedRewards: rawPos.total_claimed_rewards,
              totalXAmount: 'N/A', // Placeholder, calculated in LpPositionItem
              totalYAmount: 'N/A', // Placeholder, calculated in LpPositionItem
              pendingFeeX: 'N/A', // Placeholder, calculated in LpPositionItem
              pendingFeeY: 'N/A', // Placeholder, calculated in LpPositionItem
              pendingRewards: [], // Placeholder, calculated in LpPositionItem
              totalValueInSol: 'N/A', // Placeholder, calculated in LpPositionItem
              priceRange: 'N/A', // Placeholder, calculated in LpPositionItem
          };
      }));
      setPositions(detailedPositions);
      */

      // Placeholder: Dummy data for display
      const dummyPositions: LpPosition[] = [
          {
              positionAddress: 'Pos1Address...',
              lbPairAddress: 'Pool1Address...',
              owner: userPublicKey.toBase58(),
              lowerBinId: 100,
              upperBinId: 200,
              binStep: 10,
              tokenXDecimals: 6,
              tokenYDecimals: 9,
              tokenXMint: 'TokenX...',
              tokenYMint: 'TokenY...',
              liquidityShares: [BigInt(1000)], feeInfos: [], rewardInfos: [], totalClaimedFeeXAmount: BigInt(0), totalClaimedFeeYAmount: BigInt(0), totalClaimedRewards: [],
              totalXAmount: '100', totalYAmount: '50', pendingFeeX: '1', pendingFeeY: '0.5', pendingRewards: [], totalValueInSol: '0.1', priceRange: '100-200',
              rawPositionData: {} as any, rawLbPairData: {} as any, rawTokenXMintData: {} as any, rawTokenYMintData: {} as any, pricesInSol: {},
          },
           {
              positionAddress: 'Pos2Address...',
              lbPairAddress: 'Pool2Address...',
              owner: userPublicKey.toBase58(),
              lowerBinId: 300,
              upperBinId: 400,
              binStep: 5,
              tokenXDecimals: 6,
              tokenYDecimals: 9,
              tokenXMint: 'TokenA...',
              tokenYMint: 'TokenB...',
              liquidityShares: [BigInt(500)], feeInfos: [], rewardInfos: [], totalClaimedFeeXAmount: BigInt(0), totalClaimedFeeYAmount: BigInt(0), totalClaimedRewards: [],
              totalXAmount: '50', totalYAmount: '25', pendingFeeX: '0.1', pendingFeeY: '0.2', pendingRewards: [], totalValueInSol: '0.05', priceRange: '300-400',
              rawPositionData: {} as any, rawLbPairData: {} as any, rawTokenXMintData: {} as any, rawTokenYMintData: {} as any, pricesInSol: {},
          },
      ];
      setPositions(dummyPositions);


    } catch (e: any) {
      console.error('Error fetching user positions:', e);
      setError(e.message || 'LP 포지션 목록을 불러오는데 실패했습니다.');
    } finally {
      setIsLoading(false);
    }
  }, [userPublicKey, connection]); // Add connection to dependencies

  useEffect(() => {
    if (connected) {
      fetchUserPositions();
    } else {
      setPositions([]);
      setIsLoading(false);
    }
  }, [connected, fetchUserPositions]);

  const handleLogout = useCallback(() => {
      logout(); // Call logout function from auth store
      router.push('/'); // Redirect to home page
  }, [logout, router]);

  const handleExportPrivateKey = useCallback(async () => {
      if (!userPublicKey) {
          setError('Wallet not connected.');
          return;
      }
      setIsLoading(true); // Indicate loading for the export operation
      setError(null);

      try {
          // Call the existing backend endpoint to export the private key
          const response = await api.get('/api/wallet/export-private-key'); // Assuming this endpoint exists and is correct

          if (response.data && response.data.privateKey) {
              // The backend returns the private key as an array of numbers or similar.
              // Convert it back to a Uint8Array or string format if needed.
              const privateKeyBytes = response.data.privateKey; // Assuming it's an array of numbers
              const privateKeyUint8Array = Uint8Array.from(privateKeyBytes);
              // Convert Uint8Array to a Base58 string for display/copy
              const privateKeyBase58 = privateKeyUint8Array.toString(); // Assuming toString() on Uint8Array gives the desired format or needs conversion

              // Format the private key string with square brackets
              const formattedPrivateKey = `[${privateKeyBase58}]`;

              // Use navigator.clipboard.writeText to copy to clipboard
              if (navigator.clipboard && navigator.clipboard.writeText) {
                  await navigator.clipboard.writeText(formattedPrivateKey);
                  alert("경고: 개인 키가 클립보드에 복사되었습니다. 안전한 곳에 보관하세요.");
              } else {
                  // Fallback for browsers that don't support clipboard API
                  alert("경고: 개인 키를 클립보드에 복사할 수 없습니다. 개발 목적으로만 사용하세요.\n\n개인 키: " + formattedPrivateKey);
              }

              // TODO: Implement a more secure way to export the private key (e.g., download file)

          } else {
              throw new Error('Failed to export private key from backend: No private key in response.');
          }
      } catch (e: any) {
          console.error('Error exporting private key:', e);
          setError(e.message || '개인 키 내보내기 중 오류 발생');
      } finally {
          setIsLoading(false); // End loading
      }
  }, [userPublicKey]); // Add dependencies


  const handleRemoveAllLp = useCallback(async () => {
      if (!userPublicKey) {
          setError('Wallet not connected.');
          return;
      }
      setIsLoading(true);
      setError(null);

      try {
          // TODO: Implement transaction building for removing ALL liquidity using frontend SDK
          // This involves:
          // 1. Iterating through all positions in the 'positions' state
          // 2. For each position, building remove liquidity and claim fee instructions
          // 3. Combining instructions into transactions (respecting transaction size limits)
          // 4. Serializing transactions
          // 5. Sending serialized transactions to backend for signing and sending

          console.warn("handleRemoveAllLp: Transaction building placeholder.");

          // Placeholder: Send dummy transactions
          for (const position of positions) {
               const dummyInstruction = new TransactionInstruction({
                    keys: [], programId: SystemProgram.programId, data: Buffer.from([]),
                });
                const latestBlockhash = await connection.getLatestBlockhash('confirmed');
                const dummyTransaction = new Transaction().add(dummyInstruction);
                dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
                dummyTransaction.feePayer = userPublicKey;
                const serializedTransaction = dummyTransaction.serialize({ requireAllSignatures: false, verifySignatures: false }).toString('base64');

                console.log(`Sending dummy remove tx for position ${position.positionAddress}`);
                // await api.post('/api/dlmm/process-transaction', { serializedTransaction }); // Uncomment to send
          }

          alert('모든 LP 포지션 해제 트랜잭션 전송 완료 (더미)');
          // TODO: Refresh position list after transactions are confirmed
          // fetchUserPositions();

      } catch (e: any) {
          console.error('Error removing all liquidity:', e);
          setError(e.message || '모든 LP 포지션 해제 중 오류 발생');
      } finally {
          setIsLoading(false);
      }
  }, [positions, userPublicKey, connection]); // Add dependencies


  const handleRemoveAllLpAndSwap = useCallback(async () => {
       if (!userPublicKey) {
          setError('Wallet not connected.');
          return;
      }
      setIsLoading(true);
      setError(null);

      try {
          // TODO: Implement transaction building for removing ALL liquidity and swapping using frontend SDK
          // This involves:
          // 1. Iterating through all positions
          // 2. For each, building remove liquidity and claim fee instructions
          // 3. Building swap instructions for recovered tokens (requires Jupiter quote)
          // 4. Combining instructions into a single transaction (if possible) or multiple transactions
          // 5. Serializing transactions
          // 6. Sending serialized transactions to backend

          console.warn("handleRemoveAllLpAndSwap: Transaction building placeholder.");

           // Placeholder: Send dummy transactions
          for (const position of positions) {
               const dummyInstruction = new TransactionInstruction({
                    keys: [], programId: SystemProgram.programId, data: Buffer.from([]),
                });
                const latestBlockhash = await connection.getLatestBlockhash('confirmed');
                const dummyTransaction = new Transaction().add(dummyInstruction);
                dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
                dummyTransaction.feePayer = userPublicKey;
                const serializedTransaction = dummyTransaction.serialize({ requireAllSignatures: false, verifySignatures: false }).toString('base64');

                console.log(`Sending dummy remove+swap tx for position ${position.positionAddress}`);
                // await api.post('/api/dlmm/process-transaction', { serializedTransaction }); // Uncomment to send
          }

          alert('모든 LP 포지션 해제 및 스왑 트랜잭션 전송 완료 (더미)');
          // TODO: Refresh position list after transactions are confirmed
          // fetchUserPositions();

      } catch (e: any) {
          console.error('Error removing all liquidity and swapping:', e);
          setError(e.message || '모든 LP 포지션 해제 및 스왑 중 오류 발생');
      } finally {
          setIsLoading(false);
      }
  }, [positions, userPublicKey, connection]); // Add connection to dependencies


  if (!connected) {
    return (
      <div className="container mx-auto p-4 pt-20 text-center text-gray-300">
        <p>지갑을 연결하여 LP 포지션을 확인하세요.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 pt-20">
      <h1 className="text-4xl font-bold text-gray-100 mb-8">대시보드</h1>

      {error && (
        <div className="bg-red-500 text-white p-4 rounded-md mb-4">
          {error}
        </div>
      )}

      {/* Reconstructed original UI elements */}
      <div className="bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8">
          <h2 className="text-2xl font-semibold text-white mb-4">사용자 정보 및 지갑</h2>
          {user && <p>사용자 ID: {user.id}</p>}
          {userPublicKey && <p>지갑 주소: {userPublicKey.toBase58()}</p>}
          {solBalance !== null && <p>SOL 잔액: {solBalance.toFixed(4)}</p>}
          {/* Assuming a button to navigate to LP creation */}
          <div className="flex space-x-4 mt-4">
              <button
                  className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                  onClick={() => router.push('/lp/create')}
              >
                  새 LP 포지션 생성
              </button>
               <button
                  className="bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                  onClick={handleExportPrivateKey}
                  disabled={!userPublicKey || isLoading} // Disable if wallet not connected or loading
              >
                  {isLoading ? '내보내는 중...' : '개인 키 내보내기'}
              </button>
               <button
                  className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                  onClick={handleLogout}
              >
                  로그아웃
              </button>
          </div>
      </div>

      {/* New LP Position List Section */}
      <h2 className="text-2xl font-semibold text-gray-100 mb-4">나의 LP 포지션</h2>

      <div className="mb-4 flex space-x-4">
           <button
              className={`bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              onClick={handleRemoveAllLp}
              disabled={isLoading || positions.length === 0}
            >
              {isLoading ? '정리 중...' : '모든 LP 포지션 한번에 정리하기 (더미)'}
            </button>
             <button
              className={`bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              onClick={handleRemoveAllLpAndSwap}
              disabled={isLoading || positions.length === 0}
            >
              {isLoading ? '정리 및 스왑 중...' : '모든 LP 포지션 한번에 정리 및 SOL로 전부 자동 스왑 (더미)'}
            </button>
      </div>


      {isLoading ? (
        <p className="text-gray-300">LP 포지션을 불러오는 중...</p>
      ) : positions.length === 0 ? (
        <p className="text-gray-300">활성화된 LP 포지션이 없습니다.</p>
      ) : (
        <div className="space-y-4">
          {positions.map(position => (
            <LpPositionItem
              key={position.positionAddress}
              position={position}
              onPositionRemoved={fetchUserPositions} // Refresh list after removal
            />
          ))}
        </div>
      )}
    </div>
  );
}
