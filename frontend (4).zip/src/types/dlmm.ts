// src/types/dlmm.ts

import { PublicKey } from "@solana/web3.js"; // Import PublicKey if needed for raw data types

// Define types for raw SDK account data if passing them to frontend
// These should match the structure deserialized by the SDK
interface RawPositionV2Data {
    lb_pair: PublicKey;
    owner: PublicKey;
    lower_bin_id: number;
    upper_bin_id: number;
    liquidity_shares: bigint[]; // u128 in Rust -> bigint in JS/TS
    fee_infos: any[]; // Define more specific type if needed
    reward_infos: any[]; // Define more specific type if needed
    total_claimed_fee_x_amount: bigint;
    total_claimed_fee_y_amount: bigint;
    total_claimed_rewards: bigint[];
    // Add other relevant PositionV2 fields from SDK
}

interface RawLbPairData {
    address: PublicKey;
    bin_step: number;
    token_x_mint: PublicKey;
    token_y_mint: PublicKey;
    // Add other relevant LbPair fields from SDK
}

interface RawMintData {
    decimals: number;
    // Add other relevant Mint fields from @solana/spl-token
}


// Define the type for the structured position data used in the frontend
export interface LpPosition {
  positionAddress: string;
  lbPairAddress: string;
  owner: string;
  lowerBinId: number;
  upperBinId: number;
  binStep: number; // From LbPair
  tokenXDecimals: number; // From Mint
  tokenYDecimals: number; // From Mint
  tokenXMint: string; // From LbPair
  tokenYMint: string; // From LbPair

  // Data from PositionV2 account (raw or processed)
  liquidityShares: bigint[]; // Raw liquidity shares per bin
  feeInfos: any[]; // Raw fee info per bin
  rewardInfos: any[]; // Raw reward info per bin
  totalClaimedFeeXAmount: bigint;
  totalClaimedFeeYAmount: bigint;
  totalClaimedRewards: bigint[]; // Array of rewards

  // Calculated/Formatted data (Frontend will calculate)
  totalXAmount: string; // Total deposited X amount (UI format)
  totalYAmount: string; // Total deposited Y amount (UI format)
  pendingFeeX: string; // Total pending fee X (UI format)
  pendingFeeY: string; // Total pending fee Y (UI format)
  pendingRewards: { amount: string; mint: string }[]; // Total pending rewards (UI format)
  totalValueInSol: string; // Total value of position in SOL (UI format)
  priceRange: string; // Formatted price range (UI format)

  // Raw data for potential detailed view or transaction building
  rawPositionData: RawPositionV2Data;
  rawLbPairData: RawLbPairData;
  rawTokenXMintData: RawMintData;
  rawTokenYMintData: RawMintData;
  pricesInSol: { [mintAddress: string]: number }; // Prices fetched by backend/frontend
}

// 필요하다면 다른 DLMM 관련 타입들도 여기에 정의할 수 있습니다.
// 예: interface DlmmPoolInfo { ... }
