module.exports = {

"[project]/src/components/lp/LpPositionItem.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>LpPositionItem)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)"); // Import necessary Solana types, added SystemProgram, Connection
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react/lib/esm/useWallet.js [app-ssr] (ecmascript)"); // Assuming wallet adapter is used on frontend
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-ssr] (ecmascript)"); // Correct default import for api client
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/decimal.js/decimal.mjs [app-ssr] (ecmascript)"); // For calculations
;
;
;
;
;
;
// Helper to convert lamports to UI amount (can be shared or defined here)
function lamportsToUiAmount(lamports, decimals) {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return '0';
    try {
        const amountDecimal = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](lamports.toString()).div(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](10).pow(decimals));
        return amountDecimal.toFixed(Math.min(decimals, 6)); // Example: show up to 6 decimals
    } catch (e) {
        console.error("Error formatting amount:", e);
        return 'Error';
    }
}
// Helper to calculate total amounts from liquidity shares (Frontend logic)
function calculateTotalAmounts(position) {
    let totalX = BigInt(0);
    let totalY = BigInt(0);
    // This requires fetching BinArray accounts and using the SDK's math to convert liquidity shares to amounts.
    // This is complex and will be a placeholder for now to keep the file concise.
    // TODO: Implement actual calculation using SDK and fetched BinArray data.
    console.warn("calculateTotalAmounts: Placeholder implementation. Requires fetching BinArray data.");
    return {
        totalX: BigInt(0),
        totalY: BigInt(0)
    };
}
// Helper to calculate pending fees (Frontend logic)
function calculatePendingFees(position) {
    let pendingX = BigInt(0);
    let pendingY = BigInt(0);
    // This requires iterating through fee_infos and summing up pending fees.
    // TODO: Implement actual calculation.
    console.warn("calculatePendingFees: Placeholder implementation.");
    return {
        pendingX: BigInt(0),
        pendingY: BigInt(0)
    };
}
// Helper to calculate pending rewards (Frontend logic)
function calculatePendingRewards(position) {
    // This requires iterating through reward_infos and summing up pending rewards per mint.
    // TODO: Implement actual calculation.
    console.warn("calculatePendingRewards: Placeholder implementation.");
    return [];
}
// Helper to calculate total value in SOL (Frontend logic)
function calculateTotalValueInSol(position) {
    // This requires total X and Y amounts and their prices in SOL.
    // TODO: Implement actual calculation using total amounts and pricesInSol.
    console.warn("calculateTotalValueInSol: Placeholder implementation.");
    return 'N/A';
}
// Helper to format price range (Frontend logic)
function formatPriceRange(position) {
    // This requires binStep, lowerBinId, upperBinId and potentially token decimals.
    // TODO: Implement actual formatting using SDK price math.
    console.warn("formatPriceRange: Placeholder implementation.");
    return `${position.lowerBinId} - ${position.upperBinId}`;
}
function LpPositionItem({ position, onPositionRemoved }) {
    const { publicKey: userPublicKey, signTransaction, sendTransaction } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useWallet"])(); // Assuming wallet adapter hooks
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // TODO: Obtain the actual Solana Connection object in the frontend context
    const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"]('https://api.devnet.solana.com', 'confirmed'); // Placeholder
    // Calculated values (placeholders for now)
    const { totalX: totalXAmountLamports, totalY: totalYAmountLamports } = calculateTotalAmounts(position);
    const { pendingX: pendingFeeXLamports, pendingY: pendingFeeYLamports } = calculatePendingFees(position);
    const pendingRewards = calculatePendingRewards(position);
    const totalValueInSol = calculateTotalValueInSol(position);
    const priceRange = formatPriceRange(position);
    // Formatted amounts (using placeholder calculations)
    const totalXAmountUi = lamportsToUiAmount(totalXAmountLamports, position.tokenXDecimals);
    const totalYAmountUi = lamportsToUiAmount(totalYAmountLamports, position.tokenYDecimals);
    const pendingFeeXUi = lamportsToUiAmount(pendingFeeXLamports, position.tokenXDecimals);
    const pendingFeeYUi = lamportsToUiAmount(pendingFeeYLamports, position.tokenYDecimals); // Corrected typo
    const pendingRewardsUi = pendingRewards.map((r)=>({
            amount: lamportsToUiAmount(r.amount, position.pricesInSol[r.mint] ? 6 : 0),
            mint: r.mint
        }));
    const handleRemoveLiquidity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey || !signTransaction) {
            setError('Wallet not connected or signing not supported.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building using frontend SDK
            // This involves:
            // 1. Fetching necessary accounts (LbPair, Position, BinArrays, ATAs, etc.)
            // 2. Using SDK functions (e.g., DLMMSDK.Instructions.RemoveLiquidity2Instruction.build) to create instructions
            // 3. Building a Transaction or VersionedTransaction
            // 4. Getting the latest blockhash using the frontend connection object
            // 5. Setting fee payer and blockhash
            // 6. Serializing the transaction
            console.warn("handleRemoveLiquidity: Transaction building placeholder.");
            // Placeholder: Create a dummy transaction for demonstration
            const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                keys: [],
                programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                data: Buffer.from([])
            });
            const latestBlockhash = await connection.getLatestBlockhash('confirmed'); // Use frontend connection
            const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
            dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
            dummyTransaction.feePayer = userPublicKey;
            const serializedTransaction = dummyTransaction.serialize({
                requireAllSignatures: false,
                verifySignatures: false
            }).toString('base64');
            // Send serialized transaction to backend for signing and sending
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/process-transaction', {
                serializedTransaction
            });
            if (response.data && response.data.signature) {
                alert(`LP 해제 성공! 서명: ${response.data.signature}`);
                onPositionRemoved(position.positionAddress); // Notify parent component
            } else {
                throw new Error('Transaction failed on backend.');
            }
        } catch (e) {
            console.error('Error removing liquidity:', e);
            setError(e.message || 'LP 해제 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        position,
        userPublicKey,
        signTransaction,
        onPositionRemoved,
        connection
    ]); // Add connection to dependencies
    const handleRemoveAndSwap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey || !signTransaction) {
            setError('Wallet not connected or signing not supported.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building for remove + swap using frontend SDK
            // This involves:
            // 1. Building remove liquidity and claim fee instructions (similar to handleRemoveLiquidity)
            // 2. Building swap instructions using SDK (requires Jupiter quote)
            // 3. Combining instructions into a single transaction (if possible) or multiple transactions
            // 4. Getting the latest blockhash using the frontend connection object
            // 5. Setting fee payer and blockhash
            // 6. Serializing transaction(s)
            console.warn("handleRemoveAndSwap: Transaction building placeholder.");
            // Placeholder: Create a dummy transaction
            const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                keys: [],
                programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                data: Buffer.from([])
            });
            const latestBlockhash = await connection.getLatestBlockhash('confirmed'); // Use frontend connection
            const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
            dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
            dummyTransaction.feePayer = userPublicKey;
            const serializedTransaction = dummyTransaction.serialize({
                requireAllSignatures: false,
                verifySignatures: false
            }).toString('base64');
            // Send serialized transaction(s) to backend
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/process-transaction', {
                serializedTransaction
            });
            if (response.data && response.data.signature) {
                alert(`LP 해제 및 스왑 성공! 서명: ${response.data.signature}`);
                onPositionRemoved(position.positionAddress); // Notify parent component
            } else {
                throw new Error('Transaction failed on backend.');
            }
        } catch (e) {
            console.error('Error removing liquidity and swapping:', e);
            setError(e.message || 'LP 해제 및 스왑 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        position,
        userPublicKey,
        signTransaction,
        onPositionRemoved,
        connection
    ]); // Add connection to dependencies
    // TODO: Fetch BinArray data and perform actual calculations in useEffect
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Fetch BinArray accounts for position.lowerBinId to position.upperBinId
        // Use SDK functions to calculate total amounts, fees, rewards from rawPositionData and BinArray data
        // Update state with calculated/formatted values
        console.log(`Fetching BinArray data for position ${position.positionAddress} bins ${position.lowerBinId}-${position.upperBinId}`);
    // This requires access to the SDK's fetching and calculation logic on the frontend.
    // Example (pseudo-code):
    /*
      async function fetchAndCalculate() {
          try {
              // Assuming DLMMSDK.Accounts.PositionV2Account and DLMMSDK.Utils.getBinArrayPubkeysForPosition exist
              const positionAccount = await connection.getAccountInfo(new PublicKey(position.positionAddress)); // Use frontend connection
              if (!positionAccount) throw new Error("Position account not found");
              const positionState = DLMMSDK.Accounts.PositionV2Account.deserialize(positionAccount.data)?.0;
              if (!positionState) throw new Error("Failed to deserialize position account");

              const binArrayPubkeys = DLMMSDK.Utils.getBinArrayPubkeysForPosition(new PublicKey(position.lbPairAddress), position.lowerBinId, position.upperBinId);
              const binArrayAccounts = await connection.getMultipleAccountsInfo(binArrayPubkeys); // Use frontend connection
              // Deserialize binArrayAccounts and use SDK math to calculate amounts, fees, rewards
              // Update state
          } catch (e) {
              console.error("Failed to fetch bin arrays or calculate:", e);
          }
      }
      fetchAndCalculate();
      */ }, [
        position,
        connection
    ]); // Re-run effect if position data changes or connection changes
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-gray-800 p-4 rounded-lg mb-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-lg font-semibold text-white mb-2",
                children: [
                    "LP 포지션: ",
                    position.positionAddress.slice(0, 6),
                    "...",
                    position.positionAddress.slice(-6)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 238,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "풀: ",
                    position.lbPairAddress.slice(0, 6),
                    "...",
                    position.lbPairAddress.slice(-6)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 239,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "가격 범위: ",
                    priceRange
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 240,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "총 가치 (SOL): ",
                    totalValueInSol
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 241,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "예치 금액: ",
                    totalXAmountUi,
                    " (",
                    position.tokenXMint.slice(0, 4),
                    "...) / ",
                    totalYAmountUi,
                    " (",
                    position.tokenYMint.slice(0, 4),
                    "...)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 242,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "미청구 수수료: ",
                    pendingFeeXUi,
                    " (",
                    position.tokenXMint.slice(0, 4),
                    "...) / ",
                    pendingFeeYUi,
                    " (",
                    position.tokenYMint.slice(0, 4),
                    "...)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 243,
                columnNumber: 7
            }, this),
            pendingRewardsUi.map((reward, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-300",
                    children: [
                        "미청구 보상 ",
                        index + 1,
                        ": ",
                        reward.amount,
                        " (",
                        reward.mint.slice(0, 4),
                        "...)"
                    ]
                }, index, true, {
                    fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                    lineNumber: 245,
                    columnNumber: 11
                }, this)),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-2 rounded-md mt-4 text-sm",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 250,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex space-x-2 mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveLiquidity,
                        disabled: isLoading,
                        children: isLoading ? '해제 중...' : 'LP 해제'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                        lineNumber: 256,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAndSwap,
                        disabled: isLoading,
                        children: isLoading ? '해제 및 스왑 중...' : 'LP 해제 및 자동 스왑'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                        lineNumber: 263,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 255,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
        lineNumber: 237,
        columnNumber: 5
    }, this);
}
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/dashboard/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DashboardPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react/lib/esm/useWallet.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-ssr] (ecmascript)"); // Import api client
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$LpPositionItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/lp/LpPositionItem.tsx [app-ssr] (ecmascript)"); // Import the new component
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/authStore.ts [app-ssr] (ecmascript)"); // Assuming auth store for user info
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)"); // Assuming next router for navigation
"use client";
;
;
;
;
;
;
;
;
// Obtain the actual Solana Connection object in the frontend context
// Use environment variable for RPC URL
const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com', 'confirmed'); // Use env variable
function DashboardPage() {
    const { publicKey: userPublicKey, connected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useWallet"])();
    const { user, isLoggedIn, isLoading: isAuthLoading, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(); // Get user info and logout function
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [positions, setPositions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [solBalance, setSolBalance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null); // State for SOL balance
    // Redirect if not logged in
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!isAuthLoading && !isLoggedIn) {
            router.replace('/');
        }
    }, [
        isAuthLoading,
        isLoggedIn,
        router
    ]);
    // Fetch SOL balance
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchSolBalance = async ()=>{
            if (userPublicKey) {
                try {
                    const balance = await connection.getBalance(userPublicKey);
                    setSolBalance(balance / 10 ** 9); // Convert lamports to SOL
                } catch (e) {
                    console.error("Failed to fetch SOL balance:", e);
                    setSolBalance(null);
                }
            } else {
                setSolBalance(null);
            }
        };
        fetchSolBalance();
    }, [
        userPublicKey,
        connection
    ]);
    const fetchUserPositions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setPositions([]);
            setIsLoading(false);
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Use SDK function to fetch positions by user
            // Assuming a function like getAllLbPairPositionsByUser exists in the SDK
            console.warn("fetchUserPositions: SDK fetching placeholder.");
            // Example (pseudo-code):
            /*
      const rawPositions = await DLMMSDK.getAllLbPairPositionsByUser(connection, userPublicKey);
      // Need to fetch LbPair and Mint info for each position to create LpPosition objects
      const detailedPositions: LpPosition[] = await Promise.all(rawPositions.map(async (rawPos: any) => {
          const lbPairAccount = await connection.getAccountInfo(rawPos.lb_pair);
          const lbPairState = DLMMSDK.Accounts.LbPairAccount.deserialize(lbPairAccount.data)?.0;

          const tokenXMintAccount = await connection.getAccountInfo(lbPairState.token_x_mint);
          const tokenXMintInfo = DLMMSDK.Accounts.Mint.unpack(tokenXMintAccount.data); // Assuming Mint.unpack exists

          const tokenYMintAccount = await connection.getAccountInfo(lbPairState.token_y_mint);
          const tokenYMintInfo = DLMMSDK.Accounts.Mint.unpack(tokenYMintAccount.data);

          // Fetch prices (can be done once for all unique mints)
          const uniqueMints = new Set([lbPairState.token_x_mint.toBase58(), lbPairState.token_y_mint.toBase58()]);
          // TODO: Fetch reward mints from rawPos.reward_infos and add to uniqueMints
          const pricesInSol = await api.post('/api/dlmm/get-prices', { mints: [...uniqueMints] }); // Assuming a new backend endpoint for prices

          return {
              positionAddress: rawPos.publicKey.toBase58(),
              lbPairAddress: rawPos.lb_pair.toBase58(),
              owner: rawPos.owner.toBase58(),
              lowerBinId: rawPos.lower_bin_id,
              upperBinId: rawPos.upper_bin_id,
              binStep: lbPairState.bin_step,
              tokenXDecimals: tokenXMintInfo.decimals,
              tokenYDecimals: tokenYMintInfo.decimals,
              tokenXMint: lbPairState.token_x_mint.toBase58(),
              tokenYMint: lbPairState.token_y_mint.toBase58(),
              rawPositionData: rawPos,
              rawLbPairData: lbPairState,
              rawTokenXMintData: tokenXMintInfo,
              rawTokenYMintData: tokenYMintInfo,
              pricesInSol: pricesInSol.data, // Assuming backend returns prices in data field
              // Frontend will calculate total amounts, fees, rewards, and value
              liquidityShares: rawPos.liquidity_shares,
              feeInfos: rawPos.fee_infos,
              rewardInfos: rawPos.reward_infos,
              totalClaimedFeeXAmount: rawPos.total_claimed_fee_x_amount,
              totalClaimedFeeYAmount: rawPos.total_claimed_fee_y_amount,
              totalClaimedRewards: rawPos.total_claimed_rewards,
              totalXAmount: 'N/A', // Placeholder, calculated in LpPositionItem
              totalYAmount: 'N/A', // Placeholder, calculated in LpPositionItem
              pendingFeeX: 'N/A', // Placeholder, calculated in LpPositionItem
              pendingFeeY: 'N/A', // Placeholder, calculated in LpPositionItem
              pendingRewards: [], // Placeholder, calculated in LpPositionItem
              totalValueInSol: 'N/A', // Placeholder, calculated in LpPositionItem
              priceRange: 'N/A', // Placeholder, calculated in LpPositionItem
          };
      }));
      setPositions(detailedPositions);
      */ // Placeholder: Dummy data for display
            const dummyPositions = [
                {
                    positionAddress: 'Pos1Address...',
                    lbPairAddress: 'Pool1Address...',
                    owner: userPublicKey.toBase58(),
                    lowerBinId: 100,
                    upperBinId: 200,
                    binStep: 10,
                    tokenXDecimals: 6,
                    tokenYDecimals: 9,
                    tokenXMint: 'TokenX...',
                    tokenYMint: 'TokenY...',
                    liquidityShares: [
                        BigInt(1000)
                    ],
                    feeInfos: [],
                    rewardInfos: [],
                    totalClaimedFeeXAmount: BigInt(0),
                    totalClaimedFeeYAmount: BigInt(0),
                    totalClaimedRewards: [],
                    totalXAmount: '100',
                    totalYAmount: '50',
                    pendingFeeX: '1',
                    pendingFeeY: '0.5',
                    pendingRewards: [],
                    totalValueInSol: '0.1',
                    priceRange: '100-200',
                    rawPositionData: {},
                    rawLbPairData: {},
                    rawTokenXMintData: {},
                    rawTokenYMintData: {},
                    pricesInSol: {}
                },
                {
                    positionAddress: 'Pos2Address...',
                    lbPairAddress: 'Pool2Address...',
                    owner: userPublicKey.toBase58(),
                    lowerBinId: 300,
                    upperBinId: 400,
                    binStep: 5,
                    tokenXDecimals: 6,
                    tokenYDecimals: 9,
                    tokenXMint: 'TokenA...',
                    tokenYMint: 'TokenB...',
                    liquidityShares: [
                        BigInt(500)
                    ],
                    feeInfos: [],
                    rewardInfos: [],
                    totalClaimedFeeXAmount: BigInt(0),
                    totalClaimedFeeYAmount: BigInt(0),
                    totalClaimedRewards: [],
                    totalXAmount: '50',
                    totalYAmount: '25',
                    pendingFeeX: '0.1',
                    pendingFeeY: '0.2',
                    pendingRewards: [],
                    totalValueInSol: '0.05',
                    priceRange: '300-400',
                    rawPositionData: {},
                    rawLbPairData: {},
                    rawTokenXMintData: {},
                    rawTokenYMintData: {},
                    pricesInSol: {}
                }
            ];
            setPositions(dummyPositions);
        } catch (e) {
            console.error('Error fetching user positions:', e);
            setError(e.message || 'LP 포지션 목록을 불러오는데 실패했습니다.');
        } finally{
            setIsLoading(false);
        }
    }, [
        userPublicKey,
        connection
    ]); // Add connection to dependencies
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (connected) {
            fetchUserPositions();
        } else {
            setPositions([]);
            setIsLoading(false);
        }
    }, [
        connected,
        fetchUserPositions
    ]);
    const handleLogout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        logout(); // Call logout function from auth store
        router.push('/'); // Redirect to home page
    }, [
        logout,
        router
    ]);
    const handleExportPrivateKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setError('Wallet not connected.');
            return;
        }
        setIsLoading(true); // Indicate loading for the export operation
        setError(null);
        try {
            // Call the existing backend endpoint to export the private key
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/api/wallet/export-private-key'); // Assuming this endpoint exists and is correct
            if (response.data && response.data.privateKey) {
                // The backend returns the private key as an array of numbers or similar.
                // Convert it back to a Uint8Array or string format if needed.
                const privateKeyBytes = response.data.privateKey; // Assuming it's an array of numbers
                const privateKeyUint8Array = Uint8Array.from(privateKeyBytes);
                // Convert Uint8Array to a Base58 string for display/copy
                const privateKeyBase58 = privateKeyUint8Array.toString(); // Assuming toString() on Uint8Array gives the desired format or needs conversion
                // Format the private key string with square brackets
                const formattedPrivateKey = `[${privateKeyBase58}]`;
                // Use navigator.clipboard.writeText to copy to clipboard
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    await navigator.clipboard.writeText(formattedPrivateKey);
                    alert("경고: 개인 키가 클립보드에 복사되었습니다. 안전한 곳에 보관하세요.");
                } else {
                    // Fallback for browsers that don't support clipboard API
                    alert("경고: 개인 키를 클립보드에 복사할 수 없습니다. 개발 목적으로만 사용하세요.\n\n개인 키: " + formattedPrivateKey);
                }
            // TODO: Implement a more secure way to export the private key (e.g., download file)
            } else {
                throw new Error('Failed to export private key from backend: No private key in response.');
            }
        } catch (e) {
            console.error('Error exporting private key:', e);
            setError(e.message || '개인 키 내보내기 중 오류 발생');
        } finally{
            setIsLoading(false); // End loading
        }
    }, [
        userPublicKey
    ]); // Add dependencies
    const handleRemoveAllLp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setError('Wallet not connected.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building for removing ALL liquidity using frontend SDK
            // This involves:
            // 1. Iterating through all positions in the 'positions' state
            // 2. For each position, building remove liquidity and claim fee instructions
            // 3. Combining instructions into transactions (respecting transaction size limits)
            // 4. Serializing transactions
            // 5. Sending serialized transactions to backend for signing and sending
            console.warn("handleRemoveAllLp: Transaction building placeholder.");
            // Placeholder: Send dummy transactions
            for (const position of positions){
                const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                    keys: [],
                    programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                    data: Buffer.from([])
                });
                const latestBlockhash = await connection.getLatestBlockhash('confirmed');
                const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
                dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
                dummyTransaction.feePayer = userPublicKey;
                const serializedTransaction = dummyTransaction.serialize({
                    requireAllSignatures: false,
                    verifySignatures: false
                }).toString('base64');
                console.log(`Sending dummy remove tx for position ${position.positionAddress}`);
            // await api.post('/api/dlmm/process-transaction', { serializedTransaction }); // Uncomment to send
            }
            alert('모든 LP 포지션 해제 트랜잭션 전송 완료 (더미)');
        // TODO: Refresh position list after transactions are confirmed
        // fetchUserPositions();
        } catch (e) {
            console.error('Error removing all liquidity:', e);
            setError(e.message || '모든 LP 포지션 해제 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        positions,
        userPublicKey,
        connection
    ]); // Add dependencies
    const handleRemoveAllLpAndSwap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setError('Wallet not connected.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building for removing ALL liquidity and swapping using frontend SDK
            // This involves:
            // 1. Iterating through all positions
            // 2. For each, building remove liquidity and claim fee instructions
            // 3. Building swap instructions for recovered tokens (requires Jupiter quote)
            // 4. Combining instructions into a single transaction (if possible) or multiple transactions
            // 5. Serializing transactions
            // 6. Sending serialized transactions to backend
            console.warn("handleRemoveAllLpAndSwap: Transaction building placeholder.");
            // Placeholder: Send dummy transactions
            for (const position of positions){
                const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                    keys: [],
                    programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                    data: Buffer.from([])
                });
                const latestBlockhash = await connection.getLatestBlockhash('confirmed');
                const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
                dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
                dummyTransaction.feePayer = userPublicKey;
                const serializedTransaction = dummyTransaction.serialize({
                    requireAllSignatures: false,
                    verifySignatures: false
                }).toString('base64');
                console.log(`Sending dummy remove+swap tx for position ${position.positionAddress}`);
            // await api.post('/api/dlmm/process-transaction', { serializedTransaction }); // Uncomment to send
            }
            alert('모든 LP 포지션 해제 및 스왑 트랜잭션 전송 완료 (더미)');
        // TODO: Refresh position list after transactions are confirmed
        // fetchUserPositions();
        } catch (e) {
            console.error('Error removing all liquidity and swapping:', e);
            setError(e.message || '모든 LP 포지션 해제 및 스왑 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        positions,
        userPublicKey,
        connection
    ]); // Add connection to dependencies
    if (!connected) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto p-4 pt-20 text-center text-gray-300",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "지갑을 연결하여 LP 포지션을 확인하세요."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 323,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/page.tsx",
            lineNumber: 322,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto p-4 pt-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-4xl font-bold text-gray-100 mb-8",
                children: "대시보드"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 330,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-4 rounded-md mb-4",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 333,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-4",
                        children: "사용자 정보 및 지갑"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 340,
                        columnNumber: 11
                    }, this),
                    user && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "사용자 ID: ",
                            user.id
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 341,
                        columnNumber: 20
                    }, this),
                    userPublicKey && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "지갑 주소: ",
                            userPublicKey.toBase58()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 342,
                        columnNumber: 29
                    }, this),
                    solBalance !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "SOL 잔액: ",
                            solBalance.toFixed(4)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 343,
                        columnNumber: 35
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex space-x-4 mt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: ()=>router.push('/lp/create'),
                                children: "새 LP 포지션 생성"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 346,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: handleExportPrivateKey,
                                disabled: !userPublicKey || isLoading,
                                children: isLoading ? '내보내는 중...' : '개인 키 내보내기'
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 352,
                                columnNumber: 16
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: handleLogout,
                                children: "로그아웃"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 359,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 345,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 339,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-gray-100 mb-4",
                children: "나의 LP 포지션"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 369,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 flex space-x-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAllLp,
                        disabled: isLoading || positions.length === 0,
                        children: isLoading ? '정리 중...' : '모든 LP 포지션 한번에 정리하기 (더미)'
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 372,
                        columnNumber: 12
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAllLpAndSwap,
                        disabled: isLoading || positions.length === 0,
                        children: isLoading ? '정리 및 스왑 중...' : '모든 LP 포지션 한번에 정리 및 SOL로 전부 자동 스왑 (더미)'
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 379,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 371,
                columnNumber: 7
            }, this),
            isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: "LP 포지션을 불러오는 중..."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 390,
                columnNumber: 9
            }, this) : positions.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: "활성화된 LP 포지션이 없습니다."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 392,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: positions.map((position)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$LpPositionItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        position: position,
                        onPositionRemoved: fetchUserPositions
                    }, position.positionAddress, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 396,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 394,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/page.tsx",
        lineNumber: 329,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__ba9bf2b9._.js.map