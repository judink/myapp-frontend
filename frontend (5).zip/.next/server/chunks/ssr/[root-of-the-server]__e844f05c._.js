module.exports = {

"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/process [external] (process, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}}),
"[project]/src/hooks/useDlmmPositions.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "useDlmmPositions": (()=>useDlmmPositions)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meteora$2d$ag$2f$dlmm$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meteora-ag/dlmm/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bn.js/lib/bn.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/decimal.js/decimal.mjs [app-ssr] (ecmascript)"); // Assuming Decimal.js is used for calculations
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/spl-token/lib/esm/state/mint.js [app-ssr] (ecmascript)"); // Import getMint
;
;
;
;
;
;
;
// Configuration options (adapted for frontend environment variables)
const CONFIG = {
    SOL_TOKEN_ADDRESS: "So11111111111111111111111111111111111111112",
    RANGE_BAR_WIDTH: 20,
    UPDATE_INTERVAL: 60000,
    ERROR_RETRY_DELAY: 5000,
    RPC_ENDPOINT: ("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com'
};
// Helper function to get token price from Jupiter API
async function getTokenPrice(tokenMint) {
    if (!tokenMint) {
        console.error('getTokenPrice: tokenMint is undefined or null');
        return 0;
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`https://api.jup.ag/price/v2?ids=${tokenMint}`);
        return response.data.data[tokenMint]?.price ? parseFloat(response.data.data[tokenMint].price) : 0;
    } catch (error) {
        console.error('Error fetching price:', error);
        return 0;
    }
}
// Helper function to get token name from Gecko Terminal
async function getTokenName(tokenMint) {
    if (!tokenMint) {
        console.error('getTokenName: tokenMint is undefined or null');
        return tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token';
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`https://api.geckoterminal.com/api/v2/networks/solana/tokens/${tokenMint}`);
        return response.data.data?.attributes?.name || (tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token');
    } catch (error) {
        console.error('Error fetching token name:', error);
        return tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token';
    }
}
// Helper function to convert lamports to token amount
function lamportsToTokenAmount(lamports, decimals) {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return 0;
    try {
        const divisor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](10).pow(decimals);
        const amountDecimal = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](lamports.toString()).div(divisor);
        return amountDecimal.toNumber();
    } catch (err) {
        console.error('Error in lamportsToTokenAmount:', err);
        return 0;
    }
}
// Helper function to fetch initial deposit information
async function getInitialDeposit(positionAddress) {
    if (!positionAddress) {
        console.error('getInitialDeposit: positionAddress is undefined or null');
        return null;
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`https://dlmm-api.meteora.ag/position/${positionAddress}/deposits`);
        const deposits = response.data;
        if (deposits && deposits.length > 0) {
            const deposit = deposits[0]; // Get the first deposit
            const timestamp = new Date(deposit.onchain_timestamp * 1000).toLocaleString();
            return {
                tokenXAmount: deposit.token_x_amount,
                tokenYAmount: deposit.token_y_amount,
                tokenXUsdAmount: deposit.token_x_usd_amount,
                tokenYUsdAmount: deposit.token_y_usd_amount,
                timestamp: timestamp,
                price: deposit.price,
                onchain_timestamp: deposit.onchain_timestamp
            };
        }
        return null;
    } catch (error) {
        console.error('Error fetching deposit information:', error);
        return null;
    }
}
// Helper function to get current dynamic fee
async function getCurrentDynamicFee(poolAddress) {
    if (!poolAddress) {
        console.error('getCurrentDynamicFee: poolAddress is undefined or null');
        return null;
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`https://dlmm-api.meteora.ag/pair/${poolAddress}`);
        const data = response.data;
        const baseFee = parseFloat(data.base_fee_percentage);
        // const maxFee = parseFloat(data.max_fee_percentage); // Not used in original logic
        return baseFee;
    } catch (error) {
        console.error('Error fetching dynamic fee:', error);
        return null;
    }
}
const useDlmmPositions = (userPublicKey)=>{
    const [positions, setPositions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [totalSummary, setTotalSummary] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        totalLiquidityValue: 0,
        totalClaimedFees: 0,
        totalUnclaimedFees: 0,
        totalPositions: 0,
        inRangePositions: 0,
        totalInitialValue: 0,
        totalPnL: 0,
        totalPnLPercentage: 0
    });
    const fetchPositions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setPositions([]);
            setIsLoading(false);
            return;
        }
        setIsLoading(true);
        setError(null);
        const fetchedPositions = [];
        let totalLiquidityValue = 0;
        let totalClaimedFees = 0;
        let totalUnclaimedFees = 0;
        let totalPositions = 0;
        let inRangePositions = 0;
        let totalInitialValue = 0;
        try {
            const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](CONFIG.RPC_ENDPOINT, 'confirmed');
            const userPositionsMap = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meteora$2d$ag$2f$dlmm$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getAllLbPairPositionsByUser(connection, userPublicKey);
            if (userPositionsMap.size === 0) {
                setPositions([]);
                setIsLoading(false);
                setTotalSummary({
                    totalLiquidityValue: 0,
                    totalClaimedFees: 0,
                    totalUnclaimedFees: 0,
                    totalPositions: 0,
                    inRangePositions: 0,
                    totalInitialValue: 0,
                    totalPnL: 0,
                    totalPnLPercentage: 0
                });
                return;
            }
            for (const [poolAddress, _] of userPositionsMap.entries()){
                try {
                    const dlmmPool = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meteora$2d$ag$2f$dlmm$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create(connection, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PublicKey"](poolAddress));
                    const activeBin = await dlmmPool.getActiveBin();
                    const currentBinId = activeBin.binId;
                    const { userPositions: poolPositions } = await dlmmPool.getPositionsByUserAndLbPair(userPublicKey);
                    const tokenXPrice = await getTokenPrice(dlmmPool.tokenX.publicKey.toString());
                    const tokenYPrice = await getTokenPrice(dlmmPool.tokenY.publicKey.toString());
                    // Fetch decimals using mint addresses if not available on dlmmPool object
                    let tokenXDecimals = dlmmPool.tokenX.decimal;
                    let tokenYDecimals = dlmmPool.tokenY.decimal;
                    if (tokenXDecimals === undefined || tokenXDecimals === null || tokenYDecimals === undefined || tokenYDecimals === null) {
                        try {
                            const tokenXMintInfo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getMint"])(connection, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PublicKey"](dlmmPool.tokenX.publicKey));
                            const tokenYMintInfo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getMint"])(connection, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PublicKey"](dlmmPool.tokenY.publicKey));
                            tokenXDecimals = tokenXMintInfo.decimals;
                            tokenYDecimals = tokenYMintInfo.decimals;
                        } catch (decimalError) {
                            console.error('Error fetching token decimals:', decimalError);
                            // Fallback to a default or handle error appropriately
                            tokenXDecimals = 0; // Or some default
                            tokenYDecimals = 0; // Or some default
                        }
                    }
                    for (const positionDetails of poolPositions){
                        totalPositions++;
                        const { positionData } = positionDetails;
                        const isInRange = currentBinId >= positionData.lowerBinId && currentBinId <= positionData.upperBinId;
                        if (isInRange) inRangePositions++;
                        // Ensure amounts are treated as BN before converting to number
                        const xAmountBN = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].isBN(positionData.totalXAmount) ? positionData.totalXAmount : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.totalXAmount.toString());
                        const yAmountBN = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].isBN(positionData.totalYAmount) ? positionData.totalYAmount : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.totalYAmount.toString());
                        const tokenXAmount = lamportsToTokenAmount(xAmountBN, tokenXDecimals);
                        const tokenYAmount = lamportsToTokenAmount(yAmountBN, tokenYDecimals);
                        const tokenXValue = tokenXAmount * tokenXPrice;
                        const tokenYValue = tokenYAmount * tokenYPrice;
                        // Access fee properties, using type assertion or checking for existence
                        const claimedXAmount = lamportsToTokenAmount(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.totalClaimedFeeXAmount?.toString() || '0'), tokenXDecimals);
                        const claimedYAmount = lamportsToTokenAmount(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.totalClaimedFeeYAmount?.toString() || '0'), tokenYDecimals);
                        const claimableXAmount = lamportsToTokenAmount(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.feeX?.toString() || '0'), tokenXDecimals);
                        const claimableYAmount = lamportsToTokenAmount(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.feeY?.toString() || '0'), tokenYDecimals);
                        console.log(`Position ${positionDetails.publicKey.toString()}:`);
                        console.log(`  Raw Fee X: ${positionData.feeX?.toString() || '0'}, Raw Fee Y: ${positionData.feeY?.toString() || '0'}`);
                        console.log(`  Decimals X: ${tokenXDecimals}, Decimals Y: ${tokenYDecimals}`);
                        console.log(`  Claimable UI X: ${claimableXAmount}, Claimable UI Y: ${claimableYAmount}`);
                        console.log(`  Token X Price: ${tokenXPrice}, Token Y Price: ${tokenYPrice}`);
                        const positionValue = tokenXValue + tokenYValue;
                        const claimedValue = claimedXAmount * tokenXPrice + claimedYAmount * tokenYPrice;
                        const unclaimedValue = claimableXAmount * tokenXPrice + claimableYAmount * tokenYPrice;
                        const totalCurrentValueForPosition = positionValue + claimedValue + unclaimedValue; // Renamed to avoid scope conflict
                        console.log(`  Unclaimed Value for Position: ${unclaimedValue}`);
                        totalLiquidityValue += positionValue;
                        totalClaimedFees += claimedValue;
                        totalUnclaimedFees += unclaimedValue;
                        console.log(`  Running Total Unclaimed Fees: ${totalUnclaimedFees}`);
                        const depositInfo = await getInitialDeposit(positionDetails.publicKey.toString());
                        if (depositInfo) {
                            totalInitialValue += (depositInfo.tokenXUsdAmount || 0) + (depositInfo.tokenYUsdAmount || 0);
                        }
                        const dynamicFee = await getCurrentDynamicFee(poolAddress);
                        fetchedPositions.push({
                            address: positionDetails.publicKey.toString(),
                            pair_address: poolAddress,
                            owner: userPublicKey.toBase58(),
                            total_fee_usd_claimed: 0,
                            total_reward_usd_claimed: 0,
                            fee_apy_24h: 0,
                            fee_apr_24h: 0,
                            daily_fee_yield: 0,
                            lowerBinId: positionData.lowerBinId,
                            upperBinId: positionData.upperBinId,
                            // Access binStep from the pool object directly if available
                            binStep: dlmmPool.binStep,
                            tokenXMint: dlmmPool.tokenX.publicKey.toBase58(),
                            tokenYMint: dlmmPool.tokenY.publicKey.toBase58(),
                            tokenXDecimals: tokenXDecimals,
                            tokenYDecimals: tokenYDecimals,
                            totalXAmount: BigInt(xAmountBN.toString()),
                            totalYAmount: BigInt(yAmountBN.toString()),
                            pendingFeeX: BigInt(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.feeX?.toString() || '0').toString()),
                            pendingFeeY: BigInt(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.feeY?.toString() || '0').toString()),
                            // Access rewardInfos from positionData, using type assertion based on observed structure
                            pendingRewards: positionData.rewardInfos?.map((r)=>({
                                    mint: r.mint?.toBase58() || '',
                                    amount: BigInt(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](r.pendingReward?.toString() || '0').toString())
                                })) || [],
                            totalXAmountUi: tokenXAmount.toFixed(tokenXDecimals),
                            totalYAmountUi: tokenYAmount.toFixed(tokenYDecimals),
                            pendingFeeXUi: claimableXAmount.toFixed(tokenXDecimals),
                            pendingFeeYUi: claimableYAmount.toFixed(tokenYDecimals),
                            pendingRewardsUi: positionData.pendingRewardsUi?.map((r)=>({
                                    amount: r.amount?.toString() || '0',
                                    mint: r.mint?.toBase58() || ''
                                })) || [],
                            priceRange: `${positionData.lowerBinId} - ${positionData.upperBinId}`,
                            totalValueInSol: totalCurrentValueForPosition.toFixed(4),
                            isInRange: isInRange,
                            currentBinId: currentBinId,
                            tokenXPrice: tokenXPrice,
                            tokenYPrice: tokenYPrice,
                            claimedValue: claimedValue,
                            unclaimedValue: unclaimedValue,
                            positionValue: positionValue,
                            totalCurrentValue: totalCurrentValueForPosition,
                            depositInfo: depositInfo,
                            dynamicFee: dynamicFee
                        });
                    }
                } catch (poolError) {
                    console.error(`Error processing pool ${poolAddress}:`, poolError);
                // Continue to the next pool even if one fails
                }
            }
            const overallTotalCurrentValue = totalLiquidityValue + totalClaimedFees + totalUnclaimedFees;
            const overallTotalPnL = overallTotalCurrentValue - totalInitialValue;
            const overallTotalPnLPercentage = totalInitialValue > 0 ? overallTotalPnL / totalInitialValue * 100 : 0;
            setPositions(fetchedPositions);
            setTotalSummary({
                totalLiquidityValue,
                totalClaimedFees,
                totalUnclaimedFees,
                totalPositions,
                inRangePositions,
                totalInitialValue,
                totalPnL: overallTotalPnL,
                totalPnLPercentage: overallTotalPnLPercentage
            });
        } catch (e) {
            console.error('Error fetching user positions:', e);
            setError(e.message || 'LP 포지션 목록을 불러오는데 실패했습니다.');
        } finally{
            setIsLoading(false);
        }
    }, [
        userPublicKey
    ]); // Removed initialVolumes from dependencies
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (userPublicKey) {
            // Fetch positions only once when userPublicKey becomes available
            fetchPositions();
        // Remove setInterval for periodic fetching
        // const intervalId = setInterval(fetchPositions, CONFIG.UPDATE_INTERVAL);
        // return () => clearInterval(intervalId);
        } else {
            // Reset state when userPublicKey is null/undefined (e.g., after logout)
            setPositions([]);
            setIsLoading(false);
            setTotalSummary({
                totalLiquidityValue: 0,
                totalClaimedFees: 0,
                totalUnclaimedFees: 0,
                totalPositions: 0,
                inRangePositions: 0,
                totalInitialValue: 0,
                totalPnL: 0,
                totalPnLPercentage: 0
            });
        }
    }, [
        userPublicKey?.toBase58(),
        fetchPositions
    ]); // fetchPositions is a dependency because it's used inside useEffect
    // Return fetchPositions so it can be called manually from the component
    return {
        positions,
        isLoading,
        error,
        totalSummary,
        fetchPositions
    };
};
}}),
"[project]/src/components/lp/LpPositionItem.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>LpPositionItem)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)"); // Import necessary Solana types
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react/lib/esm/useWallet.js [app-ssr] (ecmascript)"); // Assuming wallet adapter is used on frontend
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-ssr] (ecmascript)"); // Correct default import for api client
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/decimal.js/decimal.mjs [app-ssr] (ecmascript)"); // For calculations
"use client";
;
;
;
;
;
;
// Helper to convert lamports to UI amount (can be shared or defined here)
// This helper is now primarily used for transaction building amounts if needed,
// as display amounts come pre-calculated from the backend.
function lamportsToUiAmount(lamports, decimals) {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return '0';
    try {
        const amountDecimal = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](lamports.toString()).div(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](10).pow(decimals));
        return amountDecimal.toFixed(Math.min(decimals, 6)); // Example: show up to 6 decimals
    } catch (e) {
        console.error("Error formatting amount:", e);
        return 'Error';
    }
}
function LpPositionItem({ position, onPositionRemoved }) {
    const { publicKey: userPublicKey, signTransaction, sendTransaction } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useWallet"])(); // Assuming wallet adapter hooks
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // TODO: Obtain the actual Solana Connection object in the frontend context
    const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com', 'confirmed'); // Placeholder
    // Display details are now received directly in the position prop
    // No need for a separate state or useEffect for calculations
    // useEffect(() => {
    //     // Calculation logic moved to backend
    // }, [position, connection]);
    const handleRemoveLiquidity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey || !signTransaction) {
            setError('Wallet not connected or signing not supported.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building using frontend SDK
            // This involves:
            // 1. Fetching necessary accounts (LbPair, Position, BinArrays, ATAs, etc.)
            // 2. Using SDK functions (e.g., DLMMSDK.Instructions.RemoveLiquidity2Instruction.build) to create instructions
            // 3. Building a Transaction or VersionedTransaction
            // 4. Getting the latest blockhash using the frontend connection object
            // 5. Setting fee payer and blockhash
            // 6. Serializing the transaction
            console.warn("handleRemoveLiquidity: Transaction building placeholder.");
            // Placeholder: Create a dummy transaction for demonstration
            const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                keys: [],
                programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                data: Buffer.from([])
            });
            const latestBlockhash = await connection.getLatestBlockhash('confirmed'); // Use frontend connection
            const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
            dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
            dummyTransaction.feePayer = userPublicKey;
            const serializedTransaction = dummyTransaction.serialize({
                requireAllSignatures: false,
                verifySignatures: false
            }).toString('base64');
            // Send serialized transaction to backend for signing and sending
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/process-transaction', {
                serializedTransaction
            });
            if (response.data && response.data.signature) {
                alert(`LP 해제 성공! 서명: ${response.data.signature}`);
                onPositionRemoved(position.address); // Notify parent component
            } else {
                throw new Error('Transaction failed on backend.');
            }
        } catch (e) {
            console.error('Error removing liquidity:', e);
            setError(e.message || 'LP 해제 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        position,
        userPublicKey,
        signTransaction,
        onPositionRemoved,
        connection
    ]); // Add connection to dependencies
    const handleRemoveAndSwap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey || !signTransaction) {
            setError('Wallet not connected or signing not supported.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building for remove + swap using frontend SDK
            // This involves:
            // 1. Building remove liquidity and claim fee instructions (similar to handleRemoveLiquidity)
            // 2. Building swap instructions using SDK (requires Jupiter quote)
            // 3. Combining instructions into a single transaction (if possible) or multiple transactions
            // 4. Getting the latest blockhash using the frontend connection object
            // 5. Setting fee payer and blockhash
            // 6. Serializing transaction(s)
            console.warn("handleRemoveAndSwap: Transaction building placeholder.");
            // Placeholder: Create a dummy transaction
            const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                keys: [],
                programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                data: Buffer.from([])
            });
            const latestBlockhash = await connection.getLatestBlockhash('confirmed'); // Use frontend connection
            const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
            dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
            dummyTransaction.feePayer = userPublicKey;
            const serializedTransaction = dummyTransaction.serialize({
                requireAllSignatures: false,
                verifySignatures: false
            }).toString('base64');
            // Send serialized transaction(s) to backend
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/process-transaction', {
                serializedTransaction
            });
            if (response.data && response.data.signature) {
                alert(`LP 해제 및 스왑 성공! 서명: ${response.data.signature}`);
                onPositionRemoved(position.address); // Notify parent component
            } else {
                throw new Error('Transaction failed on backend.');
            }
        } catch (e) {
            console.error('Error removing liquidity and swapping:', e);
            setError(e.message || 'LP 해제 및 자동 스왑 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        position,
        userPublicKey,
        signTransaction,
        onPositionRemoved,
        connection
    ]); // Add connection to dependencies
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-gray-800 p-4 rounded-lg mb-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-lg font-semibold text-white mb-2",
                children: [
                    "LP 포지션: ",
                    position.address.slice(0, 6),
                    "...",
                    position.address.slice(-6)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 153,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "풀: ",
                    position.pair_address.slice(0, 6),
                    "...",
                    position.pair_address.slice(-6)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 154,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "가격 범위: ",
                    position.priceRange
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 157,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "총 가치 (SOL): ",
                    position.totalValueInSol
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 158,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "예치 금액: ",
                    position.totalXAmountUi,
                    " (",
                    position.tokenXMint.slice(0, 4),
                    "...) / ",
                    position.totalYAmountUi,
                    " (",
                    position.tokenYMint.slice(0, 4),
                    "...)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 159,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "미청구 수수료: ",
                    position.pendingFeeXUi,
                    " (",
                    position.tokenXMint.slice(0, 4),
                    "...) / ",
                    position.pendingFeeYUi,
                    " (",
                    position.tokenYMint.slice(0, 4),
                    "...)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 162,
                columnNumber: 7
            }, this),
            position.pendingRewardsUi.map((reward, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-300",
                    children: [
                        "미청구 보상 ",
                        index + 1,
                        ": ",
                        reward.amount,
                        " (",
                        reward.mint.slice(0, 4),
                        "...)"
                    ]
                }, index, true, {
                    fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                    lineNumber: 166,
                    columnNumber: 9
                }, this)),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-2 rounded-md mt-4 text-sm",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 172,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex space-x-2 mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveLiquidity,
                        disabled: isLoading,
                        children: isLoading ? '해제 중...' : 'LP 해제'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                        lineNumber: 178,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAndSwap,
                        disabled: isLoading,
                        children: isLoading ? '해제 및 스왑 중...' : 'LP 해제 및 자동 스왑'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                        lineNumber: 185,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 177,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
        lineNumber: 152,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/app/dashboard/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DashboardPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react/lib/esm/useWallet.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/authStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDlmmPositions$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useDlmmPositions.ts [app-ssr] (ecmascript)"); // Import the new hook
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$LpPositionItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/lp/LpPositionItem.tsx [app-ssr] (ecmascript)"); // Import LpPositionItem component
"use client";
;
;
;
;
;
;
;
;
function DashboardPage() {
    const { publicKey: userPublicKey, connected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useWallet"])();
    const { user, isLoggedIn, isLoading: isAuthLoading, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [solBalance, setSolBalance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // Use the new hook to fetch positions and related data, and expose fetchPositions for manual refresh
    const { positions, isLoading, error, totalSummary, fetchPositions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDlmmPositions$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDlmmPositions"])(userPublicKey);
    // Redirect if not logged in
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!isAuthLoading && !isLoggedIn) {
            router.replace('/');
        }
    }, [
        isAuthLoading,
        isLoggedIn,
        router
    ]);
    // Fetch SOL balance (Still needed, uses connection)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchSolBalance = async ()=>{
            if (userPublicKey) {
                try {
                    const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com', 'confirmed');
                    const balance = await connection.getBalance(userPublicKey);
                    setSolBalance(balance / 10 ** 9); // Convert lamports to SOL
                } catch (e) {
                    console.error("Failed to fetch SOL balance:", e);
                    setSolBalance(null);
                }
            } else {
                setSolBalance(null);
            }
        };
        fetchSolBalance();
    }, [
        userPublicKey
    ]);
    const handleLogout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        logout();
        router.push('/');
    }, [
        logout,
        router
    ]);
    // Placeholder functions for LP actions (can be updated later to use hook data/actions)
    const handleExportPrivateKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        // TODO: Implement actual private key export logic
        console.log('개인 키 내보내기 기능은 현재 초기화되었습니다.');
    }, []);
    const handleRemoveAllLp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        // TODO: Implement actual remove all LP logic using hook/SDK
        console.log('모든 LP 포지션 정리 기능은 현재 초기화되었습니다.');
    }, []);
    const handleRemoveAllLpAndSwap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        // TODO: Implement actual remove all LP and swap logic using hook/SDK
        console.log('모든 LP 포지션 정리 및 스왑 기능은 현재 초기화되었습니다.');
    }, []);
    if (!connected) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto p-4 pt-20 text-center text-gray-300",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "지갑을 연결하여 LP 포지션을 확인하세요."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 72,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/page.tsx",
            lineNumber: 71,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto p-4 pt-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-4xl font-bold text-gray-100 mb-8",
                children: "대시보드"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-4 rounded-md mb-4",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 82,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-4",
                        children: "사용자 정보 및 지갑"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this),
                    user?.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "사용자 ID: ",
                            user.id
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 89,
                        columnNumber: 24
                    }, this),
                    userPublicKey && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "지갑 주소: ",
                            userPublicKey.toBase58()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 90,
                        columnNumber: 29
                    }, this),
                    solBalance !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "SOL 잔액: ",
                            solBalance?.toFixed(4)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 91,
                        columnNumber: 35
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex space-x-4 mt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: ()=>router.push('/lp/create'),
                                children: "새 LP 포지션 생성"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 93,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: handleExportPrivateKey,
                                disabled: !userPublicKey || isLoading,
                                children: "개인 키 내보내기"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 99,
                                columnNumber: 16
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-red-600 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: handleLogout,
                                children: "로그아웃"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 106,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-gray-100 mb-4",
                children: "나의 LP 포지션"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 115,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: `bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                    onClick: fetchPositions,
                    disabled: isLoading,
                    children: isLoading ? '새로고침 중...' : 'LP 포지션 새로고침'
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/page.tsx",
                    lineNumber: 119,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 118,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl font-semibold text-white mb-4",
                        children: "요약"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "총 포지션 수: ",
                            totalSummary.totalPositions
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "범위 내 포지션 수: ",
                            totalSummary.inRangePositions
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 133,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "총 유동성 가치: $",
                            totalSummary.totalLiquidityValue.toFixed(2)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 134,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "총 미청구 수수료: $",
                            totalSummary.totalUnclaimedFees.toFixed(2)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 135,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "총 초기 투자 가치: $",
                            totalSummary.totalInitialValue.toFixed(2)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 136,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 130,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 flex space-x-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAllLp,
                        disabled: isLoading || positions.length === 0,
                        children: "모든 LP 포지션 한번에 정리하기 (더미)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 142,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAllLpAndSwap,
                        disabled: isLoading || positions.length === 0,
                        children: "모든 LP 포지션 한번에 정리 및 SOL로 전부 자동 스왑 (더미)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 149,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 141,
                columnNumber: 8
            }, this),
            isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: "LP 포지션을 불러오는 중..."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 160,
                columnNumber: 9
            }, this) : error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-4 rounded-md mb-4",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 162,
                columnNumber: 9
            }, this) : positions.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: "활성화된 LP 포지션이 없습니다."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 166,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: positions.map((position)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$LpPositionItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        position: position,
                        onPositionRemoved: ()=>console.log('Placeholder onPositionRemoved triggered')
                    }, position.address, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 170,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 168,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/page.tsx",
        lineNumber: 78,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__e844f05c._.js.map