module.exports = {

"[project]/src/components/lp/LpPositionItem.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>LpPositionItem)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)"); // Import necessary Solana types
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react/lib/esm/useWallet.js [app-ssr] (ecmascript)"); // Assuming wallet adapter is used on frontend
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-ssr] (ecmascript)"); // Correct default import for api client
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/decimal.js/decimal.mjs [app-ssr] (ecmascript)"); // For calculations
"use client";
;
;
;
;
;
;
// Helper to convert lamports to UI amount (can be shared or defined here)
// This helper is now primarily used for transaction building amounts if needed,
// as display amounts come pre-calculated from the backend.
function lamportsToUiAmount(lamports, decimals) {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return '0';
    try {
        const amountDecimal = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](lamports.toString()).div(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](10).pow(decimals));
        return amountDecimal.toFixed(Math.min(decimals, 6)); // Example: show up to 6 decimals
    } catch (e) {
        console.error("Error formatting amount:", e);
        return 'Error';
    }
}
function LpPositionItem({ position, onPositionRemoved }) {
    const { publicKey: userPublicKey, signTransaction, sendTransaction } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useWallet"])(); // Assuming wallet adapter hooks
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // TODO: Obtain the actual Solana Connection object in the frontend context
    const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com', 'confirmed'); // Placeholder
    // Display details are now received directly in the position prop
    // No need for a separate state or useEffect for calculations
    // useEffect(() => {
    //     // Calculation logic moved to backend
    // }, [position, connection]);
    const handleRemoveLiquidity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey || !signTransaction) {
            setError('Wallet not connected or signing not supported.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building using frontend SDK
            // This involves:
            // 1. Fetching necessary accounts (LbPair, Position, BinArrays, ATAs, etc.)
            // 2. Using SDK functions (e.g., DLMMSDK.Instructions.RemoveLiquidity2Instruction.build) to create instructions
            // 3. Building a Transaction or VersionedTransaction
            // 4. Getting the latest blockhash using the frontend connection object
            // 5. Setting fee payer and blockhash
            // 6. Serializing the transaction
            console.warn("handleRemoveLiquidity: Transaction building placeholder.");
            // Placeholder: Create a dummy transaction for demonstration
            const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                keys: [],
                programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                data: Buffer.from([])
            });
            const latestBlockhash = await connection.getLatestBlockhash('confirmed'); // Use frontend connection
            const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
            dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
            dummyTransaction.feePayer = userPublicKey;
            const serializedTransaction = dummyTransaction.serialize({
                requireAllSignatures: false,
                verifySignatures: false
            }).toString('base64');
            // Send serialized transaction to backend for signing and sending
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/process-transaction', {
                serializedTransaction
            });
            if (response.data && response.data.signature) {
                alert(`LP 해제 성공! 서명: ${response.data.signature}`);
                onPositionRemoved(position.address); // Notify parent component
            } else {
                throw new Error('Transaction failed on backend.');
            }
        } catch (e) {
            console.error('Error removing liquidity:', e);
            setError(e.message || 'LP 해제 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        position,
        userPublicKey,
        signTransaction,
        onPositionRemoved,
        connection
    ]); // Add connection to dependencies
    const handleRemoveAndSwap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey || !signTransaction) {
            setError('Wallet not connected or signing not supported.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building for remove + swap using frontend SDK
            // This involves:
            // 1. Building remove liquidity and claim fee instructions (similar to handleRemoveLiquidity)
            // 2. Building swap instructions using SDK (requires Jupiter quote)
            // 3. Combining instructions into a single transaction (if possible) or multiple transactions
            // 4. Getting the latest blockhash using the frontend connection object
            // 5. Setting fee payer and blockhash
            // 6. Serializing transaction(s)
            console.warn("handleRemoveAndSwap: Transaction building placeholder.");
            // Placeholder: Create a dummy transaction
            const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                keys: [],
                programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                data: Buffer.from([])
            });
            const latestBlockhash = await connection.getLatestBlockhash('confirmed'); // Use frontend connection
            const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
            dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
            dummyTransaction.feePayer = userPublicKey;
            const serializedTransaction = dummyTransaction.serialize({
                requireAllSignatures: false,
                verifySignatures: false
            }).toString('base64');
            // Send serialized transaction(s) to backend
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/process-transaction', {
                serializedTransaction
            });
            if (response.data && response.data.signature) {
                alert(`LP 해제 및 스왑 성공! 서명: ${response.data.signature}`);
                onPositionRemoved(position.address); // Notify parent component
            } else {
                throw new Error('Transaction failed on backend.');
            }
        } catch (e) {
            console.error('Error removing liquidity and swapping:', e);
            setError(e.message || 'LP 해제 및 자동 스왑 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        position,
        userPublicKey,
        signTransaction,
        onPositionRemoved,
        connection
    ]); // Add connection to dependencies
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-gray-800 p-4 rounded-lg mb-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-lg font-semibold text-white mb-2",
                children: [
                    "LP 포지션: ",
                    position.address.slice(0, 6),
                    "...",
                    position.address.slice(-6)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 153,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "풀: ",
                    position.pair_address.slice(0, 6),
                    "...",
                    position.pair_address.slice(-6)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 154,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "가격 범위: ",
                    position.priceRange
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 157,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "총 가치 (SOL): ",
                    position.totalValueInSol
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 158,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "예치 금액: ",
                    position.totalXAmountUi,
                    " (",
                    position.tokenXMint.slice(0, 4),
                    "...) / ",
                    position.totalYAmountUi,
                    " (",
                    position.tokenYMint.slice(0, 4),
                    "...)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 159,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "미청구 수수료: ",
                    position.pendingFeeXUi,
                    " (",
                    position.tokenXMint.slice(0, 4),
                    "...) / ",
                    position.pendingFeeYUi,
                    " (",
                    position.tokenYMint.slice(0, 4),
                    "...)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 162,
                columnNumber: 7
            }, this),
            position.pendingRewardsUi.map((reward, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-300",
                    children: [
                        "미청구 보상 ",
                        index + 1,
                        ": ",
                        reward.amount,
                        " (",
                        reward.mint.slice(0, 4),
                        "...)"
                    ]
                }, index, true, {
                    fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                    lineNumber: 166,
                    columnNumber: 9
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "총 청구 수수료 (USD): ",
                    position.total_fee_usd_claimed.toFixed(2)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 172,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "총 청구 보상 (USD): ",
                    position.total_reward_usd_claimed.toFixed(2)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 173,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "24시간 수수료 APY: ",
                    position.fee_apy_24h.toFixed(2),
                    "%"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 174,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "24시간 수수료 APR: ",
                    position.fee_apr_24h.toFixed(2),
                    "%"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 175,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "일일 수수료 수익률: ",
                    position.daily_fee_yield.toFixed(2),
                    "%"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 176,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-2 rounded-md mt-4 text-sm",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 180,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex space-x-2 mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveLiquidity,
                        disabled: isLoading,
                        children: isLoading ? '해제 중...' : 'LP 해제'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                        lineNumber: 186,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAndSwap,
                        disabled: isLoading,
                        children: isLoading ? '해제 및 스왑 중...' : 'LP 해제 및 자동 스왑'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                        lineNumber: 193,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 185,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
        lineNumber: 152,
        columnNumber: 5
    }, this);
}
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/dashboard/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DashboardPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react/lib/esm/useWallet.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-ssr] (ecmascript)"); // Import api client
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$LpPositionItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/lp/LpPositionItem.tsx [app-ssr] (ecmascript)"); // Import the new component
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/authStore.ts [app-ssr] (ecmascript)"); // Assuming auth store for user info
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)"); // Assuming next router for navigation
"use client";
;
;
;
;
;
;
;
;
function DashboardPage() {
    const { publicKey: userPublicKey, connected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$useWallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useWallet"])();
    const { user, isLoggedIn, isLoading: isAuthLoading, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(); // Get user info and logout function
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [positions, setPositions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [solBalance, setSolBalance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null); // State for SOL balance
    // Redirect if not logged in
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!isAuthLoading && !isLoggedIn) {
            router.replace('/');
        }
    }, [
        isAuthLoading,
        isLoggedIn,
        router
    ]);
    // Fetch SOL balance (Still needed, uses connection)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchSolBalance = async ()=>{
            if (userPublicKey) {
                try {
                    // Re-create connection if needed, or pass it down from layout/context
                    // For simplicity, let's assume connection is available or re-created
                    const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com', 'confirmed');
                    const balance = await connection.getBalance(userPublicKey);
                    setSolBalance(balance / 10 ** 9); // Convert lamports to SOL
                } catch (e) {
                    console.error("Failed to fetch SOL balance:", e);
                    setSolBalance(null);
                }
            } else {
                setSolBalance(null);
            }
        };
        fetchSolBalance();
    }, [
        userPublicKey
    ]); // Removed connection from dependencies as it's created inside
    const fetchAndSetUserPositions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setPositions([]);
            setIsLoading(false);
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // Fetch detailed user positions from the backend API
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/api/dlmm/positions'); // Backend now returns detailed position data
            console.log("Fetched detailed user positions from backend:", response.data); // Debugging log
            setPositions(response.data); // Set positions directly from backend response
        } catch (e) {
            console.error('Error fetching user positions from backend:', e);
            setError(e.message || 'LP 포지션 목록을 불러오는데 실패했습니다.');
        } finally{
            setIsLoading(false);
        }
    }, [
        userPublicKey
    ]); // Dependencies: only userPublicKey is needed now
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (connected) {
            fetchAndSetUserPositions();
        } else {
            setPositions([]);
            setIsLoading(false);
        }
    }, [
        connected,
        fetchAndSetUserPositions
    ]);
    const handleLogout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        logout(); // Call logout function from auth store
        router.push('/'); // Redirect to home page
    }, [
        logout,
        router
    ]);
    const handleExportPrivateKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setError('Wallet not connected.');
            return;
        }
        setIsLoading(true); // Indicate loading for the export operation
        setError(null);
        try {
            // Call the existing backend endpoint to export the private key
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/api/wallet/export-private-key'); // Assuming this endpoint exists and is correct
            if (response.data && response.data.privateKey) {
                // The backend returns the private key as an array of numbers or similar.
                // Convert it back to a Uint8Array or string format if needed.
                const privateKeyBytes = response.data.privateKey; // Assuming it's an array of numbers
                const privateKeyUint8Array = Uint8Array.from(privateKeyBytes);
                // Convert Uint8Array to a Base58 string for display/copy
                const privateKeyBase58 = privateKeyUint8Array.toString(); // Assuming toString() on Uint8Array gives the desired format or needs conversion
                // Format the private key string with square brackets
                const formattedPrivateKey = `[${privateKeyBase58}]`;
                // Use navigator.clipboard.writeText to copy to clipboard
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    await navigator.clipboard.writeText(formattedPrivateKey);
                    alert("경고: 개인 키가 클립보드에 복사되었습니다. 안전한 곳에 보관하세요.");
                } else {
                    // Fallback for browsers that don't support clipboard API
                    alert("경고: 개인 키를 클립보드에 복사할 수 없습니다. 개발 목적으로만 사용하세요.\n\n개인 키: " + formattedPrivateKey);
                }
            // TODO: Implement a more secure way to export the private key (e.g., download file)
            } else {
                throw new Error('Failed to export private key from backend: No private key in response.');
            }
        } catch (e) {
            console.error('Error exporting private key:', e);
            setError(e.message || '개인 키 내보내기 중 오류 발생');
        } finally{
            setIsLoading(false); // End loading
        }
    }, [
        userPublicKey
    ]); // Add dependencies
    const handleRemoveAllLp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setError('Wallet not connected.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building for removing ALL liquidity using frontend SDK
            // This involves:
            // 1. Iterating through all positions in the 'positions' state
            // 2. For each position, building remove liquidity and claim fee instructions
            // 3. Combining instructions into transactions (respecting transaction size limits)
            // 4. Serializing transactions
            // 5. Sending serialized transactions to backend for signing and sending
            console.warn("handleRemoveAllLp: Transaction building placeholder.");
            // Placeholder: Send dummy transactions
            for (const position of positions){
                const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                    keys: [],
                    programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                    data: Buffer.from([])
                });
                // Re-create connection if needed, or pass it down
                const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com', 'confirmed');
                const latestBlockhash = await connection.getLatestBlockhash('confirmed');
                const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
                dummyTransaction.recentBlockhash = latestBlockhash.blockhash; // Corrected typo
                dummyTransaction.feePayer = userPublicKey;
                const serializedTransaction = dummyTransaction.serialize({
                    requireAllSignatures: false,
                    verifySignatures: false
                }).toString('base64');
                console.log(`Sending dummy remove tx for position ${position.address}`);
            // await api.post('/api/dlmm/process-transaction', { serializedTransaction }); // Uncomment to send
            }
            alert('모든 LP 포지션 해제 트랜잭션 전송 완료 (더미)');
        // TODO: Refresh position list after transactions are confirmed
        // fetchAndSetUserPositions(); // Call the updated fetch function
        } catch (e) {
            console.error('Error removing all liquidity:', e);
            setError(e.message || '모든 LP 포지션 해제 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        positions,
        userPublicKey
    ]); // Removed connection from dependencies
    const handleRemoveAllLpAndSwap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setError('Wallet not connected.');
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            // TODO: Implement transaction building for removing ALL liquidity and swapping using frontend SDK
            // This involves:
            // 1. Iterating through all positions
            // 2. For each, building remove liquidity and claim fee instructions
            // 3. Building swap instructions for recovered tokens (requires Jupiter quotes)
            // 4. Combining instructions into a single transaction (if possible) or multiple transactions
            // 5. Serializing transactions
            // 6. Sending serialized transactions to backend
            console.warn("handleRemoveAllLpAndSwap: Transaction building placeholder.");
            // Placeholder: Send dummy transactions
            for (const position of positions){
                const dummyInstruction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
                    keys: [],
                    programId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
                    data: Buffer.from([])
                });
                // Re-create connection if needed, or pass it down
                const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com', 'confirmed');
                const latestBlockhash = await connection.getLatestBlockhash('confirmed');
                const dummyTransaction = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]().add(dummyInstruction);
                dummyTransaction.recentBlockhash = latestBlockhash.blockhash; // Corrected typo
                dummyTransaction.feePayer = userPublicKey;
                const serializedTransaction = dummyTransaction.serialize({
                    requireAllSignatures: false,
                    verifySignatures: false
                }).toString('base64');
                console.log(`Sending dummy remove+swap tx for position ${position.address}`);
            // await api.post('/api/dlmm/process-transaction', { serializedTransaction }); // Uncomment to send
            }
            alert('모든 LP 포지션 해제 및 스왑 트랜잭션 전송 완료 (더미)');
        // TODO: Refresh position list after transactions are confirmed
        // fetchAndSetUserPositions(); // Call the updated fetch function
        } catch (e) {
            console.error('Error removing all liquidity and swapping:', e);
            setError(e.message || '모든 LP 포지션 해제 및 스왑 중 오류 발생');
        } finally{
            setIsLoading(false);
        }
    }, [
        positions,
        userPublicKey
    ]); // Removed connection from dependencies
    if (!connected) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto p-4 pt-20 text-center text-gray-300",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "지갑을 연결하여 LP 포지션을 확인하세요."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 242,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/page.tsx",
            lineNumber: 241,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto p-4 pt-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-4xl font-bold text-gray-100 mb-8",
                children: "대시보드"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 249,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-4 rounded-md mb-4",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 252,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-4",
                        children: "사용자 정보 및 지갑"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 259,
                        columnNumber: 11
                    }, this),
                    user && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "사용자 ID: ",
                            user.id
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 260,
                        columnNumber: 20
                    }, this),
                    userPublicKey && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "지갑 주소: ",
                            userPublicKey.toBase58()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 261,
                        columnNumber: 29
                    }, this),
                    solBalance !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "SOL 잔액: ",
                            solBalance.toFixed(4)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 262,
                        columnNumber: 35
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex space-x-4 mt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: ()=>router.push('/lp/create'),
                                children: "새 LP 포지션 생성"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 265,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: handleExportPrivateKey,
                                disabled: !userPublicKey || isLoading,
                                children: isLoading ? '내보내는 중...' : '개인 키 내보내기'
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 271,
                                columnNumber: 16
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: handleLogout,
                                children: "로그아웃"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 278,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 264,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 258,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-gray-100 mb-4",
                children: "나의 LP 포지션"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 288,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 flex space-x-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAllLp,
                        disabled: isLoading || positions.length === 0,
                        children: isLoading ? '정리 중...' : '모든 LP 포지션 한번에 정리하기 (더미)'
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 291,
                        columnNumber: 12
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAllLpAndSwap,
                        disabled: isLoading || positions.length === 0,
                        children: isLoading ? '정리 및 스왑 중...' : '모든 LP 포지션 한번에 정리 및 SOL로 전부 자동 스왑 (더미)'
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 298,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 290,
                columnNumber: 7
            }, this),
            isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: "LP 포지션을 불러오는 중..."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 309,
                columnNumber: 9
            }, this) : positions.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: "활성화된 LP 포지션이 없습니다."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 311,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: positions.map((position)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$LpPositionItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        position: position,
                        onPositionRemoved: fetchAndSetUserPositions
                    }, position.address, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 315,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 313,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/page.tsx",
        lineNumber: 248,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__ba9bf2b9._.js.map