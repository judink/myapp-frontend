(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/hooks/usePoolSearch.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "usePoolSearch": (()=>usePoolSearch)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/spl-token/lib/esm/constants.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function usePoolSearch() {
    _s();
    const [pools, setPools] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [poolsLoading, setPoolsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchPoolsByToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePoolSearch.useCallback[fetchPoolsByToken]": async (tokenCaInput)=>{
            if (!tokenCaInput) {
                setError('대상 토큰 민트 주소를 입력해주세요.');
                setPools([]);
                return;
            }
            setPoolsLoading(true);
            setError(null);
            setPools([]);
            try {
                const meteoraApiUrl = `https://dlmm-api.meteora.ag/pair/all_by_groups?include_pool_token_pairs=${tokenCaInput}-${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NATIVE_MINT"].toBase58()}`;
                console.log(`Fetching pools from Meteora API (usePoolSearch): ${meteoraApiUrl}`);
                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(meteoraApiUrl, {
                    headers: {
                        'accept': 'application/json'
                    }
                });
                const apiResponse = response.data;
                console.log("Meteora API response received (usePoolSearch).");
                const relevantPairs = apiResponse.groups.flatMap({
                    "usePoolSearch.useCallback[fetchPoolsByToken].relevantPairs": (group)=>group.pairs.map({
                            "usePoolSearch.useCallback[fetchPoolsByToken].relevantPairs": (pair)=>({
                                    poolAddress: pair.address,
                                    tokenX: pair.name?.split('/')[0] || pair.mint_x.substring(0, 4),
                                    tokenY: pair.name?.split('/')[1] || pair.mint_y.substring(0, 4),
                                    tokenXMint: pair.mint_x,
                                    tokenYMint: pair.mint_y,
                                    binStep: pair.bin_step,
                                    baseFeeBps: parseFloat(pair.base_fee_percentage) * 100,
                                    name: pair.name,
                                    liquidity: parseFloat(pair.liquidity),
                                    trade_volume_24h: pair.trade_volume_24h,
                                    current_price: pair.current_price
                                })
                        }["usePoolSearch.useCallback[fetchPoolsByToken].relevantPairs"])
                }["usePoolSearch.useCallback[fetchPoolsByToken].relevantPairs"]);
                relevantPairs.sort({
                    "usePoolSearch.useCallback[fetchPoolsByToken]": (a, b)=>b.liquidity - a.liquidity
                }["usePoolSearch.useCallback[fetchPoolsByToken]"]);
                setPools(relevantPairs);
                if (relevantPairs.length === 0) {
                    setError('입력하신 토큰 페어에 해당하는 풀을 찾을 수 없습니다.');
                }
            } catch (error) {
                console.error('Failed to fetch pools by token from Meteora API (usePoolSearch):', error);
                const errorMessage = error.response?.data?.message || error.message;
                setError(`풀 목록을 불러오는 데 실패했습니다: ${errorMessage}`);
            } finally{
                setPoolsLoading(false);
            }
        }
    }["usePoolSearch.useCallback[fetchPoolsByToken]"], []);
    return {
        pools,
        poolsLoading,
        error,
        fetchPoolsByToken,
        setPools,
        setError
    };
}
_s(usePoolSearch, "K88FZxOnGYLRmro5+Pnn1u1UrOY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/hooks/usePriceRangeCalculation.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "usePriceRangeCalculation": (()=>usePriceRangeCalculation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2e$debounce$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash.debounce/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function usePriceRangeCalculation(selectedPool, totalSolValue, solDepositRatioPercent, strategyType) {
    _s();
    const [calculatedPriceRange, setCalculatedPriceRange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [calculationLoading, setCalculationLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [calculationError, setCalculationError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const calculatePriceRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2e$debounce$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "usePriceRangeCalculation.useCallback[calculatePriceRange]": async ()=>{
            console.log('[usePriceRangeCalculation] Called. selectedPool:', selectedPool, 'totalSolValue:', totalSolValue, 'solDepositRatioPercent:', solDepositRatioPercent, 'strategyType:', strategyType);
            const parsedTotalSolValue = parseFloat(totalSolValue);
            if (!selectedPool || !totalSolValue || isNaN(parsedTotalSolValue) || parsedTotalSolValue <= 0 || solDepositRatioPercent === undefined || !strategyType || selectedPool.current_price === undefined) {
                console.log('[usePriceRangeCalculation] Conditions not met (e.g., totalSolValue invalid or other params missing), setting calculatedPriceRange to null.');
                setCalculatedPriceRange(null);
                setCalculationError(null); // Clear error if conditions are not met
                return;
            }
            setCalculationLoading(true);
            setCalculationError(null);
            try {
                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/calculate-price-range', {
                    poolAddress: selectedPool.poolAddress,
                    currentPrice: selectedPool.current_price.toString(),
                    binStep: selectedPool.binStep,
                    solDepositRatioPercent: solDepositRatioPercent,
                    strategyType: strategyType
                });
                setCalculatedPriceRange(response.data);
            } catch (error) {
                console.error('Failed to calculate price range (usePriceRangeCalculation):', error);
                setCalculationError(`가격 범위 계산 실패: ${error.response?.data?.message || error.message}`);
                setCalculatedPriceRange(null);
            } finally{
                setCalculationLoading(false);
            }
        }
    }["usePriceRangeCalculation.useCallback[calculatePriceRange]"], 500), [
        selectedPool,
        totalSolValue,
        solDepositRatioPercent,
        strategyType
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePriceRangeCalculation.useEffect": ()=>{
            calculatePriceRange();
            return ({
                "usePriceRangeCalculation.useEffect": ()=>{
                    calculatePriceRange.cancel();
                }
            })["usePriceRangeCalculation.useEffect"];
        }
    }["usePriceRangeCalculation.useEffect"], [
        selectedPool,
        totalSolValue,
        solDepositRatioPercent,
        strategyType,
        calculatePriceRange
    ]);
    return {
        calculatedPriceRange,
        calculationLoading,
        calculationError
    };
}
_s(usePriceRangeCalculation, "PRZn/vHe3WmVBrdx3FCCu0YpnAQ=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/hooks/useAssetCheck.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useAssetCheck": (()=>useAssetCheck)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useAssetCheck() {
    _s();
    const [assetCheckResult, setAssetCheckResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [assetCheckLoading, setAssetCheckLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [assetCheckError, setAssetCheckError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleAssetCheck = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useAssetCheck.useCallback[handleAssetCheck]": async (selectedPool, tokenCaInput, totalSolValue, solDepositRatioPercent, strategyType, calculatedPriceRange)=>{
            if (!selectedPool || !tokenCaInput || !totalSolValue || solDepositRatioPercent === undefined || !strategyType || !calculatedPriceRange || calculatedPriceRange.minBinId === undefined || calculatedPriceRange.maxBinId === undefined) {
                setAssetCheckError('모든 필수 정보를 입력하고 가격 범위를 계산해주세요.');
                return;
            }
            setAssetCheckLoading(true);
            setAssetCheckError(null);
            setAssetCheckResult(null);
            try {
                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/lp/create', {
                    poolAddress: selectedPool.poolAddress,
                    tokenCa: tokenCaInput,
                    totalSolValue: totalSolValue,
                    solDepositRatioPercent: solDepositRatioPercent,
                    strategyType: strategyType,
                    currentPrice: selectedPool.current_price,
                    minBinId: calculatedPriceRange.minBinId,
                    maxBinId: calculatedPriceRange.maxBinId,
                    targetMinPrice: calculatedPriceRange.minPrice,
                    targetMaxPrice: calculatedPriceRange.maxPrice,
                    executeLpCreation: false
                });
                // Check for the new status field
                if (response.data && response.data.status === 'success') {
                    setAssetCheckResult(response.data);
                // Note: The component using this hook will handle the step transition based on the result
                } else {
                    // Handle cases where status is not 'success' or response structure is unexpected
                    console.error('Asset Check Failed: Unexpected response structure or status', response.data);
                    setAssetCheckError(`자산 확인 실패: 예상치 못한 응답 형식`);
                }
            } catch (error) {
                console.error('Asset Check Failed (useAssetCheck):', error);
                setAssetCheckError(`자산 확인 실패: ${error.response?.data?.message || error.message}`);
            } finally{
                setAssetCheckLoading(false);
            }
        }
    }["useAssetCheck.useCallback[handleAssetCheck]"], [] // Dependencies: This function depends on parameters passed to it, not external state
    );
    return {
        assetCheckResult,
        assetCheckLoading,
        assetCheckError,
        handleAssetCheck,
        setAssetCheckResult,
        setAssetCheckError
    };
}
_s(useAssetCheck, "WUvotODlSm5eRSHIPTSDoJGhbXQ=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/lpUtils.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "executeLpCreation": (()=>executeLpCreation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
;
async function executeLpCreation(selectedPool, tokenCaInput, totalSolValue, solDepositRatioPercent, strategyType, calculatedPriceRange, assetCheckResult) {
    if (!selectedPool || !tokenCaInput || !totalSolValue || solDepositRatioPercent === undefined || !strategyType || !calculatedPriceRange || !assetCheckResult) {
        throw new Error('Missing required parameters for LP creation execution.');
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/lp/create', {
            poolAddress: selectedPool.poolAddress,
            tokenCa: tokenCaInput,
            totalSolValue: totalSolValue,
            solDepositRatioPercent: solDepositRatioPercent,
            strategyType: strategyType,
            currentPrice: selectedPool.current_price,
            minBinId: calculatedPriceRange.minBinId,
            maxBinId: calculatedPriceRange.maxBinId,
            targetMinPrice: calculatedPriceRange.minPrice,
            targetMaxPrice: calculatedPriceRange.maxPrice,
            executeLpCreation: true
        });
        console.log('LP Creation Response (lpUtils):', response.data);
        return response.data;
    } catch (error) {
        console.error('LP Creation Failed (lpUtils):', error);
        const errorMessage = error.response?.data?.message || error.message;
        throw new Error(`LP 포지션 생성 실패: ${errorMessage}`);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/lp/create/Step1PoolSelection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Step1PoolSelection)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Step1PoolSelection({ tokenCaInput, setTokenCaInput, pools, poolsLoading, handlePoolSearch, selectedPool, setSelectedPool, setCurrentStep }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-white mb-4",
                children: "단계 1: 토큰 선택 및 풀 검색"
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "tokenCaInput",
                        className: "block text-gray-300 text-sm font-bold mb-2",
                        children: "대상 토큰 (Y) 민트 주소:"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        id: "tokenCaInput",
                        className: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                        value: tokenCaInput,
                        onChange: (e)=>setTokenCaInput(e.target.value),
                        placeholder: "예: 대상 토큰 민트 주소"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "mt-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                        onClick: handlePoolSearch,
                        disabled: poolsLoading,
                        children: poolsLoading ? '풀 검색 중...' : '풀 검색'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            poolsLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "풀 목록을 불러오는 중..."
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                lineNumber: 63,
                columnNumber: 9
            }, this) : pools.length === 0 && tokenCaInput ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "입력하신 토큰 페어에 해당하는 풀을 찾을 수 없습니다."
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                lineNumber: 65,
                columnNumber: 9
            }, this) : pools.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "poolSelect",
                        className: "block text-gray-300 text-sm font-bold mb-2",
                        children: "풀 선택:"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        id: "poolSelect",
                        className: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                        value: selectedPool?.poolAddress || '',
                        onChange: (e)=>{
                            const pool = pools.find((p)=>p.poolAddress === e.target.value);
                            setSelectedPool(pool || null);
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                disabled: true,
                                children: "풀을 선택해주세요"
                            }, void 0, false, {
                                fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                                lineNumber: 80,
                                columnNumber: 13
                            }, this),
                            pools.map((pool)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: pool.poolAddress,
                                    children: `${pool.name || `${pool.tokenX.substring(0, 4)}/${pool.tokenY.substring(0, 4)}`} - Bin Step: ${pool.binStep} - Base Fee: ${pool.baseFeeBps / 100}% - Liquidity: ${pool.liquidity.toFixed(2)} - 24h Volume: ${pool.trade_volume_24h.toFixed(2)}`
                                }, pool.poolAddress, false, {
                                    fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                                    lineNumber: 82,
                                    columnNumber: 15
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                        lineNumber: 71,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                lineNumber: 67,
                columnNumber: 9
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                onClick: ()=>setCurrentStep(2),
                disabled: !selectedPool || poolsLoading,
                children: "다음"
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step1PoolSelection.tsx",
                lineNumber: 89,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = Step1PoolSelection;
var _c;
__turbopack_context__.k.register(_c, "Step1PoolSelection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/lp/create/Step2DepositSettings.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Step2DepositSettings)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Step2DepositSettings({ selectedPool, totalSolValue, setTotalSolValue, solDepositRatioPercent, setSolDepositRatioPercent, strategyType, setStrategyType, calculatedPriceRange, calculationLoading, setCurrentStep, handleAssetCheckStep, assetCheckLoading }) {
    console.log('[Step2DepositSettings] Rendering. selectedPool:', selectedPool, 'totalSolValue:', totalSolValue, 'solDepositRatioPercent:', solDepositRatioPercent, 'strategyType:', strategyType, 'calculatedPriceRange:', calculatedPriceRange);
    const strategies = [
        'Spot',
        'Curve',
        'BidAsk'
    ]; // Corrected 'Bid-Ask' to 'BidAsk'
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-white mb-4",
                children: "단계 2: 예치 설정"
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            selectedPool && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 p-3 bg-gray-800 rounded",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "선택된 풀:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                                lineNumber: 57,
                                columnNumber: 14
                            }, this),
                            " ",
                            selectedPool.name || selectedPool.poolAddress
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 57,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Bin Step:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                                lineNumber: 58,
                                columnNumber: 14
                            }, this),
                            " ",
                            selectedPool.binStep
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 58,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "현재 가격 (Y/X):"
                            }, void 0, false, {
                                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                                lineNumber: 59,
                                columnNumber: 14
                            }, this),
                            " ",
                            selectedPool.current_price !== undefined ? selectedPool.current_price.toFixed(10) : 'N/A'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 59,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 56,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "totalSolValue",
                        className: "block text-gray-300 text-sm font-bold mb-2",
                        children: "총 예치 가치 (SOL 기준):"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "number",
                        id: "totalSolValue",
                        className: "shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline",
                        value: totalSolValue,
                        onChange: (e)=>setTotalSolValue(e.target.value),
                        placeholder: "예: 10",
                        min: "0",
                        step: "any"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "solDepositRatio",
                        className: "block text-gray-300 text-sm font-bold mb-2",
                        children: [
                            "SOL 예치 비율 (%): ",
                            solDepositRatioPercent,
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "range",
                        id: "solDepositRatio",
                        className: "w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700",
                        min: "0",
                        max: "100",
                        value: solDepositRatioPercent,
                        onChange: (e)=>setSolDepositRatioPercent(e.target.value)
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 81,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-gray-300 text-sm font-bold mb-2",
                        children: "전략 선택:"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex space-x-2",
                        children: strategies.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: `py-2 px-4 rounded-lg transition duration-300 ${strategyType === s ? 'bg-blue-600 text-white' : 'bg-gray-600 text-gray-300 hover:bg-gray-700'}`,
                                onClick: ()=>setStrategyType(s),
                                children: s
                            }, s, false, {
                                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 91,
                columnNumber: 7
            }, this),
            calculationLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-400",
                children: "가격 범위 계산 중..."
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 110,
                columnNumber: 30
            }, this),
            !calculationLoading && calculatedPriceRange && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 text-green-400",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            children: "계산된 가격 범위 (Y/X):"
                        }, void 0, false, {
                            fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                            lineNumber: 113,
                            columnNumber: 14
                        }, this),
                        " ",
                        parseFloat(calculatedPriceRange.minPrice).toFixed(10),
                        " ~ ",
                        parseFloat(calculatedPriceRange.maxPrice).toFixed(10)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                    lineNumber: 113,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 112,
                columnNumber: 9
            }, this),
            !calculationLoading && !calculatedPriceRange && parseFloat(totalSolValue) > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-yellow-400",
                children: "가격을 계산 중이거나, 입력값을 확인해주세요."
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 117,
                columnNumber: 12
            }, this),
            !calculationLoading && !calculatedPriceRange && (!totalSolValue || parseFloat(totalSolValue) <= 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 text-gray-400",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            children: "가격 범위:"
                        }, void 0, false, {
                            fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                            lineNumber: 121,
                            columnNumber: 13
                        }, this),
                        " 총 예치 가치를 입력하시면 가격 범위가 자동 계산됩니다."
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                    lineNumber: 121,
                    columnNumber: 10
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 120,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex space-x-4 mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                        onClick: ()=>setCurrentStep(1),
                        children: "이전 (풀 선택)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${assetCheckLoading || calculationLoading || !selectedPool || !totalSolValue || !strategyType || !calculatedPriceRange ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleAssetCheckStep,
                        disabled: assetCheckLoading || calculationLoading || !selectedPool || !totalSolValue || !strategyType || !calculatedPriceRange,
                        children: assetCheckLoading ? '자산 확인 중...' : '다음 (자산 확인)'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                        lineNumber: 132,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step2DepositSettings.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = Step2DepositSettings;
var _c;
__turbopack_context__.k.register(_c, "Step2DepositSettings");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/lp/create/Step3AssetCheck.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Step3AssetCheck)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/decimal.js/decimal.mjs [app-client] (ecmascript)"); // Import Decimal for formatting
;
;
function Step3AssetCheck({ assetCheckResult, assetCheckLoading, createLpLoading, handleExecuteCreateLp, setCurrentStep, setAssetCheckResult }) {
    if (assetCheckLoading || !assetCheckResult) {
        // This component should ideally only render when assetCheckResult is available,
        // but handle loading/null state defensively.
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: "자산 정보를 불러오는 중..."
        }, void 0, false, {
            fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
            lineNumber: 40,
            columnNumber: 14
        }, this);
    }
    const formatDisplayAmount = (lamports, decimals)=>{
        if (!lamports || decimals === undefined) return 'N/A';
        try {
            const amountDecimal = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](lamports).div(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](10).pow(decimals));
            return amountDecimal.toFixed(decimals); // Display with full precision or adjust as needed
        } catch (e) {
            console.error("Error formatting amount:", e);
            return 'Error';
        }
    };
    const requiredSolDisplay = formatDisplayAmount(assetCheckResult.requiredAssets?.solLamports, 9);
    const requiredTargetDisplay = formatDisplayAmount(assetCheckResult.requiredAssets?.targetTokenLamports, assetCheckResult.requiredAssets?.tokenDecimals);
    const currentSolDisplay = assetCheckResult.currentBalances ? formatDisplayAmount(assetCheckResult.currentBalances.solLamports, 9) : 'N/A';
    const currentTargetDisplay = assetCheckResult.currentBalances ? formatDisplayAmount(assetCheckResult.currentBalances.targetTokenLamports, assetCheckResult.requiredAssets?.tokenDecimals) : 'N/A';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-white mb-6",
                children: "단계 3: 자산 확인 및 스왑 동의"
            }, void 0, false, {
                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 mb-6 p-4 bg-gray-800 rounded-lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-semibold text-sky-400 mb-1",
                                children: "필요 자산:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "SOL: ",
                                    requiredSolDisplay
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 67,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "대상 토큰 (",
                                    assetCheckResult.requiredAssets?.tokenCa?.substring(0, 6),
                                    "...): ",
                                    requiredTargetDisplay
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 68,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-semibold text-green-400 mb-1",
                                children: "현재 잔액 (서버 조회):"
                            }, void 0, false, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 71,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "SOL: ",
                                    currentSolDisplay
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 72,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "대상 토큰 (",
                                    assetCheckResult.requiredAssets?.tokenCa?.substring(0, 6),
                                    "...): ",
                                    currentTargetDisplay
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 73,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this),
                    assetCheckResult.needsSwap && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4 p-3 bg-yellow-900 bg-opacity-50 rounded border border-yellow-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-yellow-400 font-semibold mb-2",
                                children: "알림: 자산이 부족하여 자동 스왑을 진행합니다."
                            }, void 0, false, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 78,
                                columnNumber: 13
                            }, this),
                            assetCheckResult.swapQuote ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-yellow-500",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "스왑 경로: ",
                                            assetCheckResult.swapQuote.routePlan?.map((route)=>route.swapInfo.label).join(' -> ') || 'N/A'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                        lineNumber: 82,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "입력량: ",
                                            formatDisplayAmount(assetCheckResult.swapQuote.inAmount, assetCheckResult.swapQuote.inTokenInfo?.decimals || 9),
                                            " ",
                                            assetCheckResult.swapQuote.inTokenInfo?.symbol || 'Input Token'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                        lineNumber: 83,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "출력량: ",
                                            formatDisplayAmount(assetCheckResult.swapQuote.outAmount, assetCheckResult.swapQuote.outTokenInfo?.decimals || 9),
                                            " ",
                                            assetCheckResult.swapQuote.outTokenInfo?.symbol || 'Output Token'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                        lineNumber: 84,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "최소 출력량 (슬리피지 포함): ",
                                            formatDisplayAmount(assetCheckResult.swapQuote.outAmountWithSlippage, assetCheckResult.swapQuote.outTokenInfo?.decimals || 9),
                                            " ",
                                            assetCheckResult.swapQuote.outTokenInfo?.symbol || 'Output Token'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                        lineNumber: 85,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 81,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-yellow-500",
                                children: "스왑 견적 정보를 불러오지 못했습니다."
                            }, void 0, false, {
                                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                                lineNumber: 89,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                        lineNumber: 77,
                        columnNumber: 11
                    }, this),
                    !assetCheckResult.needsSwap && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4 p-3 bg-green-900 bg-opacity-50 rounded border border-green-700",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-green-400 font-semibold",
                            children: "필요한 자산이 충분합니다. 스왑 없이 LP 생성이 가능합니다."
                        }, void 0, false, {
                            fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                            lineNumber: 95,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                        lineNumber: 94,
                        columnNumber: 12
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex space-x-4 mt-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                        onClick: ()=>{
                            setAssetCheckResult(null);
                            setCurrentStep(2);
                        },
                        children: "이전 (예치 설정)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${createLpLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleExecuteCreateLp,
                        disabled: createLpLoading,
                        children: createLpLoading ? 'LP 생성 중...' : assetCheckResult.needsSwap ? '자동 스왑 후 LP 생성' : 'LP 포지션 생성'
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/create/Step3AssetCheck.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = Step3AssetCheck;
var _c;
__turbopack_context__.k.register(_c, "Step3AssetCheck");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/lp/create/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>CreateLpPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"); // Added useCallback
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/authStore.ts [app-client] (ecmascript)");
// Import the new hooks and utility function
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePoolSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/usePoolSearch.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePriceRangeCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/usePriceRangeCalculation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAssetCheck$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useAssetCheck.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lpUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/lpUtils.ts [app-client] (ecmascript)");
// Import the new step components
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$create$2f$Step1PoolSelection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/lp/create/Step1PoolSelection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$create$2f$Step2DepositSettings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/lp/create/Step2DepositSettings.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$create$2f$Step3AssetCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/lp/create/Step3AssetCheck.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
function CreateLpPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { isLoggedIn, user, isLoading: isAuthLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const [currentStep, setCurrentStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [selectedPool, setSelectedPool] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [tokenCaInput, setTokenCaInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [totalSolValue, setTotalSolValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [solDepositRatioPercent, setSolDepositRatioPercent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('50');
    const [strategyType, setStrategyType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('Spot'); // Set default to 'Spot'
    const [createLpLoading, setCreateLpLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [pageError, setPageError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // Use a separate error state for the page component
    // Use the custom hooks unconditionally at the top level
    const { pools, poolsLoading, error: poolSearchError, fetchPoolsByToken, setPools, setError: setPoolSearchError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePoolSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePoolSearch"])();
    const { calculatedPriceRange, calculationLoading, calculationError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePriceRangeCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePriceRangeCalculation"])(selectedPool, totalSolValue, solDepositRatioPercent, strategyType);
    const { assetCheckResult, assetCheckLoading, assetCheckError, handleAssetCheck: performAssetCheck, setAssetCheckResult, setAssetCheckError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAssetCheck$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAssetCheck"])();
    // Combine errors from hooks and page-specific error
    const combinedError = pageError || poolSearchError || calculationError || assetCheckError;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CreateLpPage.useEffect": ()=>{
            if (!isAuthLoading && !isLoggedIn) {
                router.replace('/');
            }
        }
    }["CreateLpPage.useEffect"], [
        isAuthLoading,
        isLoggedIn,
        router
    ]);
    // Effect to clear asset check result when pool or deposit settings change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CreateLpPage.useEffect": ()=>{
            setAssetCheckResult(null);
            setAssetCheckError(null);
        }
    }["CreateLpPage.useEffect"], [
        selectedPool,
        totalSolValue,
        solDepositRatioPercent,
        strategyType,
        setAssetCheckResult,
        setAssetCheckError
    ]);
    const handlePoolSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CreateLpPage.useCallback[handlePoolSearch]": ()=>{
            setPageError(null); // Clear page error before search
            setPools([]); // Clear previous pools
            setSelectedPool(null); // Clear selected pool
            setAssetCheckResult(null); // Clear asset check result
            setAssetCheckError(null); // Clear asset check error
            fetchPoolsByToken(tokenCaInput);
        }
    }["CreateLpPage.useCallback[handlePoolSearch]"], [
        fetchPoolsByToken,
        setPools,
        setSelectedPool,
        setAssetCheckResult,
        setAssetCheckError,
        tokenCaInput
    ]); // Added dependencies
    const handleAssetCheckStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CreateLpPage.useCallback[handleAssetCheckStep]": async ()=>{
            setPageError(null); // Clear page error before asset check
            await performAssetCheck(selectedPool, tokenCaInput, totalSolValue, solDepositRatioPercent, strategyType, calculatedPriceRange);
            // The hook updates its internal state (assetCheckResult, assetCheckLoading, assetCheckError)
            // We will transition step based on the result in the render logic or another effect if needed,
            // but for simplicity, let's transition here if no immediate error from the hook call itself.
            // Note: The hook's error state will be checked in the combinedError.
            if (!assetCheckError && !assetCheckLoading) {
            // Check if assetCheckResult was set by the hook
            // This might require a slight delay or checking the hook's state after the async call
            // A better pattern might be to let the hook manage its state and react to it in the component.
            // Let's rely on the combinedError and assetCheckResult state update.
            // We'll transition in the render logic based on assetCheckResult being non-null.
            }
        }
    }["CreateLpPage.useCallback[handleAssetCheckStep]"], [
        selectedPool,
        tokenCaInput,
        totalSolValue,
        solDepositRatioPercent,
        strategyType,
        calculatedPriceRange,
        performAssetCheck,
        assetCheckError,
        assetCheckLoading
    ]); // Added dependencies
    const handleExecuteCreateLp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CreateLpPage.useCallback[handleExecuteCreateLp]": async ()=>{
            if (!selectedPool || !tokenCaInput || !totalSolValue || solDepositRatioPercent === undefined || !strategyType || !calculatedPriceRange || !assetCheckResult) {
                setPageError('필수 정보가 누락되었습니다. 이전 단계로 돌아가 다시 시도해주세요.');
                return;
            }
            setCreateLpLoading(true);
            setPageError(null);
            try {
                const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lpUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executeLpCreation"])(selectedPool, tokenCaInput, totalSolValue, solDepositRatioPercent, strategyType, calculatedPriceRange, assetCheckResult);
                alert('LP 포지션 생성 성공! 서명: ' + response.signature);
                router.push('/dashboard');
            } catch (error) {
                console.error('LP Creation Failed (page):', error);
                setPageError(error.message || 'LP 포지션 생성 중 알 수 없는 오류 발생');
            } finally{
                setCreateLpLoading(false);
            }
        }
    }["CreateLpPage.useCallback[handleExecuteCreateLp]"], [
        selectedPool,
        tokenCaInput,
        totalSolValue,
        solDepositRatioPercent,
        strategyType,
        calculatedPriceRange,
        assetCheckResult,
        router
    ]); // Added dependencies
    const handleBack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CreateLpPage.useCallback[handleBack]": ()=>{
            setCurrentStep({
                "CreateLpPage.useCallback[handleBack]": (prevStep)=>Math.max(1, prevStep - 1)
            }["CreateLpPage.useCallback[handleBack]"]);
        }
    }["CreateLpPage.useCallback[handleBack]"], []); // Added dependencies
    // Determine current step based on state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CreateLpPage.useEffect": ()=>{
            // Stay on Step 2 if selectedPool and basic deposit settings are valid, regardless of calculatedPriceRange
            const isStep2Ready = selectedPool && totalSolValue && solDepositRatioPercent !== undefined && strategyType;
            if (assetCheckResult) {
                setCurrentStep(3);
            } else if (isStep2Ready) {
                setCurrentStep(2);
            } else {
                setCurrentStep(1);
            }
        }
    }["CreateLpPage.useEffect"], [
        selectedPool,
        totalSolValue,
        solDepositRatioPercent,
        strategyType,
        calculatedPriceRange,
        assetCheckResult
    ]); // Keep calculatedPriceRange in dependencies as it's used in render logic
    const renderStep = ()=>{
        switch(currentStep){
            case 1:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$create$2f$Step1PoolSelection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    tokenCaInput: tokenCaInput,
                    setTokenCaInput: setTokenCaInput,
                    pools: pools,
                    poolsLoading: poolsLoading,
                    handlePoolSearch: handlePoolSearch,
                    selectedPool: selectedPool,
                    setSelectedPool: setSelectedPool,
                    setCurrentStep: setCurrentStep
                }, void 0, false, {
                    fileName: "[project]/src/app/lp/create/page.tsx",
                    lineNumber: 174,
                    columnNumber: 11
                }, this);
            case 2:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$create$2f$Step2DepositSettings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    selectedPool: selectedPool,
                    totalSolValue: totalSolValue,
                    setTotalSolValue: setTotalSolValue,
                    solDepositRatioPercent: solDepositRatioPercent,
                    setSolDepositRatioPercent: setSolDepositRatioPercent,
                    strategyType: strategyType,
                    setStrategyType: setStrategyType,
                    calculatedPriceRange: calculatedPriceRange,
                    calculationLoading: calculationLoading,
                    setCurrentStep: setCurrentStep,
                    handleAssetCheckStep: handleAssetCheckStep,
                    assetCheckLoading: assetCheckLoading
                }, void 0, false, {
                    fileName: "[project]/src/app/lp/create/page.tsx",
                    lineNumber: 187,
                    columnNumber: 11
                }, this);
            case 3:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$create$2f$Step3AssetCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    assetCheckResult: assetCheckResult,
                    assetCheckLoading: assetCheckLoading,
                    createLpLoading: createLpLoading,
                    handleExecuteCreateLp: handleExecuteCreateLp,
                    setCurrentStep: setCurrentStep,
                    setAssetCheckResult: setAssetCheckResult
                }, void 0, false, {
                    fileName: "[project]/src/app/lp/create/page.tsx",
                    lineNumber: 204,
                    columnNumber: 11
                }, this);
            default:
                return null;
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto p-4 pt-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center mb-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-4xl font-bold text-gray-100",
                    children: "LP 포지션 생성"
                }, void 0, false, {
                    fileName: "[project]/src/app/lp/create/page.tsx",
                    lineNumber: 221,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 220,
                columnNumber: 7
            }, this),
            combinedError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-4 rounded-md mb-4",
                children: combinedError
            }, void 0, false, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 225,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-orange-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8",
                children: renderStep()
            }, void 0, false, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 230,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/lp/create/page.tsx",
        lineNumber: 219,
        columnNumber: 5
    }, this);
}
_s(CreateLpPage, "tNHWpABV2Jkp+4k4Z2AeFDaIKv4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePoolSearch$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePoolSearch"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$usePriceRangeCalculation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePriceRangeCalculation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAssetCheck$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAssetCheck"]
    ];
});
_c = CreateLpPage;
var _c;
__turbopack_context__.k.register(_c, "CreateLpPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_7a7389d7._.js.map