(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_03b2bdcc._.js",
  "static/chunks/src_7a7389d7._.js"
],
    source: "dynamic"
});
