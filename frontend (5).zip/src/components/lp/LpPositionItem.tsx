"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { LpPosition } from '@/types/dlmm'; // Import the updated LpPosition type
import { PublicKey, Transaction, VersionedTransaction, TransactionInstruction, SystemProgram, Connection } from '@solana/web3.js'; // Import necessary Solana types
import { getAssociatedTokenAddress } from '@solana/spl-token'; // Import SPL token helper
import { useWallet } from '@solana/wallet-adapter-react'; // Assuming wallet adapter is used on frontend
import api from '@/lib/api'; // Correct default import for api client
import Decimal from 'decimal.js'; // For calculations

interface LpPositionItemProps {
  position: LpPosition;
  onPositionRemoved: (positionAddress: string) => void; // Callback after successful removal
}

// Helper to convert lamports to UI amount (can be shared or defined here)
// This helper is now primarily used for transaction building amounts if needed,
// as display amounts come pre-calculated from the backend.
function lamportsToUiAmount(lamports: string | number | bigint | undefined | null, decimals: number | undefined | null): string {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return '0';
    try {
        const amountDecimal = new Decimal(lamports.toString()).div(new Decimal(10).pow(decimals));
        return amountDecimal.toFixed(Math.min(decimals, 6)); // Example: show up to 6 decimals
    } catch (e) {
        console.error("Error formatting amount:", e);
        return 'Error';
    }
}

export default function LpPositionItem({ position, onPositionRemoved }: LpPositionItemProps) {
  const { publicKey: userPublicKey, signTransaction, sendTransaction } = useWallet(); // Assuming wallet adapter hooks
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // TODO: Obtain the actual Solana Connection object in the frontend context
  const connection = new Connection(process.env.NEXT_PUBLIC_SOLANA_RPC_URL || 'https://api.devnet.solana.com', 'confirmed'); // Placeholder

  // Display details are now received directly in the position prop
  // No need for a separate state or useEffect for calculations

  // useEffect(() => {
  //     // Calculation logic moved to backend
  // }, [position, connection]);


  const handleRemoveLiquidity = useCallback(async () => {
    if (!userPublicKey || !signTransaction) {
        setError('Wallet not connected or signing not supported.');
        return;
    }
    setIsLoading(true);
    setError(null);

    try {
        // TODO: Implement transaction building using frontend SDK
        // This involves:
        // 1. Fetching necessary accounts (LbPair, Position, BinArrays, ATAs, etc.)
        // 2. Using SDK functions (e.g., DLMMSDK.Instructions.RemoveLiquidity2Instruction.build) to create instructions
        // 3. Building a Transaction or VersionedTransaction
        // 4. Getting the latest blockhash using the frontend connection object
        // 5. Setting fee payer and blockhash
        // 6. Serializing the transaction

        console.warn("handleRemoveLiquidity: Transaction building placeholder.");

        // Placeholder: Create a dummy transaction for demonstration
        const dummyInstruction = new TransactionInstruction({
            keys: [], // Add necessary keys
            programId: SystemProgram.programId, // Use a dummy program ID
            data: Buffer.from([]), // Add instruction data
        });
        const latestBlockhash = await connection.getLatestBlockhash('confirmed'); // Use frontend connection
        const dummyTransaction = new Transaction().add(dummyInstruction);
        dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
        dummyTransaction.feePayer = userPublicKey;

        const serializedTransaction = dummyTransaction.serialize({ requireAllSignatures: false, verifySignatures: false }).toString('base64');

        // Send serialized transaction to backend for signing and sending
        const response = await api.post('/api/dlmm/process-transaction', { serializedTransaction });

        if (response.data && response.data.signature) { // Access signature via response.data
            alert(`LP 해제 성공! 서명: ${response.data.signature}`);
            onPositionRemoved(position.address); // Notify parent component
        } else {
            throw new Error('Transaction failed on backend.');
        }

    } catch (e: any) {
        console.error('Error removing liquidity:', e);
        setError(e.message || 'LP 해제 중 오류 발생');
    } finally {
        setIsLoading(false);
    }
  }, [position, userPublicKey, signTransaction, onPositionRemoved, connection]); // Add connection to dependencies


  const handleRemoveAndSwap = useCallback(async () => {
    if (!userPublicKey || !signTransaction) {
        setError('Wallet not connected or signing not supported.');
        return;
    }
    setIsLoading(true);
    setError(null);

    try {
        // TODO: Implement transaction building for remove + swap using frontend SDK
        // This involves:
        // 1. Building remove liquidity and claim fee instructions (similar to handleRemoveLiquidity)
        // 2. Building swap instructions using SDK (requires Jupiter quote)
        // 3. Combining instructions into a single transaction (if possible) or multiple transactions
        // 4. Getting the latest blockhash using the frontend connection object
        // 5. Setting fee payer and blockhash
        // 6. Serializing transaction(s)

        console.warn("handleRemoveAndSwap: Transaction building placeholder.");

        // Placeholder: Create a dummy transaction
         const dummyInstruction = new TransactionInstruction({
            keys: [], // Add necessary keys
            programId: SystemProgram.programId, // Use a dummy program ID
            data: Buffer.from([]), // Add instruction data
        });
        const latestBlockhash = await connection.getLatestBlockhash('confirmed'); // Use frontend connection
        const dummyTransaction = new Transaction().add(dummyInstruction);
        dummyTransaction.recentBlockhash = latestBlockhash.blockhash;
        dummyTransaction.feePayer = userPublicKey;

        const serializedTransaction = dummyTransaction.serialize({ requireAllSignatures: false, verifySignatures: false }).toString('base64');


        // Send serialized transaction(s) to backend
        const response = await api.post('/api/dlmm/process-transaction', { serializedTransaction });

         if (response.data && response.data.signature) { // Access signature via response.data
            alert(`LP 해제 및 스왑 성공! 서명: ${response.data.signature}`);
            onPositionRemoved(position.address); // Notify parent component
        } else {
            throw new Error('Transaction failed on backend.');
        }

    } catch (e: any) {
        console.error('Error removing liquidity and swapping:', e);
        setError(e.message || 'LP 해제 및 자동 스왑 중 오류 발생');
    } finally {
        setIsLoading(false);
    }
  }, [position, userPublicKey, signTransaction, onPositionRemoved, connection]); // Add connection to dependencies


  return (
    <div className="bg-gray-800 p-4 rounded-lg mb-4">
      <h3 className="text-lg font-semibold text-white mb-2">LP 포지션: {position.address.slice(0, 6)}...{position.address.slice(-6)}</h3>
      <p className="text-gray-300">풀: {position.pair_address.slice(0, 6)}...{position.pair_address.slice(-6)}</p>

      {/* Display calculated details from backend */}
      <p className="text-gray-300">가격 범위: {position.priceRange}</p>
      <p className="text-gray-300">총 가치 (SOL): {position.totalValueInSol}</p>
      <p className="text-gray-300">
        예치 금액: {position.totalXAmountUi} ({position.tokenXMint.slice(0, 4)}...) / {position.totalYAmountUi} ({position.tokenYMint.slice(0, 4)}...)
      </p>
      <p className="text-gray-300">
        미청구 수수료: {position.pendingFeeXUi} ({position.tokenXMint.slice(0, 4)}...) / {position.pendingFeeYUi} ({position.tokenYMint.slice(0, 4)}...)
      </p>
      {position.pendingRewardsUi.map((reward, index) => (
        <p key={index} className="text-gray-300">
          미청구 보상 {index + 1}: {reward.amount} ({reward.mint.slice(0, 4)}...)
        </p>
      ))}

      {error && (
        <div className="bg-red-500 text-white p-2 rounded-md mt-4 text-sm">
          {error}
        </div>
      )}

      <div className="flex space-x-2 mt-4">
        <button
          className={`bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          onClick={handleRemoveLiquidity}
          disabled={isLoading}
        >
          {isLoading ? '해제 중...' : 'LP 해제'}
        </button>
        <button
          className={`bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          onClick={handleRemoveAndSwap}
          disabled={isLoading}
        >
          {isLoading ? '해제 및 스왑 중...' : 'LP 해제 및 자동 스왑'}
        </button>
      </div>
    </div>
  );
}
