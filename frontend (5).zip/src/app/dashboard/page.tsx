"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { Connection, PublicKey } from '@solana/web3.js';
import useAuthStore from '@/store/authStore';
import { useRouter } from 'next/navigation';
import { useDlmmPositions } from '@/hooks/useDlmmPositions'; // Import the new hook
import LpPositionItem from '@/components/lp/LpPositionItem'; // Import LpPositionItem component

export default function DashboardPage() {
  const { publicKey: userPublicKey, connected } = useWallet();
  const { user, isLoggedIn, isLoading: isAuthLoading, logout } = useAuthStore();
  const router = useRouter();

  const [solBalance, setSolBalance] = useState<number | null>(null);

  // Use the new hook to fetch positions and related data, and expose fetchPositions for manual refresh
  const { positions, isLoading, error, totalSummary, fetchPositions } = useDlmmPositions(userPublicKey);

  // Redirect if not logged in
  useEffect(() => {
    if (!isAuthLoading && !isLoggedIn) {
      router.replace('/');
    }
  }, [isAuthLoading, isLoggedIn, router]);

  // Fetch SOL balance (Still needed, uses connection)
  useEffect(() => {
    const fetchSolBalance = async () => {
      if (userPublicKey) {
        try {
          const connection = new Connection(process.env.NEXT_PUBLIC_SOLANA_RPC_URL || 'https://api.devnet.solana.com', 'confirmed');
          const balance = await connection.getBalance(userPublicKey);
          setSolBalance(balance / 10 ** 9); // Convert lamports to SOL
        } catch (e) {
          console.error("Failed to fetch SOL balance:", e);
          setSolBalance(null);
        }
      } else {
        setSolBalance(null);
      }
    };
    fetchSolBalance();
  }, [userPublicKey]);

  const handleLogout = useCallback(() => {
      logout();
      router.push('/');
  }, [logout, router]);

  // Placeholder functions for LP actions (can be updated later to use hook data/actions)
  const handleExportPrivateKey = useCallback(async () => {
      // TODO: Implement actual private key export logic
      console.log('개인 키 내보내기 기능은 현재 초기화되었습니다.');
  }, []);

  const handleRemoveAllLp = useCallback(async () => {
      // TODO: Implement actual remove all LP logic using hook/SDK
      console.log('모든 LP 포지션 정리 기능은 현재 초기화되었습니다.');
  }, []);

  const handleRemoveAllLpAndSwap = useCallback(async () => {
      // TODO: Implement actual remove all LP and swap logic using hook/SDK
      console.log('모든 LP 포지션 정리 및 스왑 기능은 현재 초기화되었습니다.');
  }, []);


  if (!connected) {
    return (
      <div className="container mx-auto p-4 pt-20 text-center text-gray-300">
        <p>지갑을 연결하여 LP 포지션을 확인하세요.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 pt-20">
      <h1 className="text-4xl font-bold text-gray-100 mb-8">대시보드</h1>

      {error && (
        <div className="bg-red-500 text-white p-4 rounded-md mb-4">
          {error}
        </div>
      )}

      <div className="bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8">
          <h2 className="text-2xl font-semibold text-white mb-4">사용자 정보 및 지갑</h2>
          {user?.id && <p>사용자 ID: {user.id}</p>}
          {userPublicKey && <p>지갑 주소: {userPublicKey.toBase58()}</p>}
          {solBalance !== null && <p>SOL 잔액: {solBalance?.toFixed(4)}</p>}
          <div className="flex space-x-4 mt-4">
              <button
                  className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                  onClick={() => router.push('/lp/create')}
              >
                  새 LP 포지션 생성
              </button>
               <button
                  className="bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                  onClick={handleExportPrivateKey}
                  disabled={!userPublicKey || isLoading}
              >
                   개인 키 내보내기
              </button>
               <button
                  className="bg-red-600 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                  onClick={handleLogout}
               >
                   로그아웃
               </button>
           </div>
       </div>

       <h2 className="text-2xl font-semibold text-gray-100 mb-4">나의 LP 포지션</h2>

       {/* Refresh Button */}
       <div className="mb-4">
            <button
                className={`bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={fetchPositions} // Call fetchPositions from the hook
                disabled={isLoading}
            >
                {isLoading ? '새로고침 중...' : 'LP 포지션 새로고침'}
            </button>
       </div>


      {/* Display Total Summary */}
      <div className="bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8">
          <h3 className="text-xl font-semibold text-white mb-4">요약</h3>
          <p>총 포지션 수: {totalSummary.totalPositions}</p>
          <p>범위 내 포지션 수: {totalSummary.inRangePositions}</p>
          <p>총 유동성 가치: ${totalSummary.totalLiquidityValue.toFixed(2)}</p>
          <p>총 미청구 수수료: ${totalSummary.totalUnclaimedFees.toFixed(2)}</p>
          <p>총 초기 투자 가치: ${totalSummary.totalInitialValue.toFixed(2)}</p>

       </div>


       <div className="mb-4 flex space-x-4">
            <button
              className={`bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              onClick={handleRemoveAllLp}
              disabled={isLoading || positions.length === 0}
            >
               모든 LP 포지션 한번에 정리하기 (더미)
            </button>
             <button
              className={`bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              onClick={handleRemoveAllLpAndSwap}
              disabled={isLoading || positions.length === 0}
            >
               모든 LP 포지션 한번에 정리 및 SOL로 전부 자동 스왑 (더미)
            </button>
      </div>


      {isLoading ? (
        <p className="text-gray-300">LP 포지션을 불러오는 중...</p>
      ) : error ? (
        <div className="bg-red-500 text-white p-4 rounded-md mb-4">
          {error}
        </div>
      ) : positions.length === 0 ? (
        <p className="text-gray-300">활성화된 LP 포지션이 없습니다.</p>
      ) : (
        <div className="space-y-4">
          {positions.map(position => (
            <LpPositionItem
              key={position.address}
              position={position}
              onPositionRemoved={() => console.log('Placeholder onPositionRemoved triggered')} // Add placeholder prop
            />
          ))}
        </div>
      )}

    </div>
  );
}
