import React from 'react';
import { StrategyType } from '@meteora-ag/dlmm';

interface Pool {
  poolAddress: string;
  binStep: number;
  current_price: number;
  name: string;
  // Include other necessary pool properties
}

interface PriceRangeResult {
  minPrice: string;
  maxPrice: string;
  // Include other necessary price range properties
}

interface Step2DepositSettingsProps {
  selectedPool: Pool | null;
  totalSolValue: string;
  setTotalSolValue: (value: string) => void;
  solDepositRatioPercent: string;
  setSolDepositRatioPercent: (value: string) => void;
  strategyType: keyof typeof StrategyType;
  setStrategyType: (value: keyof typeof StrategyType) => void;
  calculatedPriceRange: PriceRangeResult | null;
  calculationLoading: boolean;
  setCurrentStep: (step: number) => void;
  handleAssetCheckStep: () => Promise<void>;
  assetCheckLoading: boolean; // Need this to disable the button
}

export default function Step2DepositSettings({
  selectedPool,
  totalSolValue,
  setTotalSolValue,
  solDepositRatioPercent,
  setSolDepositRatioPercent,
  strategyType,
  setStrategyType,
  calculatedPriceRange,
  calculationLoading,
  setCurrentStep,
  handleAssetCheckStep,
  assetCheckLoading,
}: Step2DepositSettingsProps) {
  console.log('[Step2DepositSettings] Rendering. selectedPool:', selectedPool, 'totalSolValue:', totalSolValue, 'solDepositRatioPercent:', solDepositRatioPercent, 'strategyType:', strategyType, 'calculatedPriceRange:', calculatedPriceRange);
  return (
    <>
      <h2 className="text-2xl font-semibold text-white mb-4">단계 2: 예치 설정</h2>
      {selectedPool && (
        <div className="mb-4 p-3 bg-gray-800 rounded">
          <p><strong>선택된 풀:</strong> {selectedPool.name || selectedPool.poolAddress}</p>
          <p><strong>Bin Step:</strong> {selectedPool.binStep}</p>
          <p><strong>현재 가격 (Y/X):</strong> {selectedPool.current_price !== undefined ? selectedPool.current_price.toFixed(10) : 'N/A'}</p>
        </div>
      )}
      <div className="mb-4">
        <label htmlFor="totalSolValue" className="block text-gray-300 text-sm font-bold mb-2">
          총 예치 가치 (SOL 기준):
        </label>
        <input
          type="number"
          id="totalSolValue"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          value={totalSolValue}
          onChange={(e) => setTotalSolValue(e.target.value)}
          placeholder="예: 10"
          min="0"
          step="any"
        />
      </div>
      <div className="mb-4">
        <label htmlFor="solDepositRatio" className="block text-gray-300 text-sm font-bold mb-2">
          SOL 예치 비율 (%): {solDepositRatioPercent}%
        </label>
        <input
          type="range"
          id="solDepositRatio"
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
          min="0"
          max="100"
          value={solDepositRatioPercent}
          onChange={(e) => setSolDepositRatioPercent(e.target.value)}
        />
      </div>
      <div className="mb-4">
        <label htmlFor="strategyType" className="block text-gray-300 text-sm font-bold mb-2">
          전략 선택:
        </label>
        <select
          id="strategyType"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          value={strategyType}
          onChange={(e) => setStrategyType(e.target.value as keyof typeof StrategyType)}
        >
          {Object.keys(StrategyType).map(key => (
            <option key={key} value={key}>
              {key}
            </option>
          ))}
        </select>
      </div>

      {calculationLoading && <p className="text-gray-400">가격 범위 계산 중...</p>}
      {!calculationLoading && calculatedPriceRange && (
        <div className="mb-4 text-green-400">
          <p><strong>계산된 가격 범위 (Y/X):</strong> {parseFloat(calculatedPriceRange.minPrice).toFixed(10)} ~ {parseFloat(calculatedPriceRange.maxPrice).toFixed(10)}</p>
        </div>
      )}
      {!calculationLoading && !calculatedPriceRange && parseFloat(totalSolValue) > 0 && (
           <p className="text-yellow-400">가격을 계산 중이거나, 입력값을 확인해주세요.</p>
      )}
      {!calculationLoading && !calculatedPriceRange && (!totalSolValue || parseFloat(totalSolValue) <= 0) && (
        <div className="mb-4 text-gray-400">
         <p><strong>가격 범위:</strong> 총 예치 가치를 입력하시면 가격 범위가 자동 계산됩니다.</p>
        </div>
      )}

      <div className="flex space-x-4 mt-6">
        <button
          className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
          onClick={() => setCurrentStep(1)}
        >
          이전 (풀 선택)
        </button>
        <button
          className={`bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${assetCheckLoading || calculationLoading || !selectedPool || !totalSolValue || !strategyType || !calculatedPriceRange ? 'opacity-50 cursor-not-allowed' : ''}`}
          onClick={handleAssetCheckStep}
          disabled={assetCheckLoading || calculationLoading || !selectedPool || !totalSolValue || !strategyType || !calculatedPriceRange}
        >
          {assetCheckLoading ? '자산 확인 중...' : '다음 (자산 확인)'}
        </button>
      </div>
    </>
  );
}
