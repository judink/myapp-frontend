"use client";

import React, { useState, useEffect, useCallback } from 'react'; // Added useCallback
import { useRouter } from 'next/navigation';
import useAuthStore from '@/store/authStore';
import { StrategyType } from '@meteora-ag/dlmm';
import Decimal from 'decimal.js';
import { NATIVE_MINT } from '@solana/spl-token';

// Import the new hooks and utility function
import { usePoolSearch } from '@/hooks/usePoolSearch';
import { usePriceRangeCalculation } from '@/hooks/usePriceRangeCalculation';
import { useAssetCheck } from '@/hooks/useAssetCheck';
import { executeLpCreation } from '@/utils/lpUtils';

// Import the new step components
import Step1PoolSelection from '@/components/lp/create/Step1PoolSelection';
import Step2DepositSettings from '@/components/lp/create/Step2DepositSettings';
import Step3AssetCheck from '@/components/lp/create/Step3AssetCheck';


interface Pool {
  poolAddress: string;
  tokenX: string;
  tokenY: string;
  tokenXMint: string;
  tokenYMint: string;
  binStep: number;
  baseFeeBps: number;
  name: string;
  liquidity: number;
  trade_volume_24h: number;
  current_price: number;
}

// Re-define necessary types if not imported globally or from a shared file
interface PriceRangeResult {
  minPrice: string;
  maxPrice: string;
  minBinId: number;
  maxBinId: number;
}

interface AssetCheckResult {
  needsSwap: boolean;
  requiredAssets: {
    solLamports: string;
    targetTokenLamports: string;
    tokenCa: string;
    tokenDecimals: number;
  };
  currentBalances: {
    solLamports: string;
    targetTokenLamports: string;
  };
  swapQuote: any | null;
}


export default function CreateLpPage() {
  const router = useRouter();
  const { isLoggedIn, user, isLoading: isAuthLoading } = useAuthStore();

  const [currentStep, setCurrentStep] = useState(1);
  const [selectedPool, setSelectedPool] = useState<Pool | null>(null);
  const [tokenCaInput, setTokenCaInput] = useState('');
  const [totalSolValue, setTotalSolValue] = useState('');
  const [solDepositRatioPercent, setSolDepositRatioPercent] = useState('50');
  const [strategyType, setStrategyType] = useState<keyof typeof StrategyType>('Spot');
  const [createLpLoading, setCreateLpLoading] = useState(false);
  const [pageError, setPageError] = useState<string | null>(null); // Use a separate error state for the page component

  // Use the custom hooks unconditionally at the top level
  const { pools, poolsLoading, error: poolSearchError, fetchPoolsByToken, setPools, setError: setPoolSearchError } = usePoolSearch();
  const { calculatedPriceRange, calculationLoading, calculationError } = usePriceRangeCalculation(selectedPool, totalSolValue, solDepositRatioPercent, strategyType);
  const { assetCheckResult, assetCheckLoading, assetCheckError, handleAssetCheck: performAssetCheck, setAssetCheckResult, setAssetCheckError } = useAssetCheck();


  // Combine errors from hooks and page-specific error
  const combinedError = pageError || poolSearchError || calculationError || assetCheckError;

  useEffect(() => {
    if (!isAuthLoading && !isLoggedIn) {
      router.replace('/');
    }
  }, [isAuthLoading, isLoggedIn, router]);

  // Effect to clear asset check result when pool or deposit settings change
  useEffect(() => {
    setAssetCheckResult(null);
    setAssetCheckError(null);
  }, [selectedPool, totalSolValue, solDepositRatioPercent, strategyType, setAssetCheckResult, setAssetCheckError]);


  const handlePoolSearch = useCallback(() => { // Added useCallback
    setPageError(null); // Clear page error before search
    setPools([]); // Clear previous pools
    setSelectedPool(null); // Clear selected pool
    setAssetCheckResult(null); // Clear asset check result
    setAssetCheckError(null); // Clear asset check error
    fetchPoolsByToken(tokenCaInput);
  }, [fetchPoolsByToken, setPools, setSelectedPool, setAssetCheckResult, setAssetCheckError, tokenCaInput]); // Added dependencies


  const handleAssetCheckStep = useCallback(async () => { // Added useCallback
     setPageError(null); // Clear page error before asset check
     await performAssetCheck(selectedPool, tokenCaInput, totalSolValue, solDepositRatioPercent, strategyType, calculatedPriceRange);
     // The hook updates its internal state (assetCheckResult, assetCheckLoading, assetCheckError)
     // We will transition step based on the result in the render logic or another effect if needed,
     // but for simplicity, let's transition here if no immediate error from the hook call itself.
     // Note: The hook's error state will be checked in the combinedError.
     if (!assetCheckError && !assetCheckLoading) { // Only transition if no immediate error and not loading
        // Check if assetCheckResult was set by the hook
        // This might require a slight delay or checking the hook's state after the async call
        // A better pattern might be to let the hook manage its state and react to it in the component.
        // Let's rely on the combinedError and assetCheckResult state update.
        // We'll transition in the render logic based on assetCheckResult being non-null.
     }
  }, [selectedPool, tokenCaInput, totalSolValue, solDepositRatioPercent, strategyType, calculatedPriceRange, performAssetCheck, assetCheckError, assetCheckLoading]); // Added dependencies


  const handleExecuteCreateLp = useCallback(async () => { // Added useCallback
    if (!selectedPool || !tokenCaInput || !totalSolValue || solDepositRatioPercent === undefined || !strategyType || !calculatedPriceRange || !assetCheckResult) {
      setPageError('필수 정보가 누락되었습니다. 이전 단계로 돌아가 다시 시도해주세요.');
      return;
    }
    setCreateLpLoading(true);
    setPageError(null);
    try {
      const response = await executeLpCreation(
        selectedPool,
        tokenCaInput,
        totalSolValue,
        solDepositRatioPercent,
        strategyType,
        calculatedPriceRange,
        assetCheckResult
      );
      alert('LP 포지션 생성 성공! 서명: ' + response.signature);
      router.push('/dashboard');
    } catch (error: any) {
      console.error('LP Creation Failed (page):', error);
      setPageError(error.message || 'LP 포지션 생성 중 알 수 없는 오류 발생');
    } finally {
      setCreateLpLoading(false);
    }
  }, [selectedPool, tokenCaInput, totalSolValue, solDepositRatioPercent, strategyType, calculatedPriceRange, assetCheckResult, router]); // Added dependencies


  const handleBack = useCallback(() => { // Added useCallback
    setCurrentStep(prevStep => Math.max(1, prevStep - 1));
  }, []); // Added dependencies


  // Determine current step based on state
  useEffect(() => {
    // Stay on Step 2 if selectedPool and basic deposit settings are valid, regardless of calculatedPriceRange
    const isStep2Ready = selectedPool && totalSolValue && solDepositRatioPercent !== undefined && strategyType;

    if (assetCheckResult) {
      setCurrentStep(3);
    } else if (isStep2Ready) {
      setCurrentStep(2);
    } else {
      setCurrentStep(1);
    }
  }, [selectedPool, totalSolValue, solDepositRatioPercent, strategyType, calculatedPriceRange, assetCheckResult]); // Keep calculatedPriceRange in dependencies as it's used in render logic


  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <Step1PoolSelection
            tokenCaInput={tokenCaInput}
            setTokenCaInput={setTokenCaInput}
            pools={pools}
            poolsLoading={poolsLoading}
            handlePoolSearch={handlePoolSearch}
            selectedPool={selectedPool}
            setSelectedPool={setSelectedPool}
            setCurrentStep={setCurrentStep}
          />
        );
      case 2:
        return (
          <Step2DepositSettings
            selectedPool={selectedPool}
            totalSolValue={totalSolValue}
            setTotalSolValue={setTotalSolValue}
            solDepositRatioPercent={solDepositRatioPercent}
            setSolDepositRatioPercent={setSolDepositRatioPercent}
            strategyType={strategyType}
            setStrategyType={setStrategyType}
            calculatedPriceRange={calculatedPriceRange}
            calculationLoading={calculationLoading}
            setCurrentStep={setCurrentStep}
            handleAssetCheckStep={handleAssetCheckStep}
            assetCheckLoading={assetCheckLoading} // Pass assetCheckLoading to disable button
          />
        );
      case 3:
        return (
          <Step3AssetCheck
            assetCheckResult={assetCheckResult}
            assetCheckLoading={assetCheckLoading}
            createLpLoading={createLpLoading}
            handleExecuteCreateLp={handleExecuteCreateLp}
            setCurrentStep={setCurrentStep}
            setAssetCheckResult={setAssetCheckResult}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-4 pt-20">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-gray-100">LP 포지션 생성</h1>
      </div>

      {combinedError && (
        <div className="bg-red-500 text-white p-4 rounded-md mb-4">
          {combinedError}
        </div>
      )}

      <div className="bg-orange-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8">
        {renderStep()}
      </div>
    </div>
  );
}
