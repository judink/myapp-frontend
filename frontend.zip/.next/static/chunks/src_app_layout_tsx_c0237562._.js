(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__c9cfa9d6._.css",
  "static/chunks/node_modules_@solflare-wallet_5400129e._.js",
  "static/chunks/node_modules_axios_lib_99999129._.js",
  "static/chunks/node_modules_@noble_curves_esm_d476331b._.js",
  "static/chunks/node_modules_@solana_web3_js_lib_index_browser_esm_88d65ea0.js",
  "static/chunks/node_modules_@solana_3f633493._.js",
  "static/chunks/node_modules_@solana-mobile_67f20ee4._.js",
  "static/chunks/node_modules_6289ecf8._.js",
  "static/chunks/src_67f07d9c._.js"
],
    source: "dynamic"
});
