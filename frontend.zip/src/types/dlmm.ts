// src/types/dlmm.ts

export interface LbPosition {
  positionAddress: string;
  lbPairAddress: string; // 백엔드에서 'N/A' 또는 실제 주소를 반환할 수 있음
  totalXAmount: string;  // BN.toString() 결과이므로 string 타입
  totalYAmount: string;  // BN.toString() 결과이므로 string 타입
  feeX: string;          // BN.toString() 결과이므로 string 타입
  feeY: string;          // BN.toString() 결과이므로 string 타입
  rewardOne: string;     // BN.toString() 결과이므로 string 타입
  rewardTwo: string;     // BN.toString() 결과이므로 string 타입
  lowerBinId: number;
  upperBinId: number;
  binStep?: number; // 백엔드에서 추가된 binStep 정보
  tokenXDecimals?: number; // 백엔드에서 추가된 tokenX decimals 정보 (추가)
  tokenYDecimals?: number; // 백엔드에서 추가된 tokenY decimals 정보 (추가)
  // 필요에 따라 토큰 심볼, 페어 이름 등 추가 정보를 포함할 수 있습니다.
  // 예: tokenXSymbol?: string;
  // 예: tokenYSymbol?: string;
}

// 필요하다면 다른 DLMM 관련 타입들도 여기에 정의할 수 있습니다.
// 예: interface DlmmPoolInfo { ... }
