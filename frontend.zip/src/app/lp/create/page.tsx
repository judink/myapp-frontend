"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import useAuthStore from '@/store/authStore';
import apiClient from '@/lib/api'; 
// import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js'; // 서버에서 잔액 조회하므로 Connection, LAMPORTS_PER_SOL 불필요
// import { useWallet } from '@solana/wallet-adapter-react'; // 서버 관리 지갑 사용으로 불필요
// import { WalletMultiButton } from '@solana/wallet-adapter-react-ui'; // 서버 관리 지갑 사용으로 불필요
import { StrategyType } from '@meteora-ag/dlmm'; 
import Decimal from 'decimal.js'; 
import { NATIVE_MINT } from '@solana/spl-token'; // AccountLayout 등도 불필요
import axios from 'axios'; 
import debounce from 'lodash.debounce'; 

interface Pool {
  poolAddress: string;
  tokenX: string; 
  tokenY: string; 
  tokenXMint: string; 
  tokenYMint: string; 
  binStep: number;
  baseFeeBps: number;
  name: string;
  liquidity: number;
  trade_volume_24h: number;
  current_price: number; 
}

// const SOLANA_RPC_URL = process.env.NEXT_PUBLIC_SOLANA_RPC_URL || 'https://api.devnet.solana.com'; // 클라이언트 직접 연결 불필요
// const connection = new Connection(SOLANA_RPC_URL, 'confirmed');
// console.log(`Using Solana RPC URL: ${SOLANA_RPC_URL}`); 

export default function CreateLpPage() {
  const router = useRouter();
  const { isLoggedIn, user, isLoading: isAuthLoading } = useAuthStore(); // user 정보 사용 가능성
  // const wallet = useWallet(); // 서버 관리 지갑 사용으로 불필요
  const [currentStep, setCurrentStep] = useState(1); 
  const [pools, setPools] = useState<Pool[]>([]);
  const [poolsLoading, setPoolsLoading] = useState(false);
  const [selectedPool, setSelectedPool] = useState<Pool | null>(null);
  const [tokenCaInput, setTokenCaInput] = useState('');
  const [totalSolValue, setTotalSolValue] = useState('');
  const [solDepositRatioPercent, setSolDepositRatioPercent] = useState('50');
  const [strategyType, setStrategyType] = useState<keyof typeof StrategyType>('Spot');
  const [calculatedPriceRange, setCalculatedPriceRange] = useState<{ minPrice: string; maxPrice: string; minBinId: number; maxBinId: number } | null>(null);
  const [assetCheckResult, setAssetCheckResult] = useState<any | null>(null); 
  // const [displayBalances, setDisplayBalances] = useState<{ sol: string; target: string } | null>(null); // assetCheckResult.currentBalances 사용
  const [calculationLoading, setCalculationLoading] = useState(false); 
  const [assetCheckLoading, setAssetCheckLoading] = useState(false); 
  const [createLpLoading, setCreateLpLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // const [autoSwapConfirmed, setAutoSwapConfirmed] = useState(false); // 사용자 요청으로 제거됨

  useEffect(() => {
    if (!isAuthLoading && !isLoggedIn) {
      router.replace('/');
    }
  }, [isAuthLoading, isLoggedIn, router]);

  // fetchTokenBalanceForDisplay 함수는 더 이상 프론트엔드에서 필요 없음

  // useEffect для displayBalances는 더 이상 필요 없음, assetCheckResult.currentBalances를 직접 사용

  const fetchPoolsByToken = async () => {
    if (!tokenCaInput) {
      setError('대상 토큰 민트 주소를 입력해주세요.');
      setPools([]);
      setSelectedPool(null);
      return;
    }
    setPoolsLoading(true);
    setError(null);
    setPools([]);
    setSelectedPool(null);
    try {
      const meteoraApiUrl = `https://dlmm-api.meteora.ag/pair/all_by_groups?include_pool_token_pairs=${tokenCaInput}-${NATIVE_MINT.toBase58()}`;
      console.log(`Fetching pools from Meteora API (frontend): ${meteoraApiUrl}`);
      const response = await axios.get(meteoraApiUrl, { headers: { 'accept': 'application/json' } });
      const apiResponse = response.data;
      console.log("Meteora API response received (frontend).");
      const relevantPairs = apiResponse.groups.flatMap((group: any) =>
        group.pairs.map((pair: any) => ({
          poolAddress: pair.address,
          tokenX: pair.name?.split('/')[0] || pair.mint_x.substring(0,4),
          tokenY: pair.name?.split('/')[1] || pair.mint_y.substring(0,4),
          tokenXMint: pair.mint_x,
          tokenYMint: pair.mint_y,
          binStep: pair.bin_step,
          baseFeeBps: parseFloat(pair.base_fee_percentage) * 100,
          name: pair.name,
          liquidity: parseFloat(pair.liquidity),
          trade_volume_24h: pair.trade_volume_24h,
          current_price: pair.current_price,
        }))
      );
      relevantPairs.sort((a: Pool, b: Pool) => b.liquidity - a.liquidity);
      setPools(relevantPairs);
      if (relevantPairs.length === 0) {
        setError('입력하신 토큰 페어에 해당하는 풀을 찾을 수 없습니다.');
      }
    } catch (error: any) {
      console.error('Failed to fetch pools by token from Meteora API (frontend):', error);
      const errorMessage = error.response?.data?.message || error.message;
      setError(`풀 목록을 불러오는 데 실패했습니다: ${errorMessage}`);
    } finally {
      setPoolsLoading(false);
    }
  };

  const calculatePriceRange = useCallback(
    debounce(async () => {
      console.log('[calculatePriceRange] Called. selectedPool:', selectedPool, 'totalSolValue:', totalSolValue, 'solDepositRatioPercent:', solDepositRatioPercent, 'strategyType:', strategyType);
      const parsedTotalSolValue = parseFloat(totalSolValue);
      if (!selectedPool || !totalSolValue || isNaN(parsedTotalSolValue) || parsedTotalSolValue <= 0 || solDepositRatioPercent === undefined || !strategyType || selectedPool.current_price === undefined) {
        console.log('[calculatePriceRange] Conditions not met (e.g., totalSolValue invalid or other params missing), setting calculatedPriceRange to null.');
        setCalculatedPriceRange(null);
        return;
      }
      setCalculationLoading(true);
      setError(null);
      try {
        const response = await apiClient.post('/api/dlmm/calculate-price-range', {
          poolAddress: selectedPool.poolAddress,
          currentPrice: selectedPool.current_price.toString(),
          binStep: selectedPool.binStep,
          solDepositRatioPercent: solDepositRatioPercent,
          strategyType: strategyType,
        });
        setCalculatedPriceRange(response.data);
      } catch (error: any) {
        console.error('Failed to calculate price range:', error);
        setError(`가격 범위 계산 실패: ${error.response?.data?.message || error.message}`);
        setCalculatedPriceRange(null);
      } finally {
        setCalculationLoading(false);
      }
    }, 500),
    [selectedPool, totalSolValue, solDepositRatioPercent, strategyType]
  );

  useEffect(() => {
    calculatePriceRange();
    return () => {
      calculatePriceRange.cancel();
    };
  }, [selectedPool, totalSolValue, solDepositRatioPercent, strategyType, calculatePriceRange]);

  const handleAssetCheck = async () => {
    if (!selectedPool || !tokenCaInput || !totalSolValue || solDepositRatioPercent === undefined || !strategyType || !calculatedPriceRange || calculatedPriceRange.minBinId === undefined || calculatedPriceRange.maxBinId === undefined) {
      setError('모든 필수 정보를 입력하고 가격 범위를 계산해주세요.');
      return;
    }
    setAssetCheckLoading(true);
    setError(null);
    setAssetCheckResult(null);
    try {
      const response = await apiClient.post('/api/dlmm/lp/create', {
        poolAddress: selectedPool.poolAddress,
        tokenCa: tokenCaInput,
        totalSolValue: totalSolValue,
        solDepositRatioPercent: solDepositRatioPercent,
        strategyType: strategyType,
        minBinId: calculatedPriceRange.minBinId,
        maxBinId: calculatedPriceRange.maxBinId,
        executeLpCreation: false,
      });
      setAssetCheckResult(response.data);
      setCurrentStep(3);
    } catch (error: any) {
      console.error('Asset Check Failed:', error);
      setError(`자산 확인 실패: ${error.response?.data?.message || error.message}`);
    } finally {
      setAssetCheckLoading(false);
    }
  };

  const handleExecuteCreateLp = async () => {
    if (!selectedPool || !tokenCaInput || !totalSolValue || solDepositRatioPercent === undefined || !strategyType || !calculatedPriceRange || !assetCheckResult) {
      setError('필수 정보가 누락되었습니다. 이전 단계로 돌아가 다시 시도해주세요.');
      return;
    }
    setCreateLpLoading(true);
    setError(null);
    try {
      const response = await apiClient.post('/api/dlmm/lp/create', {
        poolAddress: selectedPool.poolAddress,
        tokenCa: tokenCaInput,
        totalSolValue: totalSolValue,
        solDepositRatioPercent: solDepositRatioPercent,
        strategyType: strategyType,
        minBinId: calculatedPriceRange.minBinId, // 이 Bin ID는 참고용
        maxBinId: calculatedPriceRange.maxBinId, // 이 Bin ID는 참고용
        targetMinPrice: calculatedPriceRange.minPrice, // 목표 Y/X 순수 최소 가격 전달
        targetMaxPrice: calculatedPriceRange.maxPrice, // 목표 Y/X 순수 최대 가격 전달
        executeLpCreation: true,
      });
      console.log('LP Creation Response:', response.data);
      alert('LP 포지션 생성 성공! 서명: ' + response.data.signature);
      router.push('/dashboard');
    } catch (error: any) {
      console.error('LP Creation Failed:', error);
      setError(`LP 포지션 생성 실패: ${error.response?.data?.message || error.message}`);
    } finally {
      setCreateLpLoading(false);
    }
  };

  if (isAuthLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-lg text-gray-600">인증 정보를 불러오는 중...</p>
      </div>
    );
  }

  if (!isLoggedIn) {
    return null;
  }

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <>
            <h2 className="text-2xl font-semibold text-white mb-4">단계 1: 토큰 선택 및 풀 검색</h2>
            <div className="mb-4">
              <label htmlFor="tokenCaInput" className="block text-gray-300 text-sm font-bold mb-2">
                대상 토큰 (Y) 민트 주소:
              </label>
              <input
                type="text"
                id="tokenCaInput"
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                value={tokenCaInput}
                onChange={(e) => setTokenCaInput(e.target.value)}
                placeholder="예: 대상 토큰 민트 주소"
              />
              <button
                className="mt-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                onClick={fetchPoolsByToken}
                disabled={poolsLoading}
              >
                {poolsLoading ? '풀 검색 중...' : '풀 검색'}
              </button>
            </div>
            {poolsLoading ? (
              <p>풀 목록을 불러오는 중...</p>
            ) : pools.length === 0 && tokenCaInput ? (
              <p>입력하신 토큰 페어에 해당하는 풀을 찾을 수 없습니다.</p>
            ) : pools.length > 0 ? (
              <div className="mb-4">
                <label htmlFor="poolSelect" className="block text-gray-300 text-sm font-bold mb-2">
                  풀 선택:
                </label>
                <select
                  id="poolSelect"
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  value={selectedPool?.poolAddress || ''}
                  onChange={(e) => {
                    const pool = pools.find(p => p.poolAddress === e.target.value);
                    setSelectedPool(pool || null);
                  }}
                >
                  <option value="" disabled>풀을 선택해주세요</option>
                  {pools.map(pool => (
                    <option key={pool.poolAddress} value={pool.poolAddress}>
                      {`${pool.name || `${pool.tokenX.substring(0, 4)}/${pool.tokenY.substring(0, 4)}`} - Liquidity: ${pool.liquidity.toFixed(2)} - 24h Volume: ${pool.trade_volume_24h.toFixed(2)}`}
                    </option>
                  ))}
                </select>
              </div>
            ) : null}
            <button
              className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
              onClick={() => setCurrentStep(2)}
              disabled={!selectedPool || poolsLoading}
            >
              다음
            </button>
          </>
        );
      case 2:
        console.log('[renderStep Case 2] Rendering. selectedPool:', selectedPool, 'totalSolValue:', totalSolValue, 'solDepositRatioPercent:', solDepositRatioPercent, 'strategyType:', strategyType, 'calculatedPriceRange:', calculatedPriceRange);
        return (
          <>
            <h2 className="text-2xl font-semibold text-white mb-4">단계 2: 예치 설정</h2>
            {selectedPool && (
              <div className="mb-4 p-3 bg-gray-800 rounded">
                <p><strong>선택된 풀:</strong> {selectedPool.name || selectedPool.poolAddress}</p>
                <p><strong>Bin Step:</strong> {selectedPool.binStep}</p>
                <p><strong>현재 가격 (Y/X):</strong> {selectedPool.current_price !== undefined ? selectedPool.current_price.toFixed(10) : 'N/A'}</p>
              </div>
            )}
            <div className="mb-4">
              <label htmlFor="totalSolValue" className="block text-gray-300 text-sm font-bold mb-2">
                총 예치 가치 (SOL 기준):
              </label>
              <input
                type="number"
                id="totalSolValue"
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                value={totalSolValue}
                onChange={(e) => setTotalSolValue(e.target.value)}
                placeholder="예: 10"
                min="0"
                step="any"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="solDepositRatio" className="block text-gray-300 text-sm font-bold mb-2">
                SOL 예치 비율 (%): {solDepositRatioPercent}%
              </label>
              <input
                type="range"
                id="solDepositRatio"
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                min="0"
                max="100"
                value={solDepositRatioPercent}
                onChange={(e) => setSolDepositRatioPercent(e.target.value)}
              />
            </div>
            <div className="mb-4">
              <label htmlFor="strategyType" className="block text-gray-300 text-sm font-bold mb-2">
                전략 선택:
              </label>
              <select
                id="strategyType"
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                value={strategyType}
                onChange={(e) => setStrategyType(e.target.value as keyof typeof StrategyType)}
              >
                {Object.keys(StrategyType).map(key => (
                  <option key={key} value={key}>
                    {key}
                  </option>
                ))}
              </select>
            </div>
            
            {calculationLoading && <p className="text-gray-400">가격 범위 계산 중...</p>}
            {!calculationLoading && calculatedPriceRange && (
              <div className="mb-4 text-green-400">
                <p><strong>계산된 가격 범위 (Y/X):</strong> {parseFloat(calculatedPriceRange.minPrice).toFixed(10)} ~ {parseFloat(calculatedPriceRange.maxPrice).toFixed(10)}</p>
              </div>
            )}
            {!calculationLoading && !calculatedPriceRange && parseFloat(totalSolValue) > 0 && (
                 <p className="text-yellow-400">가격을 계산 중이거나, 입력값을 확인해주세요.</p>
            )}
            {!calculationLoading && !calculatedPriceRange && (!totalSolValue || parseFloat(totalSolValue) <= 0) && (
              <div className="mb-4 text-gray-400">
               <p><strong>가격 범위:</strong> 총 예치 가치를 입력하시면 가격 범위가 자동 계산됩니다.</p>
              </div>
            )}

            <div className="flex space-x-4 mt-6">
              <button
                className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                onClick={() => { setAssetCheckResult(null); setCurrentStep(1); }}
              >
                이전 (풀 선택)
              </button>
              <button
                className={`bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${assetCheckLoading || calculationLoading || !selectedPool || !totalSolValue || !strategyType || !calculatedPriceRange ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={handleAssetCheck}
                disabled={assetCheckLoading || calculationLoading || !selectedPool || !totalSolValue || !strategyType || !calculatedPriceRange}
              >
                {assetCheckLoading ? '자산 확인 중...' : '다음 (자산 확인)'}
              </button>
            </div>
          </>
        );
      case 3:
        if (!assetCheckResult) {
            return <p>자산 정보를 불러오는 중...</p>;
        }
        const { needsSwap, requiredAssets, currentBalances, swapQuote } = assetCheckResult; 
        
        const formatDisplayAmount = (lamports: string, decimals: number | undefined) => {
            if (!lamports || decimals === undefined) return 'N/A';
            return (Number(lamports) / Math.pow(10, decimals)).toFixed(decimals);
        };

        const requiredSolDisplay = formatDisplayAmount(requiredAssets?.solLamports, 9);
        const requiredTargetDisplay = formatDisplayAmount(requiredAssets?.targetTokenLamports, requiredAssets?.tokenDecimals);
        
        const currentSolDisplay = assetCheckLoading ? '잔액 조회 중...' : (currentBalances ? formatDisplayAmount(currentBalances.solLamports, 9) : 'N/A');
        const currentTargetDisplay = assetCheckLoading ? '잔액 조회 중...' : (currentBalances ? formatDisplayAmount(currentBalances.targetTokenLamports, requiredAssets?.tokenDecimals) : 'N/A');

        return (
          <>
            <h2 className="text-2xl font-semibold text-white mb-6">단계 3: 자산 확인 및 스왑 동의</h2>
            <div className="space-y-4 mb-6 p-4 bg-gray-800 rounded-lg">
              <div>
                <h3 className="text-lg font-semibold text-sky-400 mb-1">필요 자산:</h3>
                <p>SOL: {requiredSolDisplay}</p>
                <p>대상 토큰 ({tokenCaInput.substring(0,6)}...): {requiredTargetDisplay}</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-green-400 mb-1">현재 잔액 (서버 조회):</h3>
                <p>SOL: {currentSolDisplay}</p>
                <p>대상 토큰 ({tokenCaInput.substring(0,6)}...): {currentTargetDisplay}</p>
              </div>

              {needsSwap && (
                <div className="mt-4 p-3 bg-yellow-900 bg-opacity-50 rounded border border-yellow-700">
                  <p className="text-yellow-400 font-semibold mb-2">알림: 자산이 부족하여 자동 스왑을 진행합니다.</p>
                  <p className="text-sm text-yellow-500">예상 스왑 정보: {swapQuote ? JSON.stringify(swapQuote, null, 2) : '견적 정보 없음 (또는 조회 중...)'}</p>
                </div>
              )}
            </div>

            <div className="flex space-x-4 mt-8">
              <button
                className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
                onClick={() => setCurrentStep(2)}
              >
                이전 (예치 설정)
              </button>
              <button
                className={`bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${createLpLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                onClick={handleExecuteCreateLp}
                disabled={createLpLoading}
              >
                {createLpLoading ? 'LP 생성 중...' : (needsSwap ? '자동 스왑 후 LP 생성' : 'LP 포지션 생성')}
              </button>
            </div>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-4 pt-20">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-gray-100">LP 포지션 생성</h1>
        {/* WalletMultiButton 제거 */}
      </div>

      {error && (
        <div className="bg-red-500 text-white p-4 rounded-md mb-4">
          {error}
        </div>
      )}

      <div className="bg-orange-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8">
        {renderStep()}
      </div>
    </div>
  );
}
