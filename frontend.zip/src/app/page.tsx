import Link from 'next/link';

export default function LoginPage() {
  const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:5000';
  const googleLoginUrl = `${backendUrl}/api/auth/google`;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen"> {/* 배경색은 globals.css에서 var(--background)로 이미 어두운 파란색 적용됨 */}
      <div className="p-8 bg-orange-700 shadow-xl rounded-lg max-w-md w-full"> {/* "윈도우창" 배경색 변경 */}
        <h1 className="text-3xl font-bold text-center text-white mb-8"> {/* 글자색 변경 */}
          DLMM WebApp에 오신 것을 환영합니다!
        </h1>
        <p className="text-center text-gray-200 mb-8"> {/* 글자색 변경 */}
          시작하려면 구글 계정으로 로그인해주세요.
        </p>
        <Link
          href={googleLoginUrl}
          className="w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 px-6 rounded-lg text-center transition duration-300 ease-in-out transform hover:scale-105 inline-block" /* 버튼 색상 변경 */
        >
          구글 계정으로 로그인
        </Link>
      </div>
      <footer className="mt-12 text-center text-sm text-gray-400"> {/* 푸터 글자색 변경 */}
        <p>&copy; {new Date().getFullYear()} DLMM Project. All rights reserved.</p>
      </footer>
    </div>
  );
}
