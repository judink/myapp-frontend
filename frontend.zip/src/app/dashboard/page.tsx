// src/app/dashboard/page.tsx
"use client"; 

import React, { useEffect, useState } from 'react'; // useState 추가
import { useRouter } from 'next/navigation'; 
import useAuthStore from '@/store/authStore'; 
import { User } from '@/types/user'; 
import apiClient from '@/lib/api'; // API 클라이언트 임포트
import { LbPosition } from '@/types/dlmm'; // LP 포지션 타입 절대 경로로 수정

// Meteora SDK 임포트 (프론트엔드용) (추가)
import DLMM from '@meteora-ag/dlmm';
import Decimal from 'decimal.js'; // Decimal 임포트 (추가)
import { getPriceOfBinByBinId } from '@meteora-ag/dlmm'; // getPriceOfBinByBinId 임포트 경로 수정
import { NATIVE_MINT } from '@solana/spl-token'; // NATIVE_MINT 임포트 (추가)

interface WalletBalance {
  solanaPublicKey: string;
  solBalance: string;
  // tokenBalances?: Array<{ symbol: string; balance: string; mint: string; error?: string }>; // 추후 SPL 토큰용
}

// LbPosition 타입 정의 (임시, 실제 SDK 응답에 맞춰 상세화 필요)
// 예시: controllers/dlmmController.js의 simplifiedPositions 구조 참조
// export interface LbPosition {
//   positionAddress: string;
//   lbPairAddress: string;
//   totalXAmount: string;
//   totalYAmount: string;
//   // ... 기타 필요한 필드
// }


export default function DashboardPage() {
  const router = useRouter();
  const { user, isLoggedIn, isLoading } = useAuthStore();
  const [walletBalance, setWalletBalance] = useState<WalletBalance | null>(null);
  const [balanceLoading, setBalanceLoading] = useState(true);
  const [lpPositions, setLpPositions] = useState<LbPosition[]>([]); // LP 포지션 목록 상태
  const [positionsLoading, setPositionsLoading] = useState(true); // LP 포지션 로딩 상태

  useEffect(() => {
    // AuthProvider에서 이미 initializeAuth를 호출하지만,
    // 페이지 직접 접근 시 또는 상태가 초기화되지 않은 경우를 대비하여 한 번 더 호출하거나,
    // isLoading과 isLoggedIn 상태를 바로 사용할 수 있습니다.
    // initializeAuth(); // 이미 layout에서 호출되므로 중복 호출 방지 또는 조건부 호출
  }, []);

  useEffect(() => {
    // 로딩이 끝났고, 로그인되어 있지 않다면 로그인 페이지로 리디렉션
    if (!isLoading && !isLoggedIn) {
      router.replace('/');
    } else if (!isLoading && isLoggedIn && user) {
      // 사용자가 로그인했고, 아직 잔액 정보가 없다면 잔액 조회 API 호출
      if (!walletBalance) {
        const fetchWalletBalance = async () => {
          setBalanceLoading(true);
          try {
            const response = await apiClient.get<WalletBalance>('/api/wallet/balance');
            setWalletBalance(response.data);
          } catch (error) {
            console.error('Failed to fetch wallet balance:', error);
          } finally {
            setBalanceLoading(false);
          }
        };
        fetchWalletBalance();
      }
      // 사용자가 로그인했고, 아직 LP 포지션 정보가 없고, 현재 로딩 중도 아니라면 조회 API 호출
      if (lpPositions.length === 0 && !positionsLoading) { 
        const fetchLpPositions = async () => {
          setPositionsLoading(true);
          try {
            const response = await apiClient.get<LbPosition[]>('/api/dlmm/lp/positions');
            setLpPositions(response.data);
          } catch (error) {
            console.error('Failed to fetch LP positions:', error);
            // 오류 발생 시 lpPositions를 빈 배열로 유지하거나, 사용자에게 알림
            setLpPositions([]); // 오류 시 빈 배열로 설정하여 반복 호출 방지
          } finally {
            setPositionsLoading(false);
          }
        };
        fetchLpPositions();
      }
    }
  }, [isLoading, isLoggedIn, user, router, walletBalance]); // lpPositions를 의존성 배열에서 제거

  if (isLoading || (isLoggedIn && !user)) { 
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-lg text-gray-600">사용자 정보를 불러오는 중...</p>
      </div>
    );
  }

  if (!isLoggedIn || !user) { // 로그인되지 않았거나 사용자 정보가 없는 경우 (리디렉션 전 잠시 보일 수 있음)
    return (
      <div className="flex flex-col items-center justify-center min-h-screen">
        <p className="text-lg text-gray-600 mb-4">로그인이 필요합니다. 로그인 페이지로 이동합니다...</p>
        {/* 또는 로딩 스피너를 계속 보여줄 수 있음 */}
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 pt-20"> {/* 기본 글자색은 globals.css에서 밝게 설정됨 */}
      <header className="mb-8">
        <h1 className="text-4xl font-bold text-gray-100"> {/* 글자색 변경 */}
          환영합니다, {user.displayName}님!
        </h1>
        <p className="text-xl text-gray-300">DLMM 대시보드입니다.</p> {/* 글자색 변경 */}
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="bg-orange-700 p-6 rounded-lg shadow-xl text-gray-100"> {/* 배경색 및 기본 글자색 변경 */}
          <h2 className="text-2xl font-semibold text-white mb-4">계정 정보</h2> {/* 제목 글자색 변경 */}
          <p><strong>이메일:</strong> {user.email}</p>
          {user.solanaPublicKey && (
            <p><strong>솔라나 주소:</strong> {user.solanaPublicKey}</p>
          )}
        </div>
        
        <div className="bg-orange-700 p-6 rounded-lg shadow-xl text-gray-100"> {/* 배경색 및 기본 글자색 변경 */}
          <h2 className="text-2xl font-semibold text-white mb-4">지갑 잔액</h2> {/* 제목 글자색 변경 */}
          {balanceLoading && <p>잔액을 불러오는 중...</p>}
          {!balanceLoading && walletBalance && (
            <>
              <p><strong>SOL:</strong> {parseFloat(walletBalance.solBalance).toFixed(4)} SOL</p>
              {/* TODO: SPL 토큰 잔액 표시 */}
            </>
          )}
          {!balanceLoading && !walletBalance && <p>잔액 정보를 불러오지 못했습니다.</p>}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-white mb-4">나의 LP 포지션</h2> {/* 제목 글자색 변경 */}
        <div className="bg-orange-700 p-6 rounded-lg shadow-xl text-gray-100"> {/* 배경색 및 기본 글자색 변경 */}
          {positionsLoading && <p>LP 포지션 정보를 불러오는 중...</p>}
          {!positionsLoading && lpPositions.length === 0 && <p>보유 중인 LP 포지션이 없습니다.</p>}
          {!positionsLoading && lpPositions.length > 0 && (
            <ul className="space-y-4">
              {lpPositions.map((pos) => (
                <li key={pos.positionAddress} className="p-4 bg-orange-800 rounded-md hover:shadow-lg transition-shadow"> {/* 리스트 아이템 배경색 변경 */}
                  <p><strong>포지션 주소:</strong> <span className="text-sm break-all">{pos.positionAddress}</span></p>
                  <p><strong>페어 주소:</strong> <span className="text-sm break-all">{pos.lbPairAddress}</span></p>
                  <p><strong>X 토큰 총량:</strong> {pos.totalXAmount}</p>
                  <p><strong>Y 토큰 총량:</strong> {pos.totalYAmount}</p>
                  {/* 포지션 가격 범위 표시 추가 */}
                  {pos.binStep !== undefined && pos.tokenXDecimals !== undefined && pos.tokenYDecimals !== undefined && (
                    <p>
                      <strong>가격 범위:</strong>{' '}
                      {(() => {
                        try {
                          // getPriceOfBinByBinId는 스케일링된 가격 문자열을 반환
                          const minPricePerLamport = new Decimal(getPriceOfBinByBinId(pos.lowerBinId, pos.binStep));
                          const maxPricePerLamport = new Decimal(getPriceOfBinByBinId(pos.upperBinId, pos.binStep));

                          // 스케일링된 가격을 실제 가격으로 변환 (Y/X 가격)
                          // Y/X 가격 = (스케일링된 가격) * 10^(decimals_Y - decimals_X)
                          const priceScale = new Decimal(10).pow(pos.tokenYDecimals - pos.tokenXDecimals);
                          const minPriceActual = minPricePerLamport.mul(priceScale);
                          const maxPriceActual = maxPricePerLamport.mul(priceScale);

                          return `${minPriceActual.toFixed(10)} ~ ${maxPriceActual.toFixed(10)}`; // 소수점 10자리까지 표시
                        } catch (e) {
                          console.error("Error calculating price range for position:", e);
                          return "가격 계산 오류";
                        }
                      })()}
                    </p>
                  )}
                  {/* TODO: 여기에 더 많은 포지션 정보 및 관리 버튼 추가 */}
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
      
      {/* 추가 기능 버튼들 (예시) */}
      <div className="mt-8 flex space-x-4">
        <button 
          className="bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300" /* 버튼 색상 변경 */
          onClick={() => router.push('/lp/create')} 
        >
          새 LP 포지션 생성
        </button>
        <button 
          className="bg-rose-600 hover:bg-rose-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300" /* 버튼 색상 변경 */
          onClick={() => useAuthStore.getState().logout()} 
        >
          로그아웃
        </button>
        <button
          className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
          onClick={async () => {
            const confirmed = window.confirm(
              "경고: Private Key가 노출될 수 있습니다!\n\n이 키는 귀하의 모든 자산에 접근할 수 있는 매우 민감한 정보입니다. " +
              "안전한 곳에 백업하고, 절대로 다른 사람과 공유하거나 신뢰할 수 없는 웹사이트에 입력하지 마십시오.\n\n계속 진행하시겠습니까?"
            );
            if (confirmed) {
              try {
                const response = await apiClient.get<{ privateKey: string | Uint8Array | number[] }>('/api/wallet/export-private-key');
                // privateKey가 배열 또는 객체 형태일 수 있으므로, 문자열로 변환 필요 (예: Base58)
                // Keypair.fromSecretKey는 Uint8Array를 기대함.
                // 백엔드에서 Uint8Array를 JSON으로 보내면 { '0': byte0, '1': byte1, ... } 형태가 될 수 있음.
                // 여기서는 백엔드가 Uint8Array를 배열로 변환해서 보냈다고 가정.
                let pkToCopy: string;
                if (typeof response.data.privateKey === 'string') {
                  pkToCopy = response.data.privateKey; // 이미 문자열 (예: Base58)
                } else if (Array.isArray(response.data.privateKey)) {
                  pkToCopy = JSON.stringify(response.data.privateKey); // 배열을 문자열로
                  // 또는 Uint8Array.from(response.data.privateKey).toString() 등
                  // 실제로는 Base58 인코딩된 문자열로 변환하는 것이 일반적
                  alert("Private Key 배열이 복사되었습니다. (Uint8Array로 변환하여 사용하세요)\n" + pkToCopy);
                } else if (typeof response.data.privateKey === 'object' && response.data.privateKey !== null) {
                  // 객체 형태의 배열 유사 객체일 경우
                  pkToCopy = JSON.stringify(Object.values(response.data.privateKey));
                   alert("Private Key 배열(객체형)이 복사되었습니다. (Uint8Array로 변환하여 사용하세요)\n" + pkToCopy);
                }
                else {
                  throw new Error('Unknown private key format received.');
                }
                
                await navigator.clipboard.writeText(pkToCopy);
                alert('Private Key가 클립보드에 복사되었습니다. 안전하게 보관하세요!');
              } catch (err: any) {
                console.error('Failed to export private key:', err);
                alert('Private Key를 가져오는 데 실패했습니다: ' + (err.response?.data?.message || err.message));
              }
            }
          }}
        >
          지갑 Private Key 복사 (주의!)
        </button>
      </div>
    </div>
  );
}
