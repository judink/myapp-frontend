module.exports = {

"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[externals]/node:crypto [external] (node:crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}}),
"[externals]/punycode [external] (punycode, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}}),
"[externals]/net [external] (net, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}}),
"[externals]/tls [external] (tls, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}}),
"[externals]/node:url [external] (node:url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/process [external] (process, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}}),
"[project]/src/hooks/useDlmmPositions.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "useDlmmPositions": (()=>useDlmmPositions)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meteora$2d$ag$2f$dlmm$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meteora-ag/dlmm/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bn.js/lib/bn.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/decimal.js/decimal.mjs [app-ssr] (ecmascript)"); // Assuming Decimal.js is used for calculations
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/spl-token/lib/esm/state/mint.js [app-ssr] (ecmascript)"); // Import getMint
;
;
;
;
;
;
;
// Configuration options (adapted for frontend environment variables)
const CONFIG = {
    SOL_TOKEN_ADDRESS: "So11111111111111111111111111111111111111112",
    RANGE_BAR_WIDTH: 20,
    UPDATE_INTERVAL: 60000,
    ERROR_RETRY_DELAY: 5000,
    RPC_ENDPOINT: ("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com'
};
// Helper function to get token price from Jupiter API
async function getTokenPrice(tokenMint) {
    if (!tokenMint) {
        console.error('getTokenPrice: tokenMint is undefined or null');
        return 0;
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`https://api.jup.ag/price/v2?ids=${tokenMint}`);
        return response.data.data[tokenMint]?.price ? parseFloat(response.data.data[tokenMint].price) : 0;
    } catch (error) {
        console.error('Error fetching price:', error);
        return 0;
    }
}
// Helper function to get token name from Gecko Terminal
async function getTokenName(tokenMint) {
    if (!tokenMint) {
        console.error('getTokenName: tokenMint is undefined or null');
        return tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token';
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`https://api.geckoterminal.com/api/v2/networks/solana/tokens/${tokenMint}`);
        return response.data.data?.attributes?.name || (tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token');
    } catch (error) {
        console.error('Error fetching token name:', error);
        return tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token';
    }
}
// Helper function to convert lamports to token amount
function lamportsToTokenAmount(lamports, decimals) {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return 0;
    try {
        const divisor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](10).pow(decimals);
        const amountDecimal = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](lamports.toString()).div(divisor);
        return amountDecimal.toNumber();
    } catch (err) {
        console.error('Error in lamportsToTokenAmount:', err);
        return 0;
    }
}
// Helper function to fetch initial deposit information
async function getInitialDeposit(positionAddress) {
    if (!positionAddress) {
        console.error('getInitialDeposit: positionAddress is undefined or null');
        return null;
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`https://dlmm-api.meteora.ag/position/${positionAddress}/deposits`);
        const deposits = response.data;
        if (deposits && deposits.length > 0) {
            const deposit = deposits[0]; // Get the first deposit
            const timestamp = new Date(deposit.onchain_timestamp * 1000).toLocaleString();
            return {
                tokenXAmount: deposit.token_x_amount,
                tokenYAmount: deposit.token_y_amount,
                tokenXUsdAmount: deposit.token_x_usd_amount,
                tokenYUsdAmount: deposit.token_y_usd_amount,
                timestamp: timestamp,
                price: deposit.price,
                onchain_timestamp: deposit.onchain_timestamp
            };
        }
        return null;
    } catch (error) {
        console.error('Error fetching deposit information:', error);
        return null;
    }
}
// Helper function to get current dynamic fee
async function getCurrentDynamicFee(poolAddress) {
    if (!poolAddress) {
        console.error('getCurrentDynamicFee: poolAddress is undefined or null');
        return null;
    }
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`https://dlmm-api.meteora.ag/pair/${poolAddress}`);
        const data = response.data;
        const baseFee = parseFloat(data.base_fee_percentage);
        // const maxFee = parseFloat(data.max_fee_percentage); // Not used in original logic
        return baseFee;
    } catch (error) {
        console.error('Error fetching dynamic fee:', error);
        return null;
    }
}
const useDlmmPositions = (userPublicKey)=>{
    const [positions, setPositions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchedPublicKeyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null); // Ref to track the public key for which data has been fetched
    const [totalSummary, setTotalSummary] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        totalLiquidityValue: 0,
        totalClaimedFees: 0,
        totalUnclaimedFees: 0,
        totalPositions: 0,
        inRangePositions: 0,
        totalInitialValue: 0,
        totalPnL: 0,
        totalPnLPercentage: 0
    });
    const fetchPositions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (!userPublicKey) {
            setPositions([]);
            setIsLoading(false);
            return;
        }
        setIsLoading(true);
        setError(null);
        const fetchedPositions = [];
        let totalLiquidityValue = 0;
        let totalClaimedFees = 0;
        let totalUnclaimedFees = 0;
        let totalPositions = 0;
        let inRangePositions = 0;
        let totalInitialValue = 0;
        try {
            const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](CONFIG.RPC_ENDPOINT, 'confirmed');
            const userPositionsMap = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meteora$2d$ag$2f$dlmm$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getAllLbPairPositionsByUser(connection, userPublicKey);
            if (userPositionsMap.size === 0) {
                setPositions([]);
                setIsLoading(false);
                setTotalSummary({
                    totalLiquidityValue: 0,
                    totalClaimedFees: 0,
                    totalUnclaimedFees: 0,
                    totalPositions: 0,
                    inRangePositions: 0,
                    totalInitialValue: 0,
                    totalPnL: 0,
                    totalPnLPercentage: 0
                });
                // Reset fetched key on logout/no positions
                fetchedPublicKeyRef.current = null;
                return;
            }
            for (const [poolAddress, _] of userPositionsMap.entries()){
                try {
                    const dlmmPool = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meteora$2d$ag$2f$dlmm$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create(connection, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PublicKey"](poolAddress));
                    const activeBin = await dlmmPool.getActiveBin();
                    const currentBinId = activeBin.binId;
                    const { userPositions: poolPositions } = await dlmmPool.getPositionsByUserAndLbPair(userPublicKey);
                    const tokenXPrice = await getTokenPrice(dlmmPool.tokenX.publicKey.toString());
                    const tokenYPrice = await getTokenPrice(dlmmPool.tokenY.publicKey.toString());
                    // Fetch decimals using mint addresses if not available on dlmmPool object
                    let tokenXDecimals = dlmmPool.tokenX.decimal;
                    let tokenYDecimals = dlmmPool.tokenY.decimal;
                    if (tokenXDecimals === undefined || tokenXDecimals === null || tokenYDecimals === undefined || tokenYDecimals === null) {
                        try {
                            const tokenXMintInfo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getMint"])(connection, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PublicKey"](dlmmPool.tokenX.publicKey));
                            const tokenYMintInfo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getMint"])(connection, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PublicKey"](dlmmPool.tokenY.publicKey));
                            tokenXDecimals = tokenXMintInfo.decimals;
                            tokenYDecimals = tokenYMintInfo.decimals;
                        } catch (decimalError) {
                            console.error('Error fetching token decimals:', decimalError);
                            // Fallback to a default or handle error appropriately
                            tokenXDecimals = 0; // Or some default
                            tokenYDecimals = 0; // Or some default
                        }
                    }
                    for (const positionDetails of poolPositions){
                        totalPositions++;
                        const { positionData } = positionDetails;
                        const isInRange = currentBinId >= positionData.lowerBinId && currentBinId <= positionData.upperBinId;
                        if (isInRange) inRangePositions++;
                        // Ensure amounts are treated as BN before converting to number
                        const xAmountBN = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].isBN(positionData.totalXAmount) ? positionData.totalXAmount : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.totalXAmount.toString());
                        const yAmountBN = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].isBN(positionData.totalYAmount) ? positionData.totalYAmount : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.totalYAmount.toString());
                        const tokenXAmount = lamportsToTokenAmount(xAmountBN, tokenXDecimals);
                        const tokenYAmount = lamportsToTokenAmount(yAmountBN, tokenYDecimals);
                        const tokenXValue = tokenXAmount * tokenXPrice;
                        const tokenYValue = tokenYAmount * tokenYPrice;
                        // Access fee properties, using type assertion or checking for existence
                        const claimedXAmount = lamportsToTokenAmount(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.totalClaimedFeeXAmount?.toString() || '0'), tokenXDecimals);
                        const claimedYAmount = lamportsToTokenAmount(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.totalClaimedFeeYAmount?.toString() || '0'), tokenYDecimals);
                        const claimableXAmount = lamportsToTokenAmount(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.feeX?.toString() || '0'), tokenXDecimals);
                        const claimableYAmount = lamportsToTokenAmount(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.feeY?.toString() || '0'), tokenYDecimals);
                        // Removed conditional logging inside the loop
                        const positionValue = tokenXValue + tokenYValue;
                        const claimedValue = claimedXAmount * tokenXPrice + claimedYAmount * tokenYPrice;
                        const unclaimedValue = claimableXAmount * tokenXPrice + claimableYAmount * tokenYPrice;
                        const totalCurrentValueForPosition = positionValue + claimedValue + unclaimedValue; // Renamed to avoid scope conflict
                        // Removed conditional logging inside the loop
                        totalLiquidityValue += positionValue;
                        totalClaimedFees += claimedValue;
                        totalUnclaimedFees += unclaimedValue;
                        // Removed conditional logging inside the loop
                        const depositInfo = await getInitialDeposit(positionDetails.publicKey.toString());
                        if (depositInfo) {
                            totalInitialValue += (depositInfo.tokenXUsdAmount || 0) + (depositInfo.tokenYUsdAmount || 0);
                        }
                        const dynamicFee = await getCurrentDynamicFee(poolAddress);
                        fetchedPositions.push({
                            address: positionDetails.publicKey.toString(),
                            pair_address: poolAddress,
                            owner: userPublicKey.toBase58(),
                            total_fee_usd_claimed: 0,
                            total_reward_usd_claimed: 0,
                            fee_apy_24h: 0,
                            fee_apr_24h: 0,
                            daily_fee_yield: 0,
                            lowerBinId: positionData.lowerBinId,
                            upperBinId: positionData.upperBinId,
                            // Access binStep from the pool object directly if available
                            binStep: dlmmPool.binStep,
                            tokenXMint: dlmmPool.tokenX.publicKey.toBase58(),
                            tokenYMint: dlmmPool.tokenY.publicKey.toBase58(),
                            tokenXDecimals: tokenXDecimals,
                            tokenYDecimals: tokenYDecimals,
                            totalXAmount: BigInt(xAmountBN.toString()),
                            totalYAmount: BigInt(yAmountBN.toString()),
                            pendingFeeX: BigInt(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.feeX?.toString() || '0').toString()),
                            pendingFeeY: BigInt(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionData.feeY?.toString() || '0').toString()),
                            // Access rewardInfos from positionData, using type assertion based on observed structure
                            pendingRewards: positionData.rewardInfos?.map((r)=>({
                                    mint: r.mint?.toBase58() || '',
                                    amount: BigInt(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](r.pendingReward?.toString() || '0').toString())
                                })) || [],
                            totalXAmountUi: tokenXAmount.toFixed(tokenXDecimals),
                            totalYAmountUi: tokenYAmount.toFixed(tokenYDecimals),
                            pendingFeeXUi: claimableXAmount.toFixed(tokenXDecimals),
                            pendingFeeYUi: claimableYAmount.toFixed(tokenYDecimals),
                            pendingRewardsUi: positionData.pendingRewardsUi?.map((r)=>({
                                    amount: r.amount?.toString() || '0',
                                    mint: r.mint?.toBase58() || ''
                                })) || [],
                            priceRange: `${positionData.lowerBinId} - ${positionData.upperBinId}`,
                            totalValueInSol: totalCurrentValueForPosition.toFixed(4),
                            isInRange: isInRange,
                            currentBinId: currentBinId,
                            tokenXPrice: tokenXPrice,
                            tokenYPrice: tokenYPrice,
                            claimedValue: claimedValue,
                            unclaimedValue: unclaimedValue,
                            positionValue: positionValue,
                            totalCurrentValue: totalCurrentValueForPosition,
                            depositInfo: depositInfo,
                            dynamicFee: dynamicFee
                        });
                    }
                } catch (poolError) {
                    console.error(`Error processing pool ${poolAddress}:`, poolError);
                // Continue to the next pool even if one fails
                }
            }
            const overallTotalCurrentValue = totalLiquidityValue + totalClaimedFees + totalUnclaimedFees;
            const overallTotalPnL = overallTotalCurrentValue - totalInitialValue;
            const overallTotalPnLPercentage = totalInitialValue > 0 ? overallTotalPnL / totalInitialValue * 100 : 0;
            setPositions(fetchedPositions);
            setTotalSummary({
                totalLiquidityValue,
                totalClaimedFees,
                totalUnclaimedFees,
                totalPositions,
                inRangePositions,
                totalInitialValue,
                totalPnL: overallTotalPnL,
                totalPnLPercentage: overallTotalPnLPercentage
            });
        } catch (e) {
            console.error('Error fetching user positions:', e);
            setError(e.message || 'LP 포지션 목록을 불러오는데 실패했습니다.');
        } finally{
            setIsLoading(false);
        }
    }, [
        userPublicKey
    ]); // Dependency on userPublicKey
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const currentPublicKeyString = userPublicKey?.toBase58() || null;
        // Fetch positions only when userPublicKey changes and is not null/undefined,
        // and we haven't fetched for this specific public key yet.
        if (userPublicKey && currentPublicKeyString !== fetchedPublicKeyRef.current) {
            fetchedPublicKeyRef.current = currentPublicKeyString; // Mark as fetching/fetched for this key immediately
            fetchPositions();
        } else if (!userPublicKey) {
            // Reset state and log tracking when userPublicKey is null/undefined (e.g., after logout)
            setPositions([]);
            setIsLoading(false);
            fetchedPublicKeyRef.current = null; // Reset log tracking on logout
            setTotalSummary({
                totalLiquidityValue: 0,
                totalClaimedFees: 0,
                totalUnclaimedFees: 0,
                totalPositions: 0,
                inRangePositions: 0,
                totalInitialValue: 0,
                totalPnL: 0,
                totalPnLPercentage: 0
            });
        }
    // Dependencies: Only userPublicKey?.toBase58() and fetchPositions.
    // fetchPositions is memoized with useCallback and depends only on userPublicKey.
    // This setup should prevent infinite loops.
    }, [
        userPublicKey?.toBase58(),
        fetchPositions
    ]);
    // Return fetchPositions so it can be called manually from the component
    return {
        positions,
        isLoading,
        error,
        totalSummary,
        fetchPositions
    };
};
}}),
"[project]/src/components/lp/LpPositionItem.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>LpPositionItem)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)"); // Import necessary Solana types
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/authStore.ts [app-ssr] (ecmascript)"); // Import useAuthStore
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/decimal.js/decimal.mjs [app-ssr] (ecmascript)"); // For calculations
"use client";
;
;
;
;
// Helper to convert lamports to UI amount (can be shared or defined here)
// This helper is now primarily used for transaction building amounts if needed,
// as display amounts come pre-calculated from the backend.
function lamportsToUiAmount(lamports, decimals) {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return '0';
    try {
        const amountDecimal = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](lamports.toString()).div(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$decimal$2e$js$2f$decimal$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](10).pow(decimals));
        return amountDecimal.toFixed(Math.min(decimals, 6)); // Example: show up to 6 decimals
    } catch (e) {
        console.error("Error formatting amount:", e);
        return 'Error';
    }
}
function LpPositionItem({ position }) {
    // Get userPublicKey from auth store instead of wallet adapter
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])();
    const userPublicKey = user?.solanaPublicKey ? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PublicKey"](user.solanaPublicKey) : null;
    // Display details are now received directly in the position prop
    // No need for a separate state or useEffect for calculations
    // useEffect(() => {
    //     // Calculation logic moved to backend
    // }, [position, connection]);
    // Disable these functions as client-side signing is removed
    const handleRemoveLiquidity = async ()=>{
        console.warn("handleRemoveLiquidity: Disabled due to wallet adapter removal.");
    };
    // Disable these functions as client-side signing is removed
    const handleRemoveAndSwap = async ()=>{
        console.warn("handleRemoveAndSwap: Disabled due to wallet adapter removal.");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-gray-800 p-4 rounded-lg mb-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-lg font-semibold text-white mb-2",
                children: [
                    "LP 포지션: ",
                    position.address.slice(0, 6),
                    "...",
                    position.address.slice(-6)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "풀: ",
                    position.pair_address.slice(0, 6),
                    "...",
                    position.pair_address.slice(-6)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "가격 범위: ",
                    position.priceRange
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "총 가치 (SOL): ",
                    position.totalValueInSol
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "예치 금액: ",
                    position.totalXAmountUi,
                    " (",
                    position.tokenXMint.slice(0, 4),
                    "...) / ",
                    position.totalYAmountUi,
                    " (",
                    position.tokenYMint.slice(0, 4),
                    "...)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: [
                    "미청구 수수료: ",
                    position.pendingFeeXUi,
                    " (",
                    position.tokenXMint.slice(0, 4),
                    "...) / ",
                    position.pendingFeeYUi,
                    " (",
                    position.tokenYMint.slice(0, 4),
                    "...)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            position.pendingRewardsUi.map((reward, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-300",
                    children: [
                        "미청구 보상 ",
                        index + 1,
                        ": ",
                        reward.amount,
                        " (",
                        reward.mint.slice(0, 4),
                        "...)"
                    ]
                }, index, true, {
                    fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex space-x-2 mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 opacity-50 cursor-not-allowed`,
                        onClick: handleRemoveLiquidity,
                        disabled: true,
                        children: "LP 해제 (비활성화됨)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 opacity-50 cursor-not-allowed`,
                        onClick: handleRemoveAndSwap,
                        disabled: true,
                        children: "LP 해제 및 자동 스왑 (비활성화됨)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                        lineNumber: 81,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/lp/LpPositionItem.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/lp/LpPositionItem.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/app/dashboard/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DashboardPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/authStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDlmmPositions$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useDlmmPositions.ts [app-ssr] (ecmascript)"); // Import the new hook
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$LpPositionItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/lp/LpPositionItem.tsx [app-ssr] (ecmascript)"); // Import LpPositionItem component
"use client";
;
;
;
;
;
;
;
function DashboardPage() {
    const { user, isLoggedIn, isLoading: isAuthLoading, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])();
    const userPublicKey = user?.solanaPublicKey ? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PublicKey"](user.solanaPublicKey) : null;
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [solBalance, setSolBalance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // Use the new hook to fetch positions and related data, and expose fetchPositions for manual refresh
    const { positions, isLoading, error, totalSummary, fetchPositions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDlmmPositions$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDlmmPositions"])(userPublicKey);
    // Redirect if not logged in
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!isAuthLoading && !isLoggedIn) {
            router.replace('/');
        }
    }, [
        isAuthLoading,
        isLoggedIn,
        router
    ]);
    // Fetch SOL balance (Still needed, uses connection)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchSolBalance = async ()=>{
            if (userPublicKey) {
                try {
                    const connection = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connection"](("TURBOPACK compile-time value", "https://mainnet.helius-rpc.com/?api-key=cb37a313-db23-4aa5-845b-4220d5c578a5") || 'https://api.devnet.solana.com', 'confirmed');
                    const balance = await connection.getBalance(userPublicKey);
                    setSolBalance(balance / 10 ** 9); // Convert lamports to SOL
                } catch (e) {
                    console.error("Failed to fetch SOL balance:", e);
                    setSolBalance(null);
                }
            } else {
                setSolBalance(null);
            }
        };
        fetchSolBalance();
    }, [
        userPublicKey
    ]);
    const handleLogout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        logout();
        router.push('/');
    }, [
        logout,
        router
    ]);
    // Placeholder functions for LP actions (can be updated later to use hook data/actions)
    const handleExportPrivateKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        // TODO: Implement actual private key export logic
        console.log('개인 키 내보내기 기능은 현재 초기화되었습니다.');
    }, []);
    const handleRemoveAllLp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        // TODO: Implement actual remove all LP logic using hook/SDK
        console.log('모든 LP 포지션 정리 기능은 현재 초기화되었습니다.');
    }, []);
    const handleRemoveAllLpAndSwap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        // TODO: Implement actual remove all LP and swap logic using hook/SDK
        console.log('모든 LP 포지션 정리 및 스왑 기능은 현재 초기화되었습니다.');
    }, []);
    // Check if userPublicKey is available before rendering the main content
    if (!userPublicKey) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto p-4 pt-20 text-center text-gray-300",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "사용자 지갑 정보를 불러오는 중입니다..."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 72,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/page.tsx",
            lineNumber: 71,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto p-4 pt-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-4xl font-bold text-gray-100 mb-8",
                children: "대시보드"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-4 rounded-md mb-4",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 82,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-4",
                        children: "사용자 정보 및 지갑"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this),
                    user?.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "사용자 ID: ",
                            user.id
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 89,
                        columnNumber: 24
                    }, this),
                    userPublicKey && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "지갑 주소: ",
                            userPublicKey.toBase58()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 90,
                        columnNumber: 29
                    }, this),
                    solBalance !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "SOL 잔액: ",
                            solBalance?.toFixed(4)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 91,
                        columnNumber: 35
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex space-x-4 mt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: ()=>router.push('/lp/create'),
                                children: "새 LP 포지션 생성"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 93,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: handleExportPrivateKey,
                                disabled: isLoading,
                                children: "개인 키 내보내기"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 99,
                                columnNumber: 16
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "bg-red-600 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition duration-300",
                                onClick: handleLogout,
                                children: "로그아웃"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/page.tsx",
                                lineNumber: 106,
                                columnNumber: 16
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-semibold text-gray-100 mb-4",
                children: "나의 LP 포지션"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 115,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: `bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`,
                    onClick: fetchPositions,
                    disabled: isLoading,
                    children: isLoading ? '새로고침 중...' : 'LP 포지션 새로고침'
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/page.tsx",
                    lineNumber: 119,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 118,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-gray-700 p-6 rounded-lg shadow-xl text-gray-100 mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl font-semibold text-white mb-4",
                        children: "요약"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "총 포지션 수: ",
                            totalSummary.totalPositions
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "범위 내 포지션 수: ",
                            totalSummary.inRangePositions
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 133,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "총 유동성 가치: $",
                            totalSummary.totalLiquidityValue.toFixed(2)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 134,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "총 미청구 수수료: $",
                            totalSummary.totalUnclaimedFees.toFixed(2)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 135,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "총 초기 투자 가치: $",
                            totalSummary.totalInitialValue.toFixed(2)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 136,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 130,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 flex space-x-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 || !userPublicKey ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAllLp,
                        disabled: isLoading || positions.length === 0 || !userPublicKey,
                        children: "모든 LP 포지션 한번에 정리하기 (더미)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 142,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${isLoading || positions.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`,
                        onClick: handleRemoveAllLpAndSwap,
                        disabled: isLoading || positions.length === 0 || !userPublicKey,
                        children: "모든 LP 포지션 한번에 정리 및 SOL로 전부 자동 스왑 (더미)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 149,
                        columnNumber: 14
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 141,
                columnNumber: 8
            }, this),
            isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: "LP 포지션을 불러오는 중..."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 160,
                columnNumber: 9
            }, this) : error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-500 text-white p-4 rounded-md mb-4",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 162,
                columnNumber: 9
            }, this) : positions.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-300",
                children: "활성화된 LP 포지션이 없습니다."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 166,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: positions.map((position)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$lp$2f$LpPositionItem$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        position: position,
                        onPositionRemoved: ()=>console.log('Placeholder onPositionRemoved triggered')
                    }, position.address, false, {
                        fileName: "[project]/src/app/dashboard/page.tsx",
                        lineNumber: 170,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.tsx",
                lineNumber: 168,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/page.tsx",
        lineNumber: 78,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__46d54c11._.js.map