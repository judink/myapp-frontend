module.exports = {

"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/lp/create/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/app/lp/create/page.tsx
__turbopack_context__.s({
    "default": (()=>CreateLpPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/authStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)"); // Meteora 링크용
"use client";
;
;
;
;
;
;
// 이 함수는 컴포넌트 외부에 있어도 괜찮습니다. 필요한 모든 것을 파라미터로 받기 때문입니다.
async function loadStep6Data(tokenCa, totalSolValueStr, solDepositRatioStr, setTargetTokenPrice, setCalculatedAmounts, setUserWalletBalances, setLoadingStep6Data, setError, nativeMintAddress) {
    setLoadingStep6Data(true);
    setError(null);
    try {
        // 1. 대상 토큰 가격 조회 (SOL 기준)
        const priceResponse = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/jupiter/price?mintA=${tokenCa}&mintB=${nativeMintAddress}&amount=1`);
        const currentTargetTokenPrice = priceResponse.data.price;
        setTargetTokenPrice(currentTargetTokenPrice);
        if (!currentTargetTokenPrice || currentTargetTokenPrice <= 0) {
            throw new Error('대상 토큰의 가격을 가져올 수 없습니다.');
        }
        // 2. 필요 자산 계산
        const totalSolValueNum = parseFloat(totalSolValueStr);
        const solDepositRatioNum = parseInt(solDepositRatioStr) / 100;
        let neededSol;
        let neededToken;
        neededSol = totalSolValueNum * solDepositRatioNum;
        const valueForToken = totalSolValueNum * (1 - solDepositRatioNum);
        neededToken = valueForToken / currentTargetTokenPrice;
        setCalculatedAmounts({
            sol: neededSol,
            token: neededToken
        });
        // 3. 현재 지갑 잔액 조회 (SOL 및 대상 토큰)
        const balanceResponse = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/wallet/balance?tokenMint=${tokenCa}`);
        const userSolBalance = parseFloat(balanceResponse.data.solBalance);
        let userTokenBalance = 0;
        let targetTokenDecimals = 9; // 기본값
        if (balanceResponse.data.targetToken && balanceResponse.data.targetToken.mint === tokenCa && typeof balanceResponse.data.targetToken.balance === 'string') {
            if (typeof balanceResponse.data.targetToken.decimals === 'number') {
                targetTokenDecimals = balanceResponse.data.targetToken.decimals;
            } else {
                console.warn(`Decimals not found for ${tokenCa} in balanceResponse, using default ${targetTokenDecimals}`);
            }
            const balanceLamports = BigInt(balanceResponse.data.targetToken.balance);
            userTokenBalance = Number(balanceLamports) / Math.pow(10, targetTokenDecimals);
        } else if (balanceResponse.data.targetToken) {
            console.warn('Received targetToken data from backend is incomplete or invalid (mint mismatch or type issue):', balanceResponse.data.targetToken);
        }
        setUserWalletBalances({
            sol: userSolBalance,
            token: userTokenBalance,
            tokenDecimals: targetTokenDecimals
        }); // 수정됨
    } catch (err) {
        console.error('Error loading data for step 6:', err);
        setError(err.message || '자산 정보를 불러오는 중 오류가 발생했습니다.');
        setTargetTokenPrice(null);
        setCalculatedAmounts(null);
        setUserWalletBalances(null);
    } finally{
        setLoadingStep6Data(false);
    }
}
function CreateLpPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const { user, isLoggedIn, isLoading: authLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$authStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])();
    const [step, setStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const [tokenCa, setTokenCa] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [existingPools, setExistingPools] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedPool, setSelectedPool] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loadingPools, setLoadingPools] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [totalSolValue, setTotalSolValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [minBinInput, setMinBinInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''); // 타입 string으로 변경
    const [maxBinInput, setMaxBinInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''); // 타입 string으로 변경
    const [solDepositRatio, setSolDepositRatio] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('50');
    const [selectedStrategy, setSelectedStrategy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('Spot');
    const [targetTokenPrice, setTargetTokenPrice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [calculatedAmounts, setCalculatedAmounts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [userWalletBalances, setUserWalletBalances] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null); // 수정됨
    const [isLoadingStep6Data, setIsLoadingStep6Data] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // 6단계 데이터 로딩 상태 추가
    const [isCreatingLp, setIsCreatingLp] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // LP 생성 로딩 상태 추가
    const [creationTxId, setCreationTxId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null); // 생성된 트랜잭션 ID 추가
    // const [swapQuoteResponse, setSwapQuoteResponse] = useState<any | null>(null); // 더 이상 직접 사용하지 않음
    const [swapLoading, setSwapLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const NATIVE_MINT_ADDRESS = 'So11111111111111111111111111111111111111112';
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!authLoading && !isLoggedIn) {
            router.replace('/');
        }
    }, [
        authLoading,
        isLoggedIn,
        router
    ]);
    const [priceRangeLoading, setPriceRangeLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const calculateAndSetPriceRange = async ()=>{
            if (step === 5 && selectedPool && typeof selectedPool.current_price === 'number' && typeof selectedPool.binStep === 'number' && solDepositRatio !== null && selectedStrategy) {
                setPriceRangeLoading(true);
                setError(null);
                try {
                    const params = {
                        poolAddress: selectedPool.poolAddress,
                        currentPrice: selectedPool.current_price,
                        binStep: selectedPool.binStep,
                        solDepositRatioPercent: parseInt(solDepositRatio),
                        strategyType: selectedStrategy,
                        numBins: 69
                    };
                    console.log('Requesting price range calculation with params:', params);
                    // 응답 타입을 string으로 변경
                    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/calculate-price-range', params);
                    // 응답 데이터 타입 검증을 string으로 변경
                    if (response.data && typeof response.data.minPrice === 'string' && typeof response.data.maxPrice === 'string') {
                        setMinBinInput(response.data.minPrice); // 문자열 그대로 사용
                        setMaxBinInput(response.data.maxPrice); // 문자열 그대로 사용
                        console.log('Price range received from backend:', response.data);
                    } else {
                        throw new Error('Invalid price range data received from backend.');
                    }
                } catch (err) {
                    console.error('Error fetching calculated price range:', err);
                    setError(err.response?.data?.message || err.message || '자동 가격 범위 계산에 실패했습니다.');
                } finally{
                    setPriceRangeLoading(false);
                }
            }
        };
        calculateAndSetPriceRange();
    }, [
        step,
        selectedPool,
        solDepositRatio,
        selectedStrategy,
        setError
    ]);
    const handleTokenCaSubmit = async (e)=>{
        e.preventDefault();
        if (!tokenCa.trim()) {
            setError('토큰 컨트랙트 주소를 입력해주세요.');
            return;
        }
        setError(null);
        setLoadingPools(true);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/api/dlmm/pools?tokenA=${NATIVE_MINT_ADDRESS}&tokenB=${tokenCa}`);
            if (response.data && response.data.length > 0) {
                setExistingPools(response.data);
            } else {
                setExistingPools([]);
            }
            setStep(2);
        } catch (err) {
            console.error('Error fetching existing pools:', err);
            setError('기존 풀 정보를 가져오는 데 실패했습니다. 주소를 확인하거나 네트워크 상태를 점검해주세요.');
        } finally{
            setLoadingPools(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (step === 6 && user && tokenCa && totalSolValue && solDepositRatio && selectedPool) {
            loadStep6Data(tokenCa, totalSolValue, solDepositRatio, setTargetTokenPrice, setCalculatedAmounts, setUserWalletBalances, setIsLoadingStep6Data, setError, NATIVE_MINT_ADDRESS);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps 
    }, [
        step,
        user,
        tokenCa,
        totalSolValue,
        solDepositRatio,
        selectedPool
    ]);
    if (authLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-center items-center min-h-screen",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "인증 정보 로딩 중..."
            }, void 0, false, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 229,
                columnNumber: 75
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/lp/create/page.tsx",
            lineNumber: 229,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto p-4 pt-12 md:pt-20 max-w-2xl text-gray-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-3xl md:text-4xl font-bold text-white mb-8 text-center",
                children: "새 LP 포지션 생성"
            }, void 0, false, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 234,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-red-400 bg-red-900 p-3 rounded-md mb-6 text-center",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 238,
                columnNumber: 17
            }, this),
            step === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleTokenCaSubmit,
                className: "bg-orange-700 p-6 md:p-8 rounded-lg shadow-xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "tokenCa",
                        className: "block text-lg font-semibold text-white mb-2",
                        children: "대상 토큰 컨트랙트 주소 (Token CA)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 243,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        id: "tokenCa",
                        value: tokenCa,
                        onChange: (e)=>setTokenCa(e.target.value),
                        placeholder: "예: EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v (USDC)",
                        className: "w-full px-4 py-3 bg-orange-800 border border-orange-600 text-gray-100 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none transition-shadow",
                        required: true
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 246,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-orange-200 mt-2 mb-6",
                        children: "SOL과 페어를 이룰 대상 토큰의 주소를 입력해주세요."
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 255,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        className: "w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-300 ease-in-out disabled:opacity-50",
                        disabled: loadingPools,
                        children: loadingPools ? '기존 풀 확인 중...' : '다음 단계로'
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 258,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 242,
                columnNumber: 9
            }, this),
            step === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-orange-700 p-6 md:p-8 rounded-lg shadow-xl text-gray-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-6 text-center",
                        children: "기존 LP 풀 확인"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 270,
                        columnNumber: 11
                    }, this),
                    loadingPools && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center",
                        children: "풀 정보를 불러오는 중..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 271,
                        columnNumber: 28
                    }, this),
                    !loadingPools && existingPools.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-orange-200 mb-4 text-center",
                                children: [
                                    "입력하신 토큰 페어(SOL/",
                                    tokenCa.substring(0, 6),
                                    "...)에 대해 다음 기존 LP 풀을 찾았습니다."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 274,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "space-y-3 mb-6 max-h-60 overflow-y-auto",
                                children: existingPools.map((pool)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "p-4 bg-orange-800 border border-orange-600 rounded-md hover:shadow-lg transition-shadow",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        children: "풀 이름:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                                        lineNumber: 280,
                                                        columnNumber: 24
                                                    }, this),
                                                    " ",
                                                    pool.name || 'N/A'
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 280,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        children: "풀 주소:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                                        lineNumber: 281,
                                                        columnNumber: 24
                                                    }, this),
                                                    " ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-mono text-xs",
                                                        children: pool.poolAddress
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                                        lineNumber: 281,
                                                        columnNumber: 47
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 281,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        children: "Bin Step:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                                        lineNumber: 282,
                                                        columnNumber: 24
                                                    }, this),
                                                    " ",
                                                    pool.binStep
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 282,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        children: "Base Fee:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                                        lineNumber: 283,
                                                        columnNumber: 24
                                                    }, this),
                                                    " ",
                                                    (pool.baseFeeBps / 100).toFixed(2),
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 283,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        children: "Liquidity:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                                        lineNumber: 284,
                                                        columnNumber: 24
                                                    }, this),
                                                    " $",
                                                    pool.liquidity ? pool.liquidity.toLocaleString(undefined, {
                                                        minimumFractionDigits: 2,
                                                        maximumFractionDigits: 2
                                                    }) : 'N/A'
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 284,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        children: "24h Volume:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                                        lineNumber: 285,
                                                        columnNumber: 24
                                                    }, this),
                                                    " $",
                                                    pool.trade_volume_24h ? pool.trade_volume_24h.toLocaleString(undefined, {
                                                        minimumFractionDigits: 2,
                                                        maximumFractionDigits: 2
                                                    }) : 'N/A'
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 285,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>{
                                                    setSelectedPool(pool);
                                                    setStep(3);
                                                },
                                                className: "mt-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 text-sm",
                                                children: "이 풀에 유동성 추가"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 286,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, pool.poolAddress, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 279,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 277,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-orange-200 my-4 text-center",
                                children: "또는"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 298,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true),
                    !loadingPools && existingPools.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-orange-200 mb-6 text-center",
                        children: [
                            "입력하신 토큰 페어(SOL/",
                            tokenCa.substring(0, 6),
                            "...)에 대한 기존 LP 풀을 찾지 못했습니다."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 302,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "https://edge.meteora.ag/dlmm/create",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "block w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 px-4 rounded-lg text-center transition duration-300 mb-4",
                        children: "Meteora에서 새 풀 직접 생성하기 (외부 링크)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 306,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setStep(1);
                            setTokenCa('');
                            setExistingPools([]);
                            setSelectedPool(null);
                            setError(null);
                        },
                        className: "w-full bg-gray-600 hover:bg-gray-700 text-gray-100 font-semibold py-2 px-4 rounded-lg transition duration-300",
                        children: "이전 단계로 (토큰 CA 다시 입력)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 310,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 269,
                columnNumber: 9
            }, this),
            step === 3 && selectedPool && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-orange-700 p-6 md:p-8 rounded-lg shadow-xl text-gray-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-2 text-center",
                        children: "총 예치 가치 입력"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 321,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-orange-200 mb-1",
                        children: [
                            "선택된 풀: ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-mono text-xs",
                                children: selectedPool.poolAddress
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 322,
                                columnNumber: 62
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 322,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-orange-200 mb-6",
                        children: [
                            "(Bin Step: ",
                            selectedPool.binStep,
                            ", Fee: ",
                            selectedPool.baseFeeBps,
                            "bps)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 323,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "totalSolValue",
                        className: "block text-lg font-semibold text-white mb-2",
                        children: "총 예치할 가치 (SOL 기준)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 324,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "number",
                        id: "totalSolValue",
                        value: totalSolValue,
                        onChange: (e)=>setTotalSolValue(e.target.value),
                        placeholder: "예: 10 (SOL)",
                        className: "w-full px-4 py-3 bg-orange-800 border border-orange-600 text-gray-100 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none transition-shadow",
                        required: true
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 327,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            if (!totalSolValue || parseFloat(totalSolValue) <= 0) {
                                setError("올바른 예치 가치를 입력해주세요.");
                                return;
                            }
                            setError(null);
                            setStep(4);
                        },
                        className: "mt-6 w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-300",
                        children: "다음 (가격 범위 설정)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 336,
                        columnNumber: 12
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setStep(2),
                        className: "mt-4 w-full bg-gray-600 hover:bg-gray-700 text-gray-100 font-semibold py-2 px-4 rounded-lg transition duration-300",
                        children: "이전 단계로 (풀 다시 선택)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 349,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 320,
                columnNumber: 9
            }, this),
            step === 4 && selectedPool && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-orange-700 p-6 md:p-8 rounded-lg shadow-xl text-gray-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-6 text-center",
                        children: "SOL 예치 비율 및 전략 선택"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 360,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "solDepositRatio",
                                className: "block text-lg font-semibold text-white mb-2",
                                children: [
                                    "SOL 예치 비율: ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-bold text-sky-400",
                                        children: [
                                            solDepositRatio,
                                            "%"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 364,
                                        columnNumber: 26
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 363,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "range",
                                id: "solDepositRatio",
                                value: solDepositRatio,
                                onChange: (e)=>setSolDepositRatio(e.target.value),
                                min: "0",
                                max: "100",
                                step: "1",
                                className: "w-full h-3 bg-orange-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 366,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between text-xs text-orange-200 mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "0% (대상 토큰만)"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 377,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "50% (반반)"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 378,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "100% (SOL만)"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 379,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 376,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-orange-200 mt-2",
                                children: "총 예치 가치 중 SOL로 예치할 비율입니다."
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 381,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 362,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-lg font-semibold text-white mb-2",
                                children: "Volatility Strategy 선택"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 387,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2",
                                children: [
                                    'Spot',
                                    'Curve',
                                    'Bid-Ask'
                                ].map((strategy)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex items-center space-x-2 text-orange-100",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "radio",
                                                name: "volatilityStrategy",
                                                value: strategy,
                                                checked: selectedStrategy === strategy,
                                                onChange: (e)=>setSelectedStrategy(e.target.value),
                                                className: "form-radio h-4 w-4 text-sky-500 bg-orange-800 border border-orange-600 focus:ring-sky-500"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 393,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: strategy
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/lp/create/page.tsx",
                                                lineNumber: 401,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, strategy, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 392,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 390,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-orange-200 mt-2",
                                children: "선택한 전략에 따라 LP 분배 형태가 달라집니다. (가격 범위 계산에 영향)"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 405,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 386,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setError(null);
                            setStep(5);
                        },
                        className: "w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-300",
                        children: "다음 (가격 범위 확인)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 410,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setStep(4),
                        className: "mt-4 w-full bg-gray-600 hover:bg-gray-700 text-gray-100 font-semibold py-2 px-4 rounded-lg transition duration-300",
                        children: "이전 단계로 (비율/전략 다시 선택)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 419,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 359,
                columnNumber: 9
            }, this),
            step === 5 && selectedPool && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-orange-700 p-6 md:p-8 rounded-lg shadow-xl text-gray-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-6 text-center",
                        children: "가격 범위 확인"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 430,
                        columnNumber: 11
                    }, this),
                    priceRangeLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center text-sky-400",
                        children: "가격 범위 계산 중..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 431,
                        columnNumber: 33
                    }, this),
                    !priceRangeLoading && error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-red-400 bg-red-900 p-2 rounded-md text-sm text-center mb-4",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 432,
                        columnNumber: 43
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-orange-200 mb-1",
                        children: [
                            "선택된 풀: ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-mono text-xs",
                                children: selectedPool.poolAddress
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 434,
                                columnNumber: 62
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 434,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-orange-200 mb-1",
                        children: [
                            "현재 가격 (근사): ",
                            selectedPool.current_price ? selectedPool.current_price.toPrecision(7) : 'N/A'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 435,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-orange-200 mb-1",
                        children: [
                            "선택된 SOL 예치 비율: ",
                            solDepositRatio,
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 436,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-orange-200 mb-4",
                        children: [
                            "선택된 전략: ",
                            selectedStrategy || '미선택'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 437,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "minBinInput",
                                className: "block text-lg font-semibold text-white mb-2",
                                children: "계산된 최소 가격 (대상토큰/SOL)"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 440,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                id: "minBinInput",
                                value: minBinInput,
                                readOnly: true,
                                className: "w-full px-4 py-3 bg-orange-800 border border-orange-600 text-gray-100 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 443,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 439,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "maxBinInput",
                                className: "block text-lg font-semibold text-white mb-2",
                                children: "계산된 최대 가격 (대상토ken/SOL)"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 452,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                id: "maxBinInput",
                                value: maxBinInput,
                                readOnly: true,
                                className: "w-full px-4 py-3 bg-orange-800 border border-orange-600 text-gray-100 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 455,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 451,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-orange-200 mt-1 mb-4",
                        children: [
                            "* 위 가격 범위는 선택하신 SOL 예치 비율과 전략에 따라 자동으로 계산되었습니다. ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 464,
                                columnNumber: 61
                            }, this),
                            "* (참고: 이 자동 계산은 근사치이며, 실제 Meteora SDK의 정교한 로직과 다를 수 있습니다.)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 463,
                        columnNumber: 12
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setError(null);
                            setStep(6);
                        },
                        className: "w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-300",
                        children: "다음 (자산 확인)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 467,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setStep(4),
                        className: "mt-4 w-full bg-gray-600 hover:bg-gray-700 text-gray-100 font-semibold py-2 px-4 rounded-lg transition duration-300",
                        children: "이전 단계로 (비율/전략 다시 선택)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 476,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 429,
                columnNumber: 10
            }, this),
            step === 6 && selectedPool && user && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-orange-700 p-6 md:p-8 rounded-lg shadow-xl text-gray-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold text-white mb-6 text-center",
                        children: "자산 확인"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 487,
                        columnNumber: 11
                    }, this),
                    isLoadingStep6Data && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center",
                        children: "데이터를 불러오는 중..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 488,
                        columnNumber: 34
                    }, this),
                    " ",
                    !isLoadingStep6Data && calculatedAmounts && userWalletBalances && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-semibold text-white",
                                        children: "필요 자산:"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 493,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "SOL: ",
                                            calculatedAmounts.sol.toFixed(6)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 494,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "대상 토큰 (",
                                            tokenCa.substring(0, 6),
                                            "...): ",
                                            calculatedAmounts.token.toFixed(6)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 495,
                                        columnNumber: 17
                                    }, this),
                                    targetTokenPrice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-orange-200",
                                        children: [
                                            "(대상 토큰 현재 가격: 1 ",
                                            tokenCa.substring(0, 3),
                                            "... ≈ ",
                                            targetTokenPrice.toFixed(6),
                                            " SOL)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 496,
                                        columnNumber: 38
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 492,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-semibold text-white",
                                        children: "현재 지갑 잔액:"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 499,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "SOL: ",
                                            userWalletBalances.sol.toFixed(6)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 500,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "대상 토큰 (",
                                            tokenCa.substring(0, 6),
                                            "...): ",
                                            userWalletBalances.token.toFixed(6),
                                            " (Decimals: ",
                                            userWalletBalances.tokenDecimals || 'N/A',
                                            ")"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 501,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 498,
                                columnNumber: 15
                            }, this),
                            (userWalletBalances.sol < calculatedAmounts.sol || userWalletBalances.token < calculatedAmounts.token) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 p-3 bg-yellow-600 border border-yellow-500 rounded-md text-yellow-100",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-semibold",
                                        children: "자산 부족 알림"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 506,
                                        columnNumber: 19
                                    }, this),
                                    userWalletBalances.sol < calculatedAmounts.sol && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm",
                                        children: [
                                            "SOL이 부족합니다. (필요: ",
                                            calculatedAmounts.sol.toFixed(6),
                                            ", 현재: ",
                                            userWalletBalances.sol.toFixed(6),
                                            ")"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 507,
                                        columnNumber: 70
                                    }, this),
                                    userWalletBalances.token < calculatedAmounts.token && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm",
                                        children: [
                                            "대상 토큰이 부족합니다. (필요: ",
                                            calculatedAmounts.token.toFixed(6),
                                            ", 현재: ",
                                            userWalletBalances.token.toFixed(6),
                                            ")"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 508,
                                        columnNumber: 74
                                    }, this),
                                    !swapLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: async ()=>{
                                            if (!calculatedAmounts || !userWalletBalances || !tokenCa || !selectedPool?.current_price || typeof userWalletBalances.tokenDecimals !== 'number') {
                                                setError("스왑 정보를 계산하거나 실행하기 위한 데이터가 부족합니다. (특히 대상 토큰 Decimals)");
                                                return;
                                            }
                                            setSwapLoading(true);
                                            setError(null);
                                            // setSwapQuoteResponse(null); // 더 이상 직접 사용 안 함
                                            let inputMint = null;
                                            let outputMint = null;
                                            let amountToSwapLamportsStr = null;
                                            const solDecimals = 9;
                                            const currentTargetTokenDecimals = userWalletBalances.tokenDecimals; // 수정됨
                                            let neededInputAmountForSwapUI = 0;
                                            let neededInputSymbol = '';
                                            if (userWalletBalances.token < calculatedAmounts.token) {
                                                inputMint = NATIVE_MINT_ADDRESS;
                                                outputMint = tokenCa;
                                                const neededTokenAmount = calculatedAmounts.token - userWalletBalances.token;
                                                const solValueForNeededToken = neededTokenAmount * selectedPool.current_price;
                                                amountToSwapLamportsStr = Math.ceil(solValueForNeededToken * Math.pow(10, solDecimals) * 1.05).toString();
                                                neededInputAmountForSwapUI = parseFloat(amountToSwapLamportsStr) / Math.pow(10, solDecimals);
                                                neededInputSymbol = 'SOL';
                                                if (userWalletBalances.sol * Math.pow(10, solDecimals) < BigInt(amountToSwapLamportsStr)) {
                                                    setError(`대상 토큰으로 스왑할 SOL 잔액이 부족합니다. (필요: ${neededInputAmountForSwapUI.toFixed(6)} SOL)`);
                                                    setSwapLoading(false);
                                                    return;
                                                }
                                            } else if (userWalletBalances.sol < calculatedAmounts.sol) {
                                                inputMint = tokenCa;
                                                outputMint = NATIVE_MINT_ADDRESS;
                                                const neededSolAmount = calculatedAmounts.sol - userWalletBalances.sol;
                                                const tokenValueForNeededSol = neededSolAmount / selectedPool.current_price;
                                                amountToSwapLamportsStr = Math.ceil(tokenValueForNeededSol * Math.pow(10, currentTargetTokenDecimals) * 1.05).toString();
                                                neededInputAmountForSwapUI = parseFloat(amountToSwapLamportsStr) / Math.pow(10, currentTargetTokenDecimals);
                                                neededInputSymbol = tokenCa.substring(0, 4) + '...';
                                                if (userWalletBalances.token * Math.pow(10, currentTargetTokenDecimals) < BigInt(amountToSwapLamportsStr)) {
                                                    setError(`SOL로 스왑할 ${neededInputSymbol} 잔액이 부족합니다. (필요: ${neededInputAmountForSwapUI.toFixed(6)} ${neededInputSymbol})`);
                                                    setSwapLoading(false);
                                                    return;
                                                }
                                            }
                                            if (inputMint && outputMint && amountToSwapLamportsStr && BigInt(amountToSwapLamportsStr) > 0) {
                                                try {
                                                    console.log(`Requesting swap quote: ${amountToSwapLamportsStr} of ${inputMint} to ${outputMint}`);
                                                    const quoteApiUrl = `/api/jupiter/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountToSwapLamportsStr}&slippageBps=50`;
                                                    const quoteRes = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(quoteApiUrl);
                                                    console.log('Actual Jupiter Quote Response:', JSON.stringify(quoteRes.data, null, 2)); // 디버깅용 로그
                                                    const currentSwapQuote = quoteRes.data; // Jupiter /quote API 응답
                                                    // 스왑 견적 표시 시 사용할 decimals 결정 (수정됨)
                                                    // currentSwapQuote.inputMint와 currentSwapQuote.outputMint는 주소 문자열임.
                                                    // currentSwapQuote.inAmount와 currentSwapQuote.outAmount는 lamports 단위 문자열.
                                                    const displayInputDecimals = currentSwapQuote.inputMint === NATIVE_MINT_ADDRESS ? solDecimals : currentTargetTokenDecimals;
                                                    const displayOutputDecimals = currentSwapQuote.outputMint === NATIVE_MINT_ADDRESS ? solDecimals : currentTargetTokenDecimals;
                                                    const inAmountHuman = Number(currentSwapQuote.inAmount) / Math.pow(10, displayInputDecimals);
                                                    const outAmountHuman = Number(currentSwapQuote.outAmount) / Math.pow(10, displayOutputDecimals);
                                                    // 심볼은 quote 응답에 없을 수 있으므로, 직접 결정 (수정됨)
                                                    const inputSymbolDisplay = currentSwapQuote.inputMint === NATIVE_MINT_ADDRESS ? 'SOL' : tokenCa.substring(0, 4) + '...';
                                                    const outputSymbolDisplay = currentSwapQuote.outputMint === NATIVE_MINT_ADDRESS ? 'SOL' : tokenCa.substring(0, 4) + '...';
                                                    const proceedWithSwap = window.confirm(`자산이 부족하여 자동 스왑을 진행합니다.\n\n` + `스왑: ${inAmountHuman.toFixed(6)} ${inputSymbolDisplay} → 약 ${outAmountHuman.toFixed(6)} ${outputSymbolDisplay}\n\n` + `스왑을 진행하고 LP 포지션을 생성하시겠습니까? (Slippage 0.5% 적용)`);
                                                    if (proceedWithSwap) {
                                                        console.log('User confirmed swap. Executing swap with quote:', currentSwapQuote);
                                                        const swapResponse = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/jupiter/swap', {
                                                            quoteResponse: currentSwapQuote
                                                        });
                                                        alert(`스왑 성공! 트랜잭션 ID: ${swapResponse.data.txid}\n이제 LP 포지션 생성을 진행합니다.`);
                                                        await loadStep6Data(tokenCa, totalSolValue, solDepositRatio, setTargetTokenPrice, setCalculatedAmounts, setUserWalletBalances, setIsLoadingStep6Data, setError, NATIVE_MINT_ADDRESS); // 수정: 올바른 함수 이름 사용
                                                    } else {
                                                        setError("스왑이 취소되었습니다.");
                                                    }
                                                } catch (err) {
                                                    console.error('Error during swap process:', err);
                                                    setError(err.response?.data?.message || err.message || '스왑 처리 중 오류가 발생했습니다.');
                                                }
                                            } else {
                                                setError("스왑할 토큰이나 수량이 결정되지 않았습니다. (이미 충분하거나, 양쪽 다 부족)");
                                            }
                                            setSwapLoading(false);
                                        },
                                        className: "mt-2 bg-amber-500 hover:bg-amber-600 text-white font-semibold py-2 px-3 rounded-lg text-sm disabled:opacity-70",
                                        disabled: swapLoading || calculatedAmounts && userWalletBalances && userWalletBalances.sol >= calculatedAmounts.sol && userWalletBalances.token >= calculatedAmounts.token,
                                        children: swapLoading ? "스왑 처리 중..." : "자동 스왑 후 LP 생성 진행"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 511,
                                        columnNumber: 21
                                    }, this),
                                    swapLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-center text-sky-400 mt-2",
                                        children: "스왑 처리 중입니다. 잠시만 기다려주세요..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 616,
                                        columnNumber: 35
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 505,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 491,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: async ()=>{
                            if (!calculatedAmounts || !userWalletBalances || !selectedPool || !tokenCa || !totalSolValue || !solDepositRatio || !selectedStrategy || !minBinInput || !maxBinInput) {
                                setError('LP 생성에 필요한 정보가 부족합니다. 이전 단계를 확인해주세요.');
                                return;
                            }
                            if (userWalletBalances.sol < calculatedAmounts.sol || userWalletBalances.token < calculatedAmounts.token) {
                                setError('자산이 부족합니다. "자동 스왑 후 LP 생성 진행" 버튼을 사용하거나, 직접 자산을 확보해주세요.');
                                return;
                            }
                            setIsCreatingLp(true);
                            setError(null);
                            setCreationTxId(null); // 트랜잭션 ID 상태 초기화
                            try {
                                const payload = {
                                    poolAddress: selectedPool.poolAddress,
                                    tokenCa: tokenCa,
                                    totalSolValue: totalSolValue,
                                    solDepositRatioPercent: parseInt(solDepositRatio),
                                    strategyType: selectedStrategy,
                                    minPrice: parseFloat(minBinInput),
                                    maxPrice: parseFloat(maxBinInput),
                                    autoSwapConfirmed: false
                                };
                                console.log("Calling /api/dlmm/lp/create with payload:", payload);
                                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/api/dlmm/lp/create', payload);
                                if (response.data && response.data.signature) {
                                    setCreationTxId(response.data.signature); // 트랜잭션 ID 상태 설정
                                    alert(`LP 포지션 생성 성공! 트랜잭션 ID: ${response.data.signature}`);
                                // 성공 후 대시보드 이동 또는 상태 초기화 등
                                // router.push('/dashboard');
                                } else {
                                    throw new Error(response.data.message || 'LP 생성에 실패했습니다.');
                                }
                            } catch (err) {
                                console.error('Error creating LP position:', err);
                                setError(err.response?.data?.message || err.message || 'LP 포지션 생성 중 오류가 발생했습니다.');
                                setCreationTxId(null); // 오류 시 트랜잭션 ID 상태 초기화
                            } finally{
                                setIsCreatingLp(false);
                            }
                        },
                        className: "mt-8 w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300 disabled:opacity-50",
                        disabled: isLoadingStep6Data || swapLoading || isCreatingLp || !calculatedAmounts || !userWalletBalances || calculatedAmounts && userWalletBalances && (userWalletBalances.sol < calculatedAmounts.sol || userWalletBalances.token < calculatedAmounts.token),
                        children: isCreatingLp ? 'LP 생성 중...' : 'LP 생성 실행'
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 622,
                        columnNumber: 11
                    }, this),
                    creationTxId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4 p-3 bg-green-800 border border-green-600 rounded-md text-green-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-semibold",
                                children: "LP 포지션 생성 성공!"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 677,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm",
                                children: [
                                    "트랜잭션 ID:",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: `https://solscan.io/tx/${creationTxId}?cluster=devnet`,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "text-sky-400 hover:text-sky-300 underline ml-1 break-all",
                                        children: creationTxId
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/lp/create/page.tsx",
                                        lineNumber: 679,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 678,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>router.push('/dashboard'),
                                className: "mt-2 bg-sky-600 hover:bg-sky-700 text-white font-semibold py-1 px-3 rounded text-sm",
                                children: "대시보드로 이동"
                            }, void 0, false, {
                                fileName: "[project]/src/app/lp/create/page.tsx",
                                lineNumber: 688,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 676,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setStep(5),
                        className: "mt-4 w-full bg-gray-600 hover:bg-gray-700 text-gray-100 font-semibold py-2 px-4 rounded-lg transition duration-300",
                        disabled: isCreatingLp,
                        children: "이전 단계로 (가격 범위 다시 설정)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/lp/create/page.tsx",
                        lineNumber: 697,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/lp/create/page.tsx",
                lineNumber: 486,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/lp/create/page.tsx",
        lineNumber: 233,
        columnNumber: 5
    }, this);
} // CreateLpPage 컴포넌트의 끝
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__d1e03fe3._.js.map