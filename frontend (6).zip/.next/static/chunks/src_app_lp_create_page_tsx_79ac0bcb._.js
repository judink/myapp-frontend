(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@noble_curves_esm_d476331b._.js",
  "static/chunks/node_modules_@solana_web3_js_lib_index_browser_esm_88d65ea0.js",
  "static/chunks/node_modules_afc8d187._.js",
  "static/chunks/src_7a7389d7._.js"
],
    source: "dynamic"
});
