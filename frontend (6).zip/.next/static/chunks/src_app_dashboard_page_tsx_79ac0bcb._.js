(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@noble_curves_esm_d476331b._.js",
  "static/chunks/node_modules_@solana_bc9b563d._.js",
  "static/chunks/node_modules_@solana_web3_js_lib_index_browser_esm_88d65ea0.js",
  "static/chunks/node_modules_pako_dist_pako_esm_mjs_b4dc27e5._.js",
  "static/chunks/node_modules_@coral-xyz_anchor_dist_9a414708._.js",
  "static/chunks/node_modules_@solana_spl-token_lib_esm_f526c5c8._.js",
  "static/chunks/node_modules_@meteora-ag_dlmm_dist_index_mjs_330700ab._.js",
  "static/chunks/node_modules_aa435df2._.js",
  "static/chunks/src_c83c6bba._.js"
],
    source: "dynamic"
});
