"use client";

import React from 'react';
import { LpPosition } from '@/types/dlmm'; // Import the updated LpPosition type
import { PublicKey } from '@solana/web3.js'; // Import necessary Solana types
import useAuthStore from '@/store/authStore'; // Import useAuthStore
import Decimal from 'decimal.js'; // For calculations

interface LpPositionItemProps {
  position: LpPosition;
  onPositionRemoved: (positionAddress: string) => void; // Callback after successful removal
}

// Helper to convert lamports to UI amount (can be shared or defined here)
// This helper is now primarily used for transaction building amounts if needed,
// as display amounts come pre-calculated from the backend.
function lamportsToUiAmount(lamports: string | number | bigint | undefined | null, decimals: number | undefined | null): string {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return '0';
    try {
        const amountDecimal = new Decimal(lamports.toString()).div(new Decimal(10).pow(decimals));
        return amountDecimal.toFixed(Math.min(decimals, 6)); // Example: show up to 6 decimals
    } catch (e) {
        console.error("Error formatting amount:", e);
        return 'Error';
    }
}

export default function LpPositionItem({ position }: LpPositionItemProps) {
  // Get userPublicKey from auth store instead of wallet adapter
  const { user } = useAuthStore();
  const userPublicKey = user?.solanaPublicKey ? new PublicKey(user.solanaPublicKey) : null;

  // Display details are now received directly in the position prop
  // No need for a separate state or useEffect for calculations

  // useEffect(() => {
  //     // Calculation logic moved to backend
  // }, [position, connection]);


  // Disable these functions as client-side signing is removed
  const handleRemoveLiquidity = async () => {
    console.warn("handleRemoveLiquidity: Disabled due to wallet adapter removal.");
  };

  // Disable these functions as client-side signing is removed
  const handleRemoveAndSwap = async () => {
    console.warn("handleRemoveAndSwap: Disabled due to wallet adapter removal.");
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg mb-4">
      <h3 className="text-lg font-semibold text-white mb-2">LP 포지션: {position.address.slice(0, 6)}...{position.address.slice(-6)}</h3>
      <p className="text-gray-300">풀: {position.pair_address.slice(0, 6)}...{position.pair_address.slice(-6)}</p>

      {/* Display calculated details from backend */}
      <p className="text-gray-300">가격 범위: {position.priceRange}</p>
      <p className="text-gray-300">총 가치 (SOL): {position.totalValueInSol}</p>
      <p className="text-gray-300">
        예치 금액: {position.totalXAmountUi} ({position.tokenXMint.slice(0, 4)}...) / {position.totalYAmountUi} ({position.tokenYMint.slice(0, 4)}...)
      </p>
      <p className="text-gray-300">
        미청구 수수료: {position.pendingFeeXUi} ({position.tokenXMint.slice(0, 4)}...) / {position.pendingFeeYUi} ({position.tokenYMint.slice(0, 4)}...)
      </p>
      {position.pendingRewardsUi.map((reward, index) => (
        <p key={index} className="text-gray-300">
          미청구 보상 {index + 1}: {reward.amount} ({reward.mint.slice(0, 4)}...)
        </p>
      ))}

      {/* Removed error display as state is removed */}

      <div className="flex space-x-2 mt-4">
        <button
          className={`bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 opacity-50 cursor-not-allowed`}
          onClick={handleRemoveLiquidity}
          disabled={true}
        >
          LP 해제 (비활성화됨)
        </button>
        <button
          className={`bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 opacity-50 cursor-not-allowed`}
          onClick={handleRemoveAndSwap}
          disabled={true}
        >
          LP 해제 및 자동 스왑 (비활성화됨)
        </button>
      </div>
    </div>
  );
}
