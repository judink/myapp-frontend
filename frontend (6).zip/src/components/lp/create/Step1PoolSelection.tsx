import React from 'react';
import { StrategyType } from '@meteora-ag/dlmm'; // Keep import if needed for types

interface Pool {
  poolAddress: string;
  tokenX: string;
  tokenY: string;
  tokenXMint: string;
  tokenYMint: string;
  binStep: number;
  baseFeeBps: number;
  name: string;
  liquidity: number;
  trade_volume_24h: number;
  current_price: number;
}

interface Step1PoolSelectionProps {
  tokenCaInput: string;
  setTokenCaInput: (value: string) => void;
  pools: Pool[];
  poolsLoading: boolean;
  handlePoolSearch: () => void;
  selectedPool: Pool | null;
  setSelectedPool: (pool: Pool | null) => void;
  setCurrentStep: (step: number) => void;
}

export default function Step1PoolSelection({
  tokenCaInput,
  setTokenCaInput,
  pools,
  poolsLoading,
  handlePoolSearch,
  selectedPool,
  setSelectedPool,
  setCurrentStep,
}: Step1PoolSelectionProps) {
  return (
    <>
      <h2 className="text-2xl font-semibold text-white mb-4">단계 1: 토큰 선택 및 풀 검색</h2>
      <div className="mb-4">
        <label htmlFor="tokenCaInput" className="block text-gray-300 text-sm font-bold mb-2">
          대상 토큰 (Y) 민트 주소:
        </label>
        <input
          type="text"
          id="tokenCaInput"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          value={tokenCaInput}
          onChange={(e) => setTokenCaInput(e.target.value)}
          placeholder="예: 대상 토큰 민트 주소"
        />
        <button
          className="mt-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
          onClick={handlePoolSearch}
          disabled={poolsLoading}
        >
          {poolsLoading ? '풀 검색 중...' : '풀 검색'}
        </button>
      </div>
      {poolsLoading ? (
        <p>풀 목록을 불러오는 중...</p>
      ) : pools.length === 0 && tokenCaInput ? (
        <p>입력하신 토큰 페어에 해당하는 풀을 찾을 수 없습니다.</p>
      ) : pools.length > 0 ? (
        <div className="mb-4">
          <label htmlFor="poolSelect" className="block text-gray-300 text-sm font-bold mb-2">
            풀 선택:
          </label>
          <select
            id="poolSelect"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            value={selectedPool?.poolAddress || ''}
            onChange={(e) => {
              const pool = pools.find(p => p.poolAddress === e.target.value);
              setSelectedPool(pool || null);
            }}
          >
            <option value="" disabled>풀을 선택해주세요</option>
            {pools.map(pool => (
              <option key={pool.poolAddress} value={pool.poolAddress}>
                {`${pool.name || `${pool.tokenX.substring(0, 4)}/${pool.tokenY.substring(0, 4)}`} - Bin Step: ${pool.binStep} - Base Fee: ${pool.baseFeeBps / 100}% - Liquidity: ${pool.liquidity.toFixed(2)} - 24h Volume: ${pool.trade_volume_24h.toFixed(2)}`}
              </option>
            ))}
          </select>
        </div>
      ) : null}
      <button
        className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition duration-300"
        onClick={() => setCurrentStep(2)}
        disabled={!selectedPool || poolsLoading}
      >
        다음
      </button>
    </>
  );
}
