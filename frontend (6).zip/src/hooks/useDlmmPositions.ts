import { useState, useEffect, useCallback, useRef } from 'react';
import { Connection, PublicKey } from '@solana/web3.js';
import DLMM from '@meteora-ag/dlmm';
import BN from 'bn.js';
import axios from 'axios';
import Decimal from 'decimal.js'; // Assuming Decimal.js is used for calculations
import { getMint } from '@solana/spl-token'; // Import getMint

// Define interfaces for data structure
interface LpPositionDetail {
    address: string;
    pair_address: string;
    owner: string;
    total_fee_usd_claimed: number;
    total_reward_usd_claimed: number;
    fee_apy_24h: number;
    fee_apr_24h: number;
    daily_fee_yield: number;
    lowerBinId: number;
    upperBinId: number;
    binStep: number;
    tokenXMint: string;
    tokenYMint: string;
    tokenXDecimals: number;
    tokenYDecimals: number;
    totalXAmount: bigint; // Use bigint for raw amounts
    totalYAmount: bigint; // Use bigint for raw amounts
    pendingFeeX: bigint; // Use bigint for raw amounts
    pendingFeeY: bigint; // Use bigint for raw amounts
    pendingRewards: { mint: string; amount: bigint }[]; // Use bigint for amounts
    totalXAmountUi: string;
    totalYAmountUi: string;
    pendingFeeXUi: string;
    pendingFeeYUi: string;
    pendingRewardsUi: { amount: string; mint: string }[];
    priceRange: string;
    totalValueInSol: string;
    isInRange: boolean;
    currentBinId: number;
    tokenXPrice: number;
    tokenYPrice: number;
    claimedValue: number;
    unclaimedValue: number;
    positionValue: number;
    totalCurrentValue: number;
    depositInfo: any; // Placeholder for deposit info structure
    dynamicFee: number | null;
}

interface DlmmPositionsHook {
    positions: LpPositionDetail[];
    isLoading: boolean;
    error: string | null;
    totalSummary: {
        totalLiquidityValue: number;
        totalClaimedFees: number;
        totalUnclaimedFees: number;
        totalPositions: number;
        inRangePositions: number;
        totalInitialValue: number;
        totalPnL: number;
        totalPnLPercentage: number;
    };
    fetchPositions: () => Promise<void>; // Add fetchPositions to the interface
}

// Configuration options (adapted for frontend environment variables)
const CONFIG = {
    SOL_TOKEN_ADDRESS: "So11111111111111111111111111111111111111112",
    RANGE_BAR_WIDTH: 20,
    UPDATE_INTERVAL: 60000, // 1 minute
    ERROR_RETRY_DELAY: 5000,
    RPC_ENDPOINT: process.env.NEXT_PUBLIC_SOLANA_RPC_URL || 'https://api.devnet.solana.com',
};

// Helper function to get token price from Jupiter API
async function getTokenPrice(tokenMint: string): Promise<number> {
    if (!tokenMint) {
        console.error('getTokenPrice: tokenMint is undefined or null');
        return 0;
    }
    try {
        const response = await axios.get(`https://api.jup.ag/price/v2?ids=${tokenMint}`);
        return response.data.data[tokenMint]?.price ? parseFloat(response.data.data[tokenMint].price) : 0;
    } catch (error) {
        console.error('Error fetching price:', error);
        return 0;
    }
}

// Helper function to get token name from Gecko Terminal
async function getTokenName(tokenMint: string): Promise<string> {
     if (!tokenMint) {
        console.error('getTokenName: tokenMint is undefined or null');
        return tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token';
    }
    try {
        const response = await axios.get(`https://api.geckoterminal.com/api/v2/networks/solana/tokens/${tokenMint}`);
        return response.data.data?.attributes?.name || (tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token');
    } catch (error) {
        console.error('Error fetching token name:', error);
        return tokenMint ? tokenMint.slice(0, 4) + '...' + tokenMint.slice(-4) : 'Unknown Token';
    }
}


// Helper function to convert lamports to token amount
function lamportsToTokenAmount(lamports: BN, decimals: number): number {
    if (lamports === undefined || lamports === null || decimals === undefined || decimals === null) return 0;
    try {
        const divisor = new Decimal(10).pow(decimals);
        const amountDecimal = new Decimal(lamports.toString()).div(divisor);
        return amountDecimal.toNumber();
    } catch (err) {
        console.error('Error in lamportsToTokenAmount:', err);
        return 0;
    }
}

// Helper function to fetch initial deposit information
async function getInitialDeposit(positionAddress: string): Promise<any> {
     if (!positionAddress) {
        console.error('getInitialDeposit: positionAddress is undefined or null');
        return null;
    }
    try {
        const response = await axios.get(`https://dlmm-api.meteora.ag/position/${positionAddress}/deposits`);
        const deposits = response.data;

        if (deposits && deposits.length > 0) {
            const deposit = deposits[0]; // Get the first deposit
            const timestamp = new Date(deposit.onchain_timestamp * 1000).toLocaleString();

            return {
                tokenXAmount: deposit.token_x_amount,
                tokenYAmount: deposit.token_y_amount,
                tokenXUsdAmount: deposit.token_x_usd_amount,
                tokenYUsdAmount: deposit.token_y_usd_amount,
                timestamp: timestamp,
                price: deposit.price,
                onchain_timestamp: deposit.onchain_timestamp,
            };
        }
        return null;
    } catch (error) {
        console.error('Error fetching deposit information:', error);
        return null;
    }
}

// Helper function to get current dynamic fee
async function getCurrentDynamicFee(poolAddress: string): Promise<number | null> {
     if (!poolAddress) {
        console.error('getCurrentDynamicFee: poolAddress is undefined or null');
        return null;
    }
    try {
        const response = await axios.get(`https://dlmm-api.meteora.ag/pair/${poolAddress}`);
        const data = response.data;

        const baseFee = parseFloat(data.base_fee_percentage);
        // const maxFee = parseFloat(data.max_fee_percentage); // Not used in original logic

        return baseFee;

    } catch (error) {
        console.error('Error fetching dynamic fee:', error);
        return null;
    }
}


export const useDlmmPositions = (userPublicKey: PublicKey | null | undefined): DlmmPositionsHook => {
    const [positions, setPositions] = useState<LpPositionDetail[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const fetchedPublicKeyRef = useRef<string | null>(null); // Ref to track the public key for which data has been fetched
    const [totalSummary, setTotalSummary] = useState({
        totalLiquidityValue: 0,
        totalClaimedFees: 0,
        totalUnclaimedFees: 0,
        totalPositions: 0,
        inRangePositions: 0,
        totalInitialValue: 0,
        totalPnL: 0,
        totalPnLPercentage: 0,
    });


    const fetchPositions = useCallback(async () => {
        if (!userPublicKey) {
            setPositions([]);
            setIsLoading(false);
            return;
        }

        setIsLoading(true);
        setError(null);

        const fetchedPositions: LpPositionDetail[] = [];
        let totalLiquidityValue = 0;
        let totalClaimedFees = 0;
        let totalUnclaimedFees = 0;
        let totalPositions = 0;
        let inRangePositions = 0;
        let totalInitialValue = 0;


        try {
            const connection = new Connection(CONFIG.RPC_ENDPOINT, 'confirmed');
            const userPositionsMap = await DLMM.getAllLbPairPositionsByUser(
                connection,
                userPublicKey
            );

            if (userPositionsMap.size === 0) {
                setPositions([]);
                setIsLoading(false);
                setTotalSummary({
                    totalLiquidityValue: 0,
                    totalClaimedFees: 0,
                    totalUnclaimedFees: 0,
                    totalPositions: 0,
                    inRangePositions: 0,
                    totalInitialValue: 0,
                    totalPnL: 0,
                    totalPnLPercentage: 0,
                });
                // Reset fetched key on logout/no positions
                fetchedPublicKeyRef.current = null;
                return;
            }

            for (const [poolAddress, _] of userPositionsMap.entries()) {
                try {
                    const dlmmPool = await DLMM.create(connection, new PublicKey(poolAddress));
                    const activeBin = await dlmmPool.getActiveBin();
                    const currentBinId = activeBin.binId;

                    const { userPositions: poolPositions } = await dlmmPool.getPositionsByUserAndLbPair(userPublicKey);
                    const tokenXPrice = await getTokenPrice(dlmmPool.tokenX.publicKey.toString());
                    const tokenYPrice = await getTokenPrice(dlmmPool.tokenY.publicKey.toString());

                    // Fetch decimals using mint addresses if not available on dlmmPool object
                    let tokenXDecimals = (dlmmPool.tokenX as any).decimal;
                    let tokenYDecimals = (dlmmPool.tokenY as any).decimal;

                    if (tokenXDecimals === undefined || tokenXDecimals === null || tokenYDecimals === undefined || tokenYDecimals === null) {
                        try {
                            const tokenXMintInfo = await getMint(connection, new PublicKey(dlmmPool.tokenX.publicKey));
                            const tokenYMintInfo = await getMint(connection, new PublicKey(dlmmPool.tokenY.publicKey));
                            tokenXDecimals = tokenXMintInfo.decimals;
                            tokenYDecimals = tokenYMintInfo.decimals;
                        } catch (decimalError) {
                            console.error('Error fetching token decimals:', decimalError);
                            // Fallback to a default or handle error appropriately
                            tokenXDecimals = 0; // Or some default
                            tokenYDecimals = 0; // Or some default
                        }
                    }

                    for (const positionDetails of poolPositions) {
                        totalPositions++;
                        const { positionData } = positionDetails;

                        const isInRange = currentBinId >= positionData.lowerBinId && currentBinId <= positionData.upperBinId;
                        if (isInRange) inRangePositions++;

                        // Ensure amounts are treated as BN before converting to number
                        const xAmountBN = BN.isBN(positionData.totalXAmount) ? positionData.totalXAmount : new BN(positionData.totalXAmount.toString());
                        const yAmountBN = BN.isBN(positionData.totalYAmount) ? positionData.totalYAmount : new BN(positionData.totalYAmount.toString());

                        const tokenXAmount = lamportsToTokenAmount(xAmountBN, tokenXDecimals);
                        const tokenYAmount = lamportsToTokenAmount(yAmountBN, tokenYDecimals);

                        const tokenXValue = tokenXAmount * tokenXPrice;
                        const tokenYValue = tokenYAmount * tokenYPrice;

                        // Access fee properties, using type assertion or checking for existence
                        const claimedXAmount = lamportsToTokenAmount(new BN(positionData.totalClaimedFeeXAmount?.toString() || '0'), tokenXDecimals);
                        const claimedYAmount = lamportsToTokenAmount(new BN(positionData.totalClaimedFeeYAmount?.toString() || '0'), tokenYDecimals);

                        const claimableXAmount = lamportsToTokenAmount(new BN((positionData as any).feeX?.toString() || '0'), tokenXDecimals);
                        const claimableYAmount = lamportsToTokenAmount(new BN((positionData as any).feeY?.toString() || '0'), tokenYDecimals);


                        // Removed conditional logging inside the loop


                        const positionValue = tokenXValue + tokenYValue;
                        const claimedValue = (claimedXAmount * tokenXPrice) + (claimedYAmount * tokenYPrice);
                        const unclaimedValue = (claimableXAmount * tokenXPrice) + (claimableYAmount * tokenYPrice);
                        const totalCurrentValueForPosition = positionValue + claimedValue + unclaimedValue; // Renamed to avoid scope conflict

                        // Removed conditional logging inside the loop

                        totalLiquidityValue += positionValue;
                        totalClaimedFees += claimedValue;
                        totalUnclaimedFees += unclaimedValue;
                        // Removed conditional logging inside the loop


                        const depositInfo = await getInitialDeposit(positionDetails.publicKey.toString());
                        if (depositInfo) {
                             totalInitialValue += (depositInfo.tokenXUsdAmount || 0) + (depositInfo.tokenYUsdAmount || 0);
                        }

                        const dynamicFee = await getCurrentDynamicFee(poolAddress);


                        fetchedPositions.push({
                            address: positionDetails.publicKey.toString(),
                            pair_address: poolAddress,
                            owner: userPublicKey.toBase58(), // Assuming owner is the connected user
                            total_fee_usd_claimed: 0, // This might need to be fetched from API if not in SDK
                            total_reward_usd_claimed: 0, // This might need to be fetched from API if not in SDK
                            fee_apy_24h: 0, // This might need to be fetched from API
                            fee_apr_24h: 0, // This might need to be fetched from API
                            daily_fee_yield: 0, // This might need to be fetched from API
                            lowerBinId: positionData.lowerBinId,
                            upperBinId: positionData.upperBinId,
                            // Access binStep from the pool object directly if available
                            binStep: (dlmmPool as any).binStep,
                            tokenXMint: dlmmPool.tokenX.publicKey.toBase58(),
                            tokenYMint: dlmmPool.tokenY.publicKey.toBase58(),
                            tokenXDecimals: tokenXDecimals,
                            tokenYDecimals: tokenYDecimals,
                            totalXAmount: BigInt(xAmountBN.toString()), // Convert BN to string then bigint
                            totalYAmount: BigInt(yAmountBN.toString()), // Convert BN to string then bigint
                            pendingFeeX: BigInt(new BN((positionData as any).feeX?.toString() || '0').toString()), // Convert to BN then string then bigint
                            pendingFeeY: BigInt(new BN((positionData as any).feeY?.toString() || '0').toString()), // Convert to BN then string then bigint
                            // Access rewardInfos from positionData, using type assertion based on observed structure
                            pendingRewards: (positionData as any).rewardInfos?.map((r: any) => ({ mint: r.mint?.toBase58() || '', amount: BigInt(new BN(r.pendingReward?.toString() || '0').toString()) })) || [], // Convert to BN then string then bigint
                            totalXAmountUi: tokenXAmount.toFixed(tokenXDecimals),
                            totalYAmountUi: tokenYAmount.toFixed(tokenYDecimals),
                            pendingFeeXUi: claimableXAmount.toFixed(tokenXDecimals), // Use claimableXAmount here
                            pendingFeeYUi: claimableYAmount.toFixed(tokenYDecimals), // Use claimableYAmount here
                            pendingRewardsUi: (positionData as any).pendingRewardsUi?.map((r: any) => ({ amount: r.amount?.toString() || '0', mint: r.mint?.toBase58() || '' })) || [],
                            priceRange: `${positionData.lowerBinId} - ${positionData.upperBinId}`, // Simple bin ID range for now
                            totalValueInSol: totalCurrentValueForPosition.toFixed(4), // Using total value for this position
                            isInRange: isInRange,
                            currentBinId: currentBinId,
                            tokenXPrice: tokenXPrice,
                            tokenYPrice: tokenYPrice,
                            claimedValue: claimedValue,
                            unclaimedValue: unclaimedValue,
                            positionValue: positionValue,
                            totalCurrentValue: totalCurrentValueForPosition, // Use the value for this position
                            depositInfo: depositInfo,
                            dynamicFee: dynamicFee,
                        });
                    }
                } catch (poolError: any) {
                    console.error(`Error processing pool ${poolAddress}:`, poolError);
                    // Continue to the next pool even if one fails
                }
            }

             const overallTotalCurrentValue = totalLiquidityValue + totalClaimedFees + totalUnclaimedFees;
             const overallTotalPnL = overallTotalCurrentValue - totalInitialValue;
             const overallTotalPnLPercentage = totalInitialValue > 0 ? (overallTotalPnL / totalInitialValue) * 100 : 0;


            setPositions(fetchedPositions);
            setTotalSummary({
                totalLiquidityValue,
                totalClaimedFees,
                totalUnclaimedFees,
                totalPositions,
                inRangePositions,
                totalInitialValue,
                totalPnL: overallTotalPnL,
                totalPnLPercentage: overallTotalPnLPercentage,
            });


        } catch (e: any) {
            console.error('Error fetching user positions:', e);
            setError(e.message || 'LP 포지션 목록을 불러오는데 실패했습니다.');
        } finally {
            setIsLoading(false);
        }
    }, [userPublicKey]); // Dependency on userPublicKey


    useEffect(() => {
        const currentPublicKeyString = userPublicKey?.toBase58() || null;

        // Fetch positions only when userPublicKey changes and is not null/undefined,
        // and we haven't fetched for this specific public key yet.
        if (userPublicKey && currentPublicKeyString !== fetchedPublicKeyRef.current) {
            fetchedPublicKeyRef.current = currentPublicKeyString; // Mark as fetching/fetched for this key immediately
            fetchPositions();
        } else if (!userPublicKey) {
            // Reset state and log tracking when userPublicKey is null/undefined (e.g., after logout)
            setPositions([]);
            setIsLoading(false);
            fetchedPublicKeyRef.current = null; // Reset log tracking on logout
            setTotalSummary({
                totalLiquidityValue: 0,
                totalClaimedFees: 0,
                totalUnclaimedFees: 0,
                totalPositions: 0,
                inRangePositions: 0,
                totalInitialValue: 0,
                totalPnL: 0,
                totalPnLPercentage: 0,
            });
        }
        // Dependencies: Only userPublicKey?.toBase58() and fetchPositions.
        // fetchPositions is memoized with useCallback and depends only on userPublicKey.
        // This setup should prevent infinite loops.
    }, [userPublicKey?.toBase58(), fetchPositions]);


    // Return fetchPositions so it can be called manually from the component
    return { positions, isLoading, error, totalSummary, fetchPositions };
};
